import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../errors/app_exception.dart';
import '../theme/app_colors.dart';

class Helpers {
  Helpers._();

  /// Clamp long text (conversation titles, prompts...).
  static String clamp(String text, int max) {
    final String t = text.trim();
    if (t.length <= max) return t;
    return '${t.substring(0, max).trim()}…';
  }

  static String formatNumber(int n) => NumberFormat.compact().format(n);

  static String formatDate(DateTime dt, String locale) =>
      DateFormat.yMMMd(locale).add_Hm().format(dt.toLocal());

  static String formatDay(DateTime dt, String locale) =>
      DateFormat.yMMMd(locale).format(dt.toLocal());

  /// Map Supabase auth failures to user-facing error keys.
  static String mapAuthError(Object error) {
    final String msg = error.toString().toLowerCase();
    if (msg.contains('invalid login credentials')) return 'errWrongCredentials';
    if (msg.contains('already registered') || msg.contains('already exists')) {
      return 'errEmailTaken';
    }
    if (msg.contains('rate limit') || msg.contains('too many')) {
      return 'errTooManyRequests';
    }
    if (msg.contains('network') ||
        msg.contains('socket') ||
        msg.contains('connection')) {
      return 'errNetwork';
    }
    return 'authFailed';
  }

  static String mapAppError(AppException e) {
    switch (e.type) {
      case AppErrorType.network:
        return 'networkError';
      case AppErrorType.unauthorized:
        return 'loginRequired';
      case AppErrorType.imageTooLarge:
        return 'imageTooLarge';
      case AppErrorType.uploadFailed:
        return 'uploadFailed';
      case AppErrorType.limitDailyChat:
        return 'limitDailyChat';
      case AppErrorType.limitDailyImages:
        return 'limitDailyImages';
      case AppErrorType.limitCredits:
        return 'limitCredits';
      case AppErrorType.server:
        return 'serverError';
    }
  }

  static void showSnack(
    BuildContext context,
    String message, {
    bool error = false,
  }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? AppColors.error : null,
        duration: Duration(milliseconds: error ? 3500 : 2200),
      ),
    );
  }

  static String mimeFromPath(String path) {
    final String ext = path.split('.').last.toLowerCase();
    switch (ext) {
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      default:
        return 'image/jpeg';
    }
  }

  static String stylePrefixHint(String? styleId) {
    switch (styleId) {
      case 'realistic':
        return 'ultra realistic photograph, natural lighting, 8k';
      case 'anime':
        return 'anime style, vibrant, studio anime key visual';
      case 'digital_art':
        return 'digital art, trending on artstation, detailed';
      case '3d_render':
        return '3d render, octane render, soft studio lighting';
      case 'watercolor':
        return 'delicate watercolor painting, textured paper';
      case 'cyberpunk':
        return 'cyberpunk style, neon lights, cinematic';
      case 'minimal':
        return 'minimalist flat design, clean shapes, pastel palette';
      case 'logo':
        return 'clean vector logo, flat, centered, white background';
      default:
        return '';
    }
  }
}
