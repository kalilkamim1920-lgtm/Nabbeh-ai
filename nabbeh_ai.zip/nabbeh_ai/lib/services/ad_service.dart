/// Optional lightweight advertising layer.
///
/// DESIGN:
/// - Free users see a small "Go PRO" promo banner (no third-party ads).
/// - If you later want real AdMob ads: add the `google_mobile_ads` package,
///   put the AdMob App ID in AndroidManifest/Info.plist and the banner unit
///   id below via .env — the banner widget switches automatically.
///
/// NO ad unit IDs are hardcoded in this project.
class AdService {
  AdService._();

  /// Real ads are disabled until you opt in (see README -> Ads section).
  static bool get adsEnabled => false;

  /// Whether the free-tier promo banner should be visible for this user.
  static bool shouldShowPromoBanner(bool isPro) => !isPro;
}
