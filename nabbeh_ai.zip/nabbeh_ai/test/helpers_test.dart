import 'package:flutter_test/flutter_test.dart';
import 'package:nabbeh_ai/core/utils/helpers.dart';

void main() {
  group('Helpers', () {
    test('clamp shortens long text', () {
      final String result = Helpers.clamp('a' * 100, 10);
      expect(result.length, lessThanOrEqualTo(11));
      expect(result.endsWith('…'), isTrue);
    });

    test('clamp keeps short text intact', () {
      expect(Helpers.clamp('hello', 10), 'hello');
    });

    test('mime detection works', () {
      expect(Helpers.mimeFromPath('photo.png'), 'image/png');
      expect(Helpers.mimeFromPath('photo.jpg'), 'image/jpeg');
    });
  });
}
