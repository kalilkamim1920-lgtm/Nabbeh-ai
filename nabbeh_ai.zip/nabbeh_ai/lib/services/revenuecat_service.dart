import 'dart:io';

import 'package:flutter/services.dart'
    show PlatformException;
import 'package:purchases_flutter/purchases_flutter.dart';

import '../core/config/env_config.dart';

/// RevenueCat integration for subscriptions and credit packs.
///
/// Only PUBLIC SDK keys are used here (they are designed to ship in apps).
/// Server-side verification happens in the `sync-subscription` Edge Function
/// and the `revenuecat-webhook` function using the RevenueCat SECRET key.
class RevenueCatService {
  RevenueCatService._();

  static bool _configured = false;
  static bool get isConfigured => _configured;

  static Future<void> init() async {
    if (!EnvConfig.isRevenueCatConfigured) {
      _configured = false;
      return;
    }
    try {
      await Purchases.setLogLevel(LogLevel.warn);
      final String apiKey =
          Platform.isIOS ? EnvConfig.revenueCatAppleKey : EnvConfig.revenueCatGoogleKey;
      if (apiKey.isEmpty) {
        _configured = false;
        return;
      }
      final PurchasesConfiguration configuration = PurchasesConfiguration(apiKey);
      await Purchases.configure(configuration);
      _configured = true;
    } catch (_) {
      _configured = false;
    }
  }

  /// Tie the RevenueCat user to the Supabase user id.
  static Future<void> logIn(String appUserId) async {
    if (!_configured) return;
    try {
      await Purchases.logIn(appUserId);
    } catch (_) {/* non-fatal */}
  }

  static Future<void> logOut() async {
    if (!_configured) return;
    try {
      await Purchases.logOut();
    } catch (_) {/* non-fatal */}
  }

  static Future<bool> hasProEntitlement() async {
    if (!_configured) return false;
    try {
      final CustomerInfo info = await Purchases.getCustomerInfo();
      return info.entitlements.all['pro_access']?.isActive == true;
    } catch (_) {
      return false;
    }
  }

  /// Returns available packages from the current offering.
  static Future<List<Package>> getOfferings() async {
    if (!_configured) return [];
    try {
      final Offerings offerings = await Purchases.getOfferings();
      return offerings.current?.availablePackages ?? [];
    } catch (_) {
      return [];
    }
  }

  /// Returns the customer info after a successful purchase, or null.
  static Future<CustomerInfo?> purchase(Package package) async {
    if (!_configured) return null;
    try {
      return await Purchases.purchasePackage(package);
    } on PlatformException catch (e) {
      if (e.code == '1' ||
          (e.details?['readableErrorCode'] == 'PURCHASE_CANCELLED_ERROR') ||
          (e.details?['userCancelled'] == true)) {
        // User cancelled — not an error.
        return null;
      }
      rethrow;
    }
  }

  static Future<void> restore() => Purchases.restorePurchases();
}
