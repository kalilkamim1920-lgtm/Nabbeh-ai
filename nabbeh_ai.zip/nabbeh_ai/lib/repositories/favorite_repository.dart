import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/favorite_item.dart';
import '../services/supabase_service.dart';

/// Text favorites (saved prompts).
class FavoriteRepository {
  const FavoriteRepository();

  SupabaseClient get _client => SupabaseService.client;
  String? get _uid => SupabaseService.currentUser?.id;

  Future<List<FavoriteItem>> listPrompts({int limit = 100}) async {
    final String? uid = _uid;
    if (uid == null) return [];
    final List<dynamic> rows = await _client
        .from('favorites')
        .select()
        .eq('user_id', uid)
        .eq('item_type', 'prompt')
        .order('created_at', ascending: false)
        .limit(limit);
    return rows
        .map((e) => FavoriteItem.fromMap(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> savePrompt(String title, String content) async {
    final String? uid = _uid;
    if (uid == null) return;
    await _client.from('favorites').insert({
      'user_id': uid,
      'item_type': 'prompt',
      'title': title,
      'content': content,
    });
  }

  Future<void> remove(String id) async {
    await _client.from('favorites').delete().eq('id', id);
  }
}
