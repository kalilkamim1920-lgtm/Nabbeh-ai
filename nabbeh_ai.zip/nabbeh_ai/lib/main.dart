import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/config/env_config.dart';
import 'core/theme/app_theme.dart';
import 'generated/app_localizations.dart';
import 'providers/auth_provider.dart';
import 'providers/chat_provider.dart';
import 'providers/creation_provider.dart';
import 'providers/gallery_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/subscription_provider.dart';
import 'screens/splash_screen.dart';
import 'services/revenuecat_service.dart';
import 'services/settings_storage.dart';
import 'services/supabase_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1) Public client config (.env — no secrets here, by design).
  await EnvConfig.load();

  // 2) Backend connection (only when configured).
  if (EnvConfig.isConfigured) {
    await SupabaseService.init();
  }

  // 3) Local settings + RevenueCat (safe no-op without public keys).
  await SettingsStorage.init();
  await RevenueCatService.init();

  runApp(const NabbehApp());
}

class NabbehApp extends StatelessWidget {
  const NabbehApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<SettingsProvider>(
          create: (_) => SettingsProvider(),
        ),
        if (EnvConfig.isConfigured)
          ChangeNotifierProvider<AuthProvider>(create: (_) => AuthProvider()),
        ChangeNotifierProvider<ChatProvider>(create: (_) => ChatProvider()),
        ChangeNotifierProvider<CreationProvider>(
          create: (_) => CreationProvider(),
        ),
        ChangeNotifierProvider<GalleryProvider>(
          create: (_) => GalleryProvider(),
        ),
        ChangeNotifierProvider<SubscriptionProvider>(
          create: (_) => SubscriptionProvider(),
        ),
      ],
      child: Consumer<SettingsProvider>(
        builder: (BuildContext context, SettingsProvider settings, _) {
          return MaterialApp(
            title: 'NABBEH AI',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: settings.themeMode,
            locale: settings.locale,
            supportedLocales: S.supportedLocales,
            localizationsDelegates: S.localizationsDelegates,
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}
