import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../l10n_helper.dart';
import '../../models/generation.dart';
import '../../providers/auth_provider.dart';
import '../../providers/gallery_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/generation_grid.dart';
import '../create/image_generation_screen.dart';
import 'image_detail_screen.dart';

/// Full-screen gallery of generated images (pushed from Home/Profile).
class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<GalleryProvider>().loadImages();
    });
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final GalleryProvider gallery = context.watch<GalleryProvider>();
    final AuthProvider auth = context.watch<AuthProvider>();

    if (!auth.isSignedIn) {
      return Scaffold(
        appBar: AppBar(title: Text(s.galleryTitle)),
        body: EmptyState(
          icon: Icons.lock_outline_rounded,
          title: s.loginRequired,
          subtitle: s.signInToContinue,
          actionLabel: s.tabProfile,
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(s.galleryTitle),
        actions: [
          IconButton(
            tooltip: s.favoritesTitle,
            onPressed: () => setState(() {
              context.read<GalleryProvider>().toggleShowOnlyFavorites();
            }),
            icon: Icon(
              gallery.showOnlyFavorites
                  ? Icons.star_rounded
                  : Icons.star_border_rounded,
              color: gallery.showOnlyFavorites ? const Color(0xFFF2C94C) : null,
            ),
          ),
        ],
      ),
      body: gallery.loadingImages && gallery.images.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : gallery.images.isEmpty
              ? EmptyState(
                  icon: Icons.photo_library_outlined,
                  title: s.historyEmptyImages,
                  actionLabel: s.featureImageTitle,
                  onAction: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const ImageGenerationScreen(),
                      ),
                    );
                    if (!context.mounted) return;
                    context.read<GalleryProvider>().loadImages();
                  },
                )
              : NotificationListener<ScrollNotification>(
                  onNotification: (ScrollNotification n) {
                    if (n.metrics.pixels >=
                        n.metrics.maxScrollExtent - 240) {
                      context.read<GalleryProvider>().loadMoreImages();
                    }
                    return false;
                  },
                  child: GenerationGrid(
                    generations: gallery.images,
                    onTap: (Generation g) => _open(context, g),
                  ),
                ),
    );
  }

  Future<void> _open(BuildContext context, Generation g) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ImageDetailScreen(generation: g),
      ),
    );
    if (!context.mounted) return;
    context.read<GalleryProvider>().loadImages();
  }
}
