/// App-wide constants.
///
/// The SERVER (Supabase Edge Functions) is the single source of truth for
/// enforcement — these client constants exist only for display/copywriting.
class AppConstants {
  AppConstants._();

  static const String appName = 'NABBEH AI';
  static const String appVersion = '1.0.0';

  // ----- Credit costs per action (mirrors backend) -----
  static const int costChat = 1;
  static const int costPrompt = 1;
  static const int costAnalysis = 2;
  static const int costEdit = 8;
  static const int costImage = 10;
  static const int costImageHd = 15;

  // ----- Plan display names -----
  static const String entitlementPro = 'pro_access';

  // RevenueCat product identifiers (create the same ids in the stores).
  static const String productIdMonthly = 'nabbeh_pro_monthly';
  static const String productIdYearly = 'nabbeh_pro_yearly';
  static const String productIdCreditsSmall = 'nabbeh_credits_small';
  static const String productIdCreditsMedium = 'nabbeh_credits_medium';
  static const String productIdCreditsLarge = 'nabbeh_credits_large';

  // Demo prices shown only when RevenueCat is not configured yet.
  static const Map<String, String> demoPrices = {
    productIdMonthly: r'$4.99',
    productIdYearly: r'$39.99',
    productIdCreditsSmall: r'$1.99',
    productIdCreditsMedium: r'$6.99',
    productIdCreditsLarge: r'$12.99',
  };

  // ----- Image styles -----
  static const List<String> imageStyles = [
    'none',
    'realistic',
    'anime',
    'digital_art',
    '3d_render',
    'watercolor',
    'cyberpunk',
    'minimal',
    'logo',
  ];

  // ----- Aspect ratios -----
  static const List<String> aspectRatios = ['1:1', '16:9', '9:16'];

  // ----- Prompt target platforms -----
  static const List<String> promptPlatforms = [
    'generic',
    'midjourney',
    'stable_diffusion',
    'dalle',
  ];

  // ----- Client-side upload guard -----
  static const int maxImageBytes = 4 * 1024 * 1024; // 4 MB
  static const int maxPickDimension = 1600;
  static const int pickQuality = 85;
}
