import 'package:flutter/foundation.dart';
import 'package:purchases_flutter/purchases_flutter.dart';

import '../core/constants/app_constants.dart';
import '../providers/auth_provider.dart';
import '../services/ai_service.dart';
import '../services/revenuecat_service.dart';

/// Subscription + credit-pack purchase state.
class SubscriptionProvider extends ChangeNotifier {
  bool _loading = false;
  bool _purchasing = false;
  List<Package> _packages = <Package>[];

  bool get loading => _loading;
  bool get purchasing => _purchasing;
  bool get revenueCatReady => RevenueCatService.isConfigured;
  List<Package> get packages => _packages;

  List<Package> get subscriptionPackages => _packages
      .where((Package p) =>
          p.packageType == PackageType.monthly ||
          p.packageType == PackageType.annual ||
          p.packageType == PackageType.lifetime)
      .toList();

  List<Package> get creditPackages => _packages
      .where((Package p) => p.packageType == PackageType.custom)
      .toList();

  Future<void> loadOfferings() async {
    if (!RevenueCatService.isConfigured) return;
    _loading = true;
    notifyListeners();
    try {
      _packages = await RevenueCatService.getOfferings();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// Ask the backend to verify the entitlement with RevenueCat and
  /// sync `profiles.plan` / credits accordingly.
  Future<bool> syncWithBackend(AuthProvider auth) async {
    try {
      final Map<String, dynamic>? res = await AiService.syncSubscription();
      if (res != null && res['profile'] is Map<String, dynamic>) {
        await auth.loadProfile();
        return (res['profile'] as Map<String, dynamic>)['plan'] == 'pro';
      }
      return auth.isPro;
    } catch (_) {
      return auth.isPro;
    }
  }

  /// Purchases [package]. Returns true when the purchase completed.
  Future<bool> purchase(Package package, AuthProvider auth) async {
    if (_purchasing) return false;
    _purchasing = true;
    notifyListeners();
    try {
      if (RevenueCatService.isConfigured) {
        final customerInfo = await RevenueCatService.purchase(package);
        if (customerInfo == null) return false; // cancelled
        await AiService.syncSubscription();
        await auth.loadProfile();
        return true;
      } else {
        // Demo mode: no RevenueCat keys yet. The backend grants PRO only
        // while RevenueCat secrets are missing on the server side, so the
        // developer can test premium flows. See README.
        await AiService.syncSubscription(demo: true);
        await auth.loadProfile();
        return true;
      }
    } finally {
      _purchasing = false;
      notifyListeners();
    }
  }

  Future<bool> restore(AuthProvider auth) async {
    if (!RevenueCatService.isConfigured) return false;
    await RevenueCatService.restore();
    await AiService.syncSubscription();
    await auth.loadProfile();
    return true;
  }

  String priceFor(Package package) {
    final String price = package.storeProduct.priceString;
    if (price.isNotEmpty) return price;
    return AppConstants.demoPrices[package.storeProduct.identifier] ?? '';
  }

  bool isYearly(Package package) => package.packageType == PackageType.annual;

  bool isMonthly(Package package) => package.packageType == PackageType.monthly;

  bool isCreditPack(Package package) =>
      package.packageType == PackageType.custom;

  /// Maps a credit-pack product id to its localized label key.
  String creditsLabelKeyFor(String productId) {
    switch (productId) {
      case AppConstants.productIdCreditsLarge:
        return 'creditsLarge';
      case AppConstants.productIdCreditsMedium:
        return 'creditsMedium';
      default:
        return 'creditsSmall';
    }
  }
}
