import 'package:flutter/foundation.dart';

import '../models/chat_message.dart';
import '../models/conversation.dart';
import '../repositories/chat_repository.dart';
import '../services/ai_service.dart';

/// Chat state: conversation list + the active conversation's messages.
class ChatProvider extends ChangeNotifier {
  final ChatRepository _repo = const ChatRepository();

  List<Conversation> _conversations = <Conversation>[];
  List<ChatMessage> _messages = <ChatMessage>[];
  String? _activeConversationId;
  bool _loadingConversations = false;
  bool _loadingMessages = false;
  bool _sending = false;
  String _language = 'en';

  List<Conversation> get conversations => _conversations;
  List<ChatMessage> get messages => _messages;
  String? get activeConversationId => _activeConversationId;
  bool get loadingConversations => _loadingConversations;
  bool get loadingMessages => _loadingMessages;
  bool get sending => _sending;

  set language(String code) {
    _language = code;
  }

  Future<void> loadConversations() async {
    _loadingConversations = true;
    notifyListeners();
    try {
      _conversations = await _repo.listConversations();
    } finally {
      _loadingConversations = false;
      notifyListeners();
    }
  }

  Future<void> openConversation(String conversationId) async {
    _activeConversationId = conversationId;
    _loadingMessages = true;
    notifyListeners();
    try {
      _messages = await _repo.listMessages(conversationId);
    } finally {
      _loadingMessages = false;
      notifyListeners();
    }
  }

  void startNewChat() {
    _activeConversationId = null;
    _messages = <ChatMessage>[];
    notifyListeners();
  }

  void clearActive() {
    _activeConversationId = null;
    _messages = <ChatMessage>[];
    _conversations = <Conversation>[];
  }

  /// Sends [text] (with optional attached image) through the backend.
  /// Throws [AppException] so the UI can react (limits -> paywall).
  Future<void> sendMessage({
    required String text,
    String? imageBase64,
    String? imageMime,
  }) async {
    if (_sending) return;
    final String content = text.trim();
    if (content.isEmpty && imageBase64 == null) return;

    _sending = true;
    notifyListeners();

    // Optimistic user message.
    final ChatMessage pending = _repo.buildPendingMessage(
      conversationId: _activeConversationId ?? 'new',
      content: content,
      imageUrl: imageBase64 == null ? null : 'local',
    );
    _messages = List<ChatMessage>.from(_messages)..add(pending);
    notifyListeners();

    try {
      final Map<String, dynamic> res = await AiService.chat(
        conversationId: _activeConversationId,
        message: content,
        imageBase64: imageBase64,
        imageMime: imageMime,
        language: _language,
      );

      final String conversationId =
          (res['conversation_id'] ?? _activeConversationId ?? '').toString();

      final ChatMessage userMsg = res['user_message'] is Map<String, dynamic>
          ? ChatMessage.fromMap(res['user_message'] as Map<String, dynamic>)
          : pending;
      final ChatMessage assistantMsg =
          res['assistant_message'] is Map<String, dynamic>
              ? ChatMessage.fromMap(
                  res['assistant_message'] as Map<String, dynamic>)
              : ChatMessage.pending(
                  conversationId: conversationId,
                  role: 'assistant',
                  content: (res['reply'] ?? '').toString(),
                );

      _activeConversationId = conversationId;
      // Replace optimistic entry with persisted rows.
      _messages = List<ChatMessage>.from(_messages)
        ..removeLast()
        ..addAll(<ChatMessage>[userMsg, assistantMsg]);

      await loadConversations();
    } catch (_) {
      _messages = List<ChatMessage>.from(_messages)..removeLast();
      rethrow;
    } finally {
      _sending = false;
      notifyListeners();
    }
  }

  Future<void> deleteConversation(String id) async {
    await _repo.deleteConversation(id);
    _conversations = List<Conversation>.from(_conversations)
      ..removeWhere((Conversation c) => c.id == id);
    if (_activeConversationId == id) {
      _activeConversationId = null;
      _messages = <ChatMessage>[];
    }
    notifyListeners();
  }
}
