import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/app_user.dart';
import '../repositories/user_repository.dart';
import '../services/revenuecat_service.dart';
import '../services/supabase_service.dart';

/// Authentication + profile state.
class AuthProvider extends ChangeNotifier {
  AuthProvider() {
    _listen();
    _bootstrap();
  }

  final UserRepository _repo = const UserRepository();

  User? _user;
  AppUser? _profile;
  bool _initialized = false;
  bool _loading = false;

  User? get user => _user;
  AppUser? get profile => _profile;
  bool get initialized => _initialized;
  bool get loading => _loading;
  bool get isSignedIn => _user != null;
  bool get isPro => _profile?.isPro ?? false;
  int get credits => _profile?.credits ?? 0;

  void _listen() {
    SupabaseService.client.auth.onAuthStateChange.listen((AuthState state) {
      final AuthChangeEvent event = state.event;
      _user = state.session?.user;
      if (event == AuthChangeEvent.signedOut || _user == null) {
        _profile = null;
      } else if (event == AuthChangeEvent.initialSession ||
          event == AuthChangeEvent.signedIn ||
          event == AuthChangeEvent.userUpdated) {
        loadProfile();
      }
      notifyListeners();
    });
  }

  Future<void> _bootstrap() async {
    _user = SupabaseService.currentUser;
    if (_user != null) {
      await loadProfile();
    }
    _initialized = true;
    notifyListeners();
  }

  Future<void> loadProfile() async {
    try {
      final AppUser? fresh = await _repo.fetchProfile();
      if (fresh != null) {
        _profile = fresh;
        // Keep RevenueCat user aligned with Supabase user.
        await RevenueCatService.logIn(fresh.id);
      }
      notifyListeners();
    } catch (_) {/* profile loads lazily on next screen */}
  }

  Future<void> refreshAfterPurchase() async {
    try {
      final AppUser? fresh = await _repo.fetchProfile(retry: false);
      if (fresh != null) {
        _profile = fresh;
        notifyListeners();
      }
    } catch (_) {/* ignore */}
  }

  Future<void> signIn(String email, String password) async {
    _setLoading(true);
    try {
      await SupabaseService.signIn(email, password);
      _user = SupabaseService.currentUser;
      await loadProfile();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> signUp(String email, String password, String name) async {
    _setLoading(true);
    try {
      await SupabaseService.signUp(email, password, name);
      _user = SupabaseService.currentUser;
      if (_user != null) {
        await loadProfile();
      }
    } finally {
      _setLoading(false);
    }
  }

  Future<void> signInAsGuest() async {
    _setLoading(true);
    try {
      await SupabaseService.signInAsGuest();
      _user = SupabaseService.currentUser;
      await loadProfile();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> resetPassword(String email) =>
      SupabaseService.resetPassword(email);

  Future<void> updateDisplayName(String name) async {
    await _repo.updateDisplayName(name);
    await loadProfile();
  }

  Future<void> signOut() async {
    await RevenueCatService.logOut();
    await SupabaseService.signOut();
    _user = null;
    _profile = null;
    notifyListeners();
  }

  void _setLoading(bool v) {
    _loading = v;
    notifyListeners();
  }

  @override
  void dispose() {
    // Stream subscription is managed by Supabase lifecycle.
    super.dispose();
  }
}
