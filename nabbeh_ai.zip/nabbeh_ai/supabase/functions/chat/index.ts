// NABBEH AI — chat endpoint (text + optional vision).
// POST /functions/v1/chat
// body: { conversation_id?, message, image_base64?, image_mime?, language? }

import {
  adminClient,
  aiChat,
  CHAT_SYSTEM_PROMPT,
  consume,
  COSTS,
  corsHeaders,
  fail,
  getProfile,
  json,
  readHistory,
  refillIfNeeded,
  requireUser,
} from "../_shared/utils.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return fail("bad_request", "method", "POST only", 405);
  }

  const auth = await requireUser(req);
  if (auth instanceof Response) return auth;
  const admin = adminClient();

  try {
    const body = await req.json();
    const message: string = (body.message ?? "").toString().trim();
    const imageBase64: string | null = body.image_base64 ?? null;
    const imageMime: string = (body.image_mime ?? "image/jpeg").toString();
    const language: string = (body.language ?? "en").toString();

    if (!message && !imageBase64) {
      return fail("bad_request", "input", "message is required", 400);
    }

    // 1) Profile + daily refill
    let profile = await getProfile(admin, auth.user.id);
    if (!profile) return fail("unauthorized", "profile", "Profile missing", 401);
    profile = await refillIfNeeded(admin, profile);

    // 2) Limits + credits
    const result = await consume(admin, profile, "chat", COSTS.chat);
    if (result instanceof Response) return result;

    // 3) Conversation (create if needed)
    let conversationId: string = (body.conversation_id ?? "").toString();
    if (!conversationId) {
      const { data, error } = await admin
        .from("conversations")
        .insert({
          user_id: auth.user.id,
          title: message ? message.slice(0, 60) : "Image chat",
        })
        .select()
        .single();
      if (error) return fail("server", "db", error.message, 500);
      conversationId = (data as { id: string }).id;
    }

    // 4) History + provider call
    const history = await readHistory(admin, conversationId);
    const imageDataUri = imageBase64
      ? `data:${imageMime};base64,${imageBase64}`
      : undefined;

    const { text } = await aiChat(
      CHAT_SYSTEM_PROMPT +
        (language === "ar" ? " The user interface language is Arabic." : ""),
      history,
      message || "What is in this image? Describe it briefly.",
      imageDataUri,
    );

    // 5) Persist both messages
    const { data: userMsg, error: userErr } = await admin
      .from("messages")
      .insert({
        conversation_id: conversationId,
        user_id: auth.user.id,
        role: "user",
        content: message || "🖼️",
        image_url: null,
      })
      .select()
      .single();
    if (userErr) return fail("server", "db", userErr.message, 500);

    const { data: assistantMsg, error: assistantErr } = await admin
      .from("messages")
      .insert({
        conversation_id: conversationId,
        user_id: auth.user.id,
        role: "assistant",
        content: text,
      })
      .select()
      .single();
    if (assistantErr) return fail("server", "db", assistantErr.message, 500);

    return json({
      conversation_id: conversationId,
      user_message: userMsg,
      assistant_message: assistantMsg,
      credits_left: result.creditsLeft,
      plan: profile.plan,
    });
  } catch (e) {
    return fail("server", "ai", e instanceof Error ? e.message : String(e), 500);
  }
});
