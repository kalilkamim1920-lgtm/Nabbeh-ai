import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

/// PRO membership badge.
class ProBadge extends StatelessWidget {
  const ProBadge({super.key, this.height = 26});

  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: AppColors.proGradient,
        borderRadius: BorderRadius.circular(30),
      ),
      child: const Text(
        'PRO',
        style: TextStyle(
          color: Color(0xFF5C3A00),
          fontWeight: FontWeight.w900,
          fontSize: 12,
          letterSpacing: 1,
        ),
      ),
    );
  }
}
