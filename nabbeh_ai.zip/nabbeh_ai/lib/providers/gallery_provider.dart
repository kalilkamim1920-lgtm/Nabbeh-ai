import 'package:flutter/foundation.dart';

import '../models/favorite_item.dart';
import '../models/generation.dart';
import '../repositories/favorite_repository.dart';
import '../repositories/generation_repository.dart';

/// Gallery (visual creations) + text favorites state.
class GalleryProvider extends ChangeNotifier {
  final GenerationRepository _genRepo = const GenerationRepository();
  final FavoriteRepository _favRepo = const FavoriteRepository();

  List<Generation> _images = <Generation>[];
  List<Generation> _favoriteImages = <Generation>[];
  List<FavoriteItem> _favoritePrompts = <FavoriteItem>[];

  bool _loadingImages = false;
  bool _loadingFavorites = false;
  bool _showOnlyFavorites = false;
  bool _hasMore = true;
  int _page = 0;

  static const int _pageSize = 30;

  List<Generation> get images => _images;
  List<Generation> get favoriteImages => _favoriteImages;
  List<FavoriteItem> get favoritePrompts => _favoritePrompts;
  bool get loadingImages => _loadingImages;
  bool get loadingFavorites => _loadingFavorites;
  bool get showOnlyFavorites => _showOnlyFavorites;
  bool get hasMore => _hasMore;

  Future<void> loadImages({bool refresh = true}) async {
    if (refresh) {
      _page = 0;
      _hasMore = true;
      _loadingImages = true;
      notifyListeners();
    }
    try {
      final List<Generation> fresh = await _genRepo.listImageGenerations(
        limit: _pageSize,
        offset: _page * _pageSize,
        onlyFavorites: _showOnlyFavorites,
      );
      if (refresh) {
        _images = fresh;
      } else {
        _images = List<Generation>.from(_images)..addAll(fresh);
      }
      _hasMore = fresh.length >= _pageSize;
      if (refresh) _page = 1;
    } finally {
      _loadingImages = false;
      notifyListeners();
    }
  }

  Future<void> loadMoreImages() async {
    if (!_hasMore || _loadingImages) return;
    _page += 1;
    try {
      final List<Generation> fresh = await _genRepo.listImageGenerations(
        limit: _pageSize,
        offset: _page * _pageSize,
        onlyFavorites: _showOnlyFavorites,
      );
      _images = List<Generation>.from(_images)..addAll(fresh);
      _hasMore = fresh.length >= _pageSize;
      notifyListeners();
    } catch (_) {
      _page -= 1;
    }
  }

  Future<void> toggleShowOnlyFavorites() async {
    _showOnlyFavorites = !_showOnlyFavorites;
    await loadImages();
  }

  Future<void> toggleFavorite(Generation g) async {
    final bool next = !g.isFavorite;
    await _genRepo.setFavorite(g.id, next);
    _images = _images
        .map((Generation e) => e.id == g.id
            ? Generation(
                id: e.id,
                type: e.type,
                createdAt: e.createdAt,
                prompt: e.prompt,
                resultUrl: e.resultUrl,
                resultText: e.resultText,
                style: e.style,
                isFavorite: next,
              )
            : e)
        .toList();
    if (_showOnlyFavorites && !next) {
      _images = _images.where((Generation e) => e.id != g.id).toList();
    }
    notifyListeners();
  }

  Future<void> deleteImage(Generation g) async {
    await _genRepo.delete(g.id);
    _images = _images.where((Generation e) => e.id != g.id).toList();
    notifyListeners();
  }

  // ----- Text favorites -----

  Future<void> loadFavorites() async {
    _loadingFavorites = true;
    notifyListeners();
    try {
      _favoritePrompts = await _favRepo.listPrompts();
      _favoriteImages = await _genRepo.listImageGenerations(
        onlyFavorites: true,
        limit: 60,
      );
    } finally {
      _loadingFavorites = false;
      notifyListeners();
    }
  }

  Future<void> savePrompt(String title, String content) =>
      _favRepo.savePrompt(title, content);

  Future<void> removePromptFavorite(String id) async {
    await _favRepo.remove(id);
    _favoritePrompts =
        _favoritePrompts.where((FavoriteItem e) => e.id != id).toList();
    notifyListeners();
  }

  void clearAll() {
    _images = <Generation>[];
    _favoriteImages = <Generation>[];
    _favoritePrompts = <FavoriteItem>[];
    _showOnlyFavorites = false;
    _hasMore = true;
    _page = 0;
    notifyListeners();
  }
}
