// NABBEH AI — AI image editing (upload + instruction -> new image).
// POST /functions/v1/edit-image
// body: { image_base64, image_mime, instruction, style?, language? }

import {
  adminClient,
  aiImage,
  consume,
  COSTS,
  corsHeaders,
  fail,
  getProfile,
  json,
  refillIfNeeded,
  requireUser,
  saveGeneration,
  uploadToStorage,
} from "../_shared/utils.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return fail("bad_request", "method", "POST only", 405);
  }

  const auth = await requireUser(req);
  if (auth instanceof Response) return auth;
  const admin = adminClient();

  try {
    const body = await req.json();
    const imageBase64: string | null = body.image_base64 ?? null;
    const imageMime: string = (body.image_mime ?? "image/jpeg").toString();
    const instruction: string = (body.instruction ?? "").toString().trim();
    const style: string | null = body.style ? body.style.toString() : null;

    if (!imageBase64 || !instruction) {
      return fail("bad_request", "input", "image_base64 and instruction are required", 400);
    }

    let profile = await getProfile(admin, auth.user.id);
    if (!profile) return fail("unauthorized", "profile", "Profile missing", 401);
    profile = await refillIfNeeded(admin, profile);

    const result = await consume(admin, profile, "image", COSTS.edit);
    if (result instanceof Response) return result;

    const bytes = await aiImage({
      prompt: instruction,
      aspectRatio: "1:1",
      hd: profile.plan === "pro",
      sourceBase64: imageBase64,
      sourceMime: imageMime,
    });
    const url = await uploadToStorage(admin, auth.user.id, bytes);

    const generation = await saveGeneration(admin, auth.user.id, {
      type: "edit",
      prompt: instruction,
      result_url: url,
      style,
      metadata: { source_mime: imageMime },
    });

    return json({
      generation,
      image_url: url,
      credits_left: result.creditsLeft,
      plan: profile.plan,
    });
  } catch (e) {
    return fail("server", "ai", e instanceof Error ? e.message : String(e), 500);
  }
});
