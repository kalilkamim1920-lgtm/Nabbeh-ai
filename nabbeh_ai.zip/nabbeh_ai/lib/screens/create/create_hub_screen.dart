import 'package:flutter/material.dart';

import '../../l10n_helper.dart';
import '../../widgets/feature_card.dart';
import '../../core/theme/app_colors.dart';
import 'image_analysis_screen.dart';
import 'image_edit_screen.dart';
import 'image_generation_screen.dart';
import 'prompt_generator_screen.dart';

/// The "Create" tab — quick access to all AI creation tools.
class CreateHubScreen extends StatelessWidget {
  const CreateHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(s.createHubTitle),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(
              s.createHubSubtitle,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(color: Colors.grey.shade500),
            ),
            const SizedBox(height: 18),
            FeatureCard(
              title: s.featureImageTitle,
              subtitle: s.featureImageSubtitle,
              icon: Icons.palette_rounded,
              gradient: AppColors.imageGradient,
              wide: true,
              onTap: () => _push(context, const ImageGenerationScreen()),
            ),
            const SizedBox(height: 12),
            FeatureCard(
              title: s.featureEditTitle,
              subtitle: s.featureEditSubtitle,
              icon: Icons.edit_rounded,
              gradient: AppColors.editGradient,
              wide: true,
              onTap: () => _push(context, const ImageEditScreen()),
            ),
            const SizedBox(height: 12),
            FeatureCard(
              title: s.featureAnalyzeTitle,
              subtitle: s.featureAnalyzeSubtitle,
              icon: Icons.image_search_rounded,
              gradient: AppColors.analyzeGradient,
              wide: true,
              onTap: () => _push(context, const ImageAnalysisScreen()),
            ),
            const SizedBox(height: 12),
            FeatureCard(
              title: s.featurePromptTitle,
              subtitle: s.featurePromptSubtitle,
              icon: Icons.tips_and_updates_rounded,
              gradient: AppColors.promptGradient,
              wide: true,
              onTap: () => _push(context, const PromptGeneratorScreen()),
            ),
          ],
        ),
      ),
    );
  }

  void _push(BuildContext context, Widget page) {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (_) => page));
  }
}
