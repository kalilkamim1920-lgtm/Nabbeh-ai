-- ============================================================
-- NABBEH AI — Initial database schema
-- Run this in Supabase Dashboard -> SQL Editor -> New query
-- ============================================================

-- ---------- Extensions ----------
create extension if not exists pgcrypto;

-- ---------- Profiles ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  display_name text,
  avatar_url text,
  plan text not null default 'free' check (plan in ('free', 'pro')),
  credits integer not null default 25,
  last_refill_date date not null default current_date,
  is_anonymous boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- Conversations ----------
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text not null default 'Chat',
  last_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- Messages ----------
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null default '',
  image_url text,
  created_at timestamptz not null default now()
);

-- ---------- Generations (images, edits, analyses, prompts) ----------
create table if not exists public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  type text not null check (type in ('image', 'edit', 'analysis', 'prompt')),
  prompt text,
  result_url text,
  result_text text,
  style text,
  metadata jsonb default '{}'::jsonb,
  is_favorite boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Favorites (text items: saved prompts) ----------
create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  item_type text not null check (item_type in ('prompt', 'message')),
  item_id uuid,
  title text,
  content text,
  created_at timestamptz not null default now()
);

-- ---------- Daily usage counters ----------
create table if not exists public.usage_daily (
  user_id uuid not null references public.profiles (id) on delete cascade,
  day date not null default current_date,
  chat_count integer not null default 0,
  image_count integer not null default 0,
  primary key (user_id, day)
);

-- ---------- Credit transactions (audit trail) ----------
create table if not exists public.credit_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  amount integer not null,
  reason text not null,
  created_at timestamptz not null default now()
);

-- ---------- RevenueCat grant tracking (idempotency) ----------
create table if not exists public.rc_grants (
  user_id uuid not null references public.profiles (id) on delete cascade,
  product_id text not null,
  transaction_id text not null,
  granted_at timestamptz not null default now(),
  primary key (user_id, product_id, transaction_id)
);

-- ---------- Indexes ----------
create index if not exists idx_conversations_user on public.conversations (user_id, updated_at desc);
create index if not exists idx_messages_conversation on public.messages (conversation_id, created_at);
create index if not exists idx_generations_user on public.generations (user_id, created_at desc);
create index if not exists idx_favorites_user on public.favorites (user_id, created_at desc);

-- ============================================================
-- Row Level Security — users can only touch their own rows
-- ============================================================
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.generations enable row level security;
alter table public.favorites enable row level security;
alter table public.usage_daily enable row level security;
alter table public.credit_transactions enable row level security;
alter table public.rc_grants enable row level security;

-- Profiles
drop policy if exists "own profile select" on public.profiles;
create policy "own profile select" on public.profiles
  for select using (auth.uid () = id);
drop policy if exists "own profile update" on public.profiles;
create policy "own profile update" on public.profiles
  for update using (auth.uid () = id) with check (auth.uid () = id);

-- Conversations
drop policy if exists "own conversations all" on public.conversations;
create policy "own conversations all" on public.conversations
  for all using (auth.uid () = user_id) with check (auth.uid () = user_id);

-- Messages
drop policy if exists "own messages all" on public.messages;
create policy "own messages all" on public.messages
  for all using (auth.uid () = user_id) with check (auth.uid () = user_id);

-- Generations
drop policy if exists "own generations all" on public.generations;
create policy "own generations all" on public.generations
  for all using (auth.uid () = user_id) with check (auth.uid () = user_id);

-- Favorites
drop policy if exists "own favorites all" on public.favorites;
create policy "own favorites all" on public.favorites
  for all using (auth.uid () = user_id) with check (auth.uid () = user_id);

-- usage_daily: read-only for users (edge functions write with service role)
drop policy if exists "own usage select" on public.usage_daily;
create policy "own usage select" on public.usage_daily
  for select using (auth.uid () = user_id);

-- credit_transactions / rc_grants: read-only for users
drop policy if exists "own transactions select" on public.credit_transactions;
create policy "own transactions select" on public.credit_transactions
  for select using (auth.uid () = user_id);
drop policy if exists "own grants select" on public.rc_grants;
create policy "own grants select" on public.rc_grants
  for select using (auth.uid () = user_id);

-- ============================================================
-- Auto-create profile on sign-up (incl. anonymous users)
-- ============================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, display_name, is_anonymous)
  values (
    new.id,
    new.email,
    coalesce(
      new.raw_user_meta_data ->> 'display_name',
      split_part(coalesce(new.email, 'Guest'), '@', 1)
    ),
    new.is_anonymous
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- Storage bucket for AI-generated images (public read)
-- ============================================================
insert into storage.buckets (id, name, public)
values ('generations', 'generations', true)
on conflict (id) do nothing;

drop policy if exists "public read generations" on storage.objects;
create policy "public read generations" on storage.objects
  for select using (bucket_id = 'generations');

-- ============================================================
-- Keep conversations.updated_at fresh
-- ============================================================
create or replace function public.touch_conversation()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.conversations
  set updated_at = now(),
      last_message = left(new.content, 120)
  where id = new.conversation_id;
  return new;
end;
$$;

drop trigger if exists on_message_created on public.messages;
create trigger on_message_created
  after insert on public.messages
  for each row execute function public.touch_conversation();
