import 'package:shared_preferences/shared_preferences.dart';

/// Small typed wrapper over SharedPreferences for app-level settings.
class SettingsStorage {
  SettingsStorage._();

  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // ----- Theme -----
  static String get themeMode => _prefs.getString('theme_mode') ?? 'system';

  static Future<void> setThemeMode(String mode) =>
      _prefs.setString('theme_mode', mode);

  // ----- Locale -----
  static String get languageCode => _prefs.getString('language_code') ?? '';

  static Future<void> setLanguageCode(String code) =>
      _prefs.setString('language_code', code);

  // ----- Notifications toggle (in-app alerts) -----
  static bool get notificationsEnabled =>
      _prefs.getBool('notifications') ?? true;

  static Future<void> setNotificationsEnabled(bool v) =>
      _prefs.setBool('notifications', v);
}
