import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/errors/app_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/creation_provider.dart';
import '../../providers/settings_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/section_header.dart';
import '../../widgets/limit_sheet.dart';

/// Upload a photo + instruction -> AI-edited result.
class ImageEditScreen extends StatefulWidget {
  const ImageEditScreen({super.key});

  @override
  State<ImageEditScreen> createState() => _ImageEditScreenState();
}

class _ImageEditScreenState extends State<ImageEditScreen> {
  final TextEditingController _instruction = TextEditingController();

  Future<void> _pick() async {
    final CreationProvider creation = context.read<CreationProvider>();
    try {
      await creation.pickSourceImage(forAnalysis: false);
    } on AppException catch (e) {
      if (!mounted) return;
      Helpers.showSnack(
        context,
        e.type == AppErrorType.imageTooLarge
            ? S.of(context).imageTooLarge
            : S.of(context).uploadFailed,
        error: true,
      );
    }
  }

  Future<void> _apply() async {
    final CreationProvider creation = context.read<CreationProvider>();
    final SettingsProvider settings = context.read<SettingsProvider>();
    final S s = S.of(context);
    try {
      await creation.applyEdit(
        instruction: _instruction.text,
        language: settings.locale.languageCode,
      );
    } on AppException catch (e) {
      if (!mounted) return;
      if (e.isLimitReached) {
        await showLimitReachedSheet(context, e.type);
      } else {
        Helpers.showSnack(context, s.generationFailed, error: true);
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.networkError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final CreationProvider creation = context.watch<CreationProvider>();
    final Uint8List? source = creation.sourceBytes;

    return Scaffold(
      appBar: AppBar(title: Text(s.featureEditTitle)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Source image picker / preview
            GestureDetector(
              onTap: _pick,
              child: Container(
                height: 220,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Theme.of(context).dividerColor,
                    width: 1.4,
                  ),
                ),
                child: source == null
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.add_photo_alternate_outlined,
                              size: 42, color: AppColors.primary),
                          const SizedBox(height: 10),
                          Text(s.chooseImage,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600)),
                        ],
                      )
                    : Stack(
                        fit: StackFit.expand,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(18),
                            child: Image.memory(source, fit: BoxFit.cover),
                          ),
                          PositionedDirectional(
                            top: 10,
                            end: 10,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.black54,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                s.changeImage,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 12),
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 18),
            SectionHeader(title: s.editInstructionLabel),
            TextField(
              controller: _instruction,
              minLines: 2,
              maxLines: 4,
              decoration: InputDecoration(hintText: s.editInstructionHint),
            ),
            const SizedBox(height: 20),
            PrimaryButton(
              label: s.applyEdit,
              icon: Icons.auto_fix_high_rounded,
              onPressed:
                  source == null || _instruction.text.trim().isEmpty
                      ? null
                      : _apply,
              busy: creation.busy,
              gradient: AppColors.editGradient,
            ),
            const SizedBox(height: 24),
            if (creation.busy)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 14),
                    Text(s.applyingEdit,
                        style: TextStyle(color: Colors.grey.shade500)),
                  ],
                ),
              )
            else if (creation.editedImageUrl != null) ...[
              SectionHeader(title: s.imageDetails),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(
                  creation.editedImageUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => EmptyState(
                    icon: Icons.broken_image_outlined,
                    title: s.generationFailed,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () => Share.share(creation.editedImageUrl ?? ''),
                icon: const Icon(Icons.ios_share, size: 18),
                label: Text(s.share),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
