import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/constants/app_constants.dart';
import '../../core/errors/app_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/creation_provider.dart';
import '../../providers/settings_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/section_header.dart';
import '../../widgets/limit_sheet.dart';

/// Text -> Image with style + aspect ratio selection.
class ImageGenerationScreen extends StatefulWidget {
  const ImageGenerationScreen({super.key});

  @override
  State<ImageGenerationScreen> createState() => _ImageGenerationScreenState();
}

class _ImageGenerationScreenState extends State<ImageGenerationScreen> {
  final TextEditingController _prompt = TextEditingController();

  String _style = 'realistic';
  String _ratio = '1:1';

  @override
  void initState() {
    super.initState();
    final CreationProvider creation = context.read<CreationProvider>();
    _prompt.text = creation.lastPrompt ?? '';
  }

  @override
  void dispose() {
    _prompt.dispose();
    super.dispose();
  }

  String _styleLabel(S s, String id) {
    switch (id) {
      case 'realistic':
        return s.styleRealistic;
      case 'anime':
        return s.styleAnime;
      case 'digital_art':
        return s.styleDigitalArt;
      case '3d_render':
        return s.style3D;
      case 'watercolor':
        return s.styleWatercolor;
      case 'cyberpunk':
        return s.styleCyberpunk;
      case 'minimal':
        return s.styleMinimal;
      case 'logo':
        return s.styleLogo;
      default:
        return s.styleNone;
    }
  }

  String _ratioLabel(S s, String id) {
    switch (id) {
      case '16:9':
        return s.ratioLandscape;
      case '9:16':
        return s.ratioPortrait;
      default:
        return s.ratioSquare;
    }
  }

  Future<void> _generate() async {
    final CreationProvider creation = context.read<CreationProvider>();
    final SettingsProvider settings = context.read<SettingsProvider>();
    final S s = S.of(context);

    creation.setLastPrompt(_prompt.text);

    try {
      await creation.generateImage(
        prompt: _prompt.text,
        style: _style == 'none' ? null : _style,
        aspectRatio: _ratio,
        language: settings.locale.languageCode,
      );
    } on AppException catch (e) {
      if (!mounted) return;
      if (e.isLimitReached) {
        await showLimitReachedSheet(context, e.type);
      } else {
        Helpers.showSnack(context, s.generationFailed, error: true);
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.networkError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final CreationProvider creation = context.watch<CreationProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(s.featureImageTitle)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            SectionHeader(title: s.promptLabel),
            TextField(
              controller: _prompt,
              minLines: 3,
              maxLines: 6,
              decoration: InputDecoration(hintText: s.promptHint),
            ),
            const SizedBox(height: 18),
            SectionHeader(title: s.styleLabel),
            SizedBox(
              height: 42,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: AppConstants.imageStyles.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (BuildContext context, int index) {
                  final String id = AppConstants.imageStyles[index];
                  final bool selected = _style == id;
                  return ChoiceChip(
                    label: Text(_styleLabel(s, id)),
                    selected: selected,
                    onSelected: (_) => setState(() => _style = id),
                    showCheckmark: false,
                    labelStyle: TextStyle(
                      color: selected ? Colors.white : null,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.w500,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 18),
            SectionHeader(title: s.ratioLabel),
            Row(
              children: AppConstants.aspectRatios.map((String id) {
                final bool selected = _ratio == id;
                return Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ChoiceChip(
                    label: Text(_ratioLabel(s, id)),
                    selected: selected,
                    onSelected: (_) => setState(() => _ratio = id),
                    showCheckmark: false,
                    labelStyle: TextStyle(
                      color: selected ? Colors.white : null,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            PrimaryButton(
              label: s.generate,
              icon: Icons.auto_awesome,
              onPressed: _prompt.text.trim().isEmpty ? null : _generate,
              busy: creation.busy,
              gradient: AppColors.imageGradient,
            ),
            const SizedBox(height: 26),
            if (creation.busy)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 44),
                child: Column(
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 16),
                    Text(s.generatingImage,
                        style: TextStyle(color: Colors.grey.shade500)),
                  ],
                ),
              )
            else if (creation.generatedImageUrl != null) ...[
              SectionHeader(title: s.imageDetails),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(
                  creation.generatedImageUrl!,
                  fit: BoxFit.cover,
                  loadingBuilder: (BuildContext context, Widget child,
                      ImageChunkEvent? progress) {
                    if (progress == null) return child;
                    return AspectRatio(
                      aspectRatio: _ratio == '16:9'
                          ? 16 / 9
                          : _ratio == '9:16'
                              ? 9 / 16
                              : 1,
                      child: const Center(
                          child: CircularProgressIndicator()),
                    );
                  },
                  errorBuilder: (_, __, ___) => EmptyState(
                    icon: Icons.broken_image_outlined,
                    title: s.generationFailed,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _share(),
                      icon: const Icon(Icons.ios_share, size: 18),
                      label: Text(s.share),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _regenerate,
                      icon: const Icon(Icons.refresh_rounded, size: 18),
                      label: Text(s.retry),
                    ),
                  ),
                ],
              ),
            ]
            else
              const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _regenerate() {
    if (_prompt.text.trim().isNotEmpty) _generate();
  }

  Future<void> _share() async {
    final CreationProvider creation = context.read<CreationProvider>();
    final String url = creation.generatedImageUrl ?? '';
    if (url.isEmpty) return;
    await Share.share(url);
  }
}
