// NABBEH AI — verify RevenueCat entitlement and sync the profile.
// POST /functions/v1/sync-subscription
// body: { demo?: boolean }
//
// - Real mode: queries RevenueCat REST API with the SECRET key and syncs
//   profiles.plan + grants one-time credit packs (idempotent).
// - Demo mode: only allowed while REVENUECAT_SECRET_API_KEY is NOT set,
//   so developers can test PRO flows before configuring RevenueCat.

import {
  adminClient,
  corsHeaders,
  fail,
  getProfile,
  json,
  requireUser,
} from "../_shared/utils.ts";

const CREDIT_PACKS: Record<string, number> = {
  nabbeh_credits_small: 100,
  nabbeh_credits_medium: 500,
  nabbeh_credits_large: 1500,
};

interface RcEntitlement {
  expires_date?: string | null;
}
interface RcSubscriber {
  entitlements?: Record<string, RcEntitlement>;
  non_subscriptions?: Record<string, Array<{ product_id: string; transaction_id: string; purchased_date_ms?: number }>>;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return fail("bad_request", "method", "POST only", 405);
  }

  const auth = await requireUser(req);
  if (auth instanceof Response) return auth;
  const admin = adminClient();

  const secretKey = Deno.env.get("REVENUECAT_SECRET_API_KEY") ?? "";

  try {
    const body = await req.json().catch(() => ({}));
    const demoRequested = (body?.demo ?? false) === true;

    let profile = await getProfile(admin, auth.user.id);
    if (!profile) return fail("unauthorized", "profile", "Profile missing", 401);

    // ----- Demo mode (dev only, before RevenueCat is configured) -----
    if (!secretKey) {
      if (demoRequested) {
        const { data } = await admin
          .from("profiles")
          .update({ plan: "pro" })
          .eq("id", profile.id)
          .select()
          .single();
        return json({ profile: data ?? { ...profile, plan: "pro" }, demo: true });
      }
      return json({ profile, demo: true });
    }

    // ----- Real mode: verify with RevenueCat -----
    const res = await fetch(
      `https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(auth.user.id)}`,
      {
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json",
        },
      },
    );

    if (res.status === 404) {
      // Unknown RevenueCat user — treat as free.
      await admin.from("profiles").update({ plan: "free" }).eq("id", profile.id);
      const fresh = await getProfile(admin, auth.user.id);
      return json({ profile: fresh ?? { ...profile, plan: "free" } });
    }
    if (!res.ok) {
      return fail("server", "revenuecat", `RevenueCat error ${res.status}`, 500);
    }

    const payload = (await res.json()) as { subscriber?: RcSubscriber };
    const subscriber = payload.subscriber ?? {};

    // 1) PRO entitlement
    const pro = subscriber.entitlements?.["pro_access"];
    const isPro =
      !!pro?.expires_date && new Date(pro.expires_date).getTime() > Date.now();

    // 2) Credit packs (one-time purchases) — grant once
    let granted = 0;
    const nonSubs = subscriber.non_subscriptions ?? {};
    for (const entries of Object.values(nonSubs)) {
      for (const entry of entries ?? []) {
        const credits = CREDIT_PACKS[entry.product_id];
        if (!credits || !entry.transaction_id) continue;
        const { data: existing } = await admin
          .from("rc_grants")
          .select("user_id")
          .eq("user_id", auth.user.id)
          .eq("product_id", entry.product_id)
          .eq("transaction_id", entry.transaction_id)
          .maybeSingle();
        if (existing) continue;
        const { error: grantError } = await admin
          .from("profiles")
          .update({ credits: profile.credits + granted + credits })
          .eq("id", auth.user.id);
        if (grantError) continue;
        await admin.from("rc_grants").insert({
          user_id: auth.user.id,
          product_id: entry.product_id,
          transaction_id: entry.transaction_id,
        });
        await admin.from("credit_transactions").insert({
          user_id: auth.user.id,
          amount: credits,
          reason: `credit_pack:${entry.product_id}`,
        });
        granted += credits;
      }
    }

    await admin
      .from("profiles")
      .update({ plan: isPro ? "pro" : "free" })
      .eq("id", auth.user.id);

    profile = await getProfile(admin, auth.user.id);
    return json({ profile, granted_credits: granted });
  } catch (e) {
    return fail("server", "sync", e instanceof Error ? e.message : String(e), 500);
  }
});
