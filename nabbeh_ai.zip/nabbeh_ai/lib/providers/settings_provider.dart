import 'package:flutter/material.dart';

import '../services/settings_storage.dart';

/// Theme mode + language, persisted across restarts.
class SettingsProvider extends ChangeNotifier {
  SettingsProvider() {
    _restore();
  }

  ThemeMode _themeMode = ThemeMode.system;
  Locale _locale = const Locale('en');

  ThemeMode get themeMode => _themeMode;
  Locale get locale => _locale;

  void _restore() {
    switch (SettingsStorage.themeMode) {
      case 'light':
        _themeMode = ThemeMode.light;
        break;
      case 'dark':
        _themeMode = ThemeMode.dark;
        break;
      default:
        _themeMode = ThemeMode.system;
    }

    final String saved = SettingsStorage.languageCode;
    if (saved == 'ar' || saved == 'en') {
      _locale = Locale(saved);
    } else {
      // Follow the system language; default to Arabic if unsupported.
      final Locale device =
          WidgetsBinding.instance.platformDispatcher.locale;
      _locale = device.languageCode == 'ar'
          ? const Locale('ar')
          : device.languageCode == 'en'
              ? const Locale('en')
              : const Locale('ar');
    }
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    notifyListeners();
    await SettingsStorage.setThemeMode(mode.name);
  }

  Future<void> setLocale(Locale locale) async {
    _locale = locale;
    notifyListeners();
    await SettingsStorage.setLanguageCode(locale.languageCode);
  }
}
