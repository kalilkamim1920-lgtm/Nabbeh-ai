import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/chat_message.dart';
import '../models/conversation.dart';
import '../services/supabase_service.dart';

/// Conversations & messages persistence.
class ChatRepository {
  const ChatRepository();

  SupabaseClient get _client => SupabaseService.client;
  String? get _uid => SupabaseService.currentUser?.id;

  Future<List<Conversation>> listConversations({int limit = 100}) async {
    final String? uid = _uid;
    if (uid == null) return [];
    final List<dynamic> rows = await _client
        .from('conversations')
        .select()
        .eq('user_id', uid)
        .order('updated_at', ascending: false)
        .limit(limit);
    return rows
        .map((e) => Conversation.fromMap(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<ChatMessage>> listMessages(
    String conversationId, {
    int limit = 100,
  }) async {
    final List<dynamic> rows = await _client
        .from('messages')
        .select()
        .eq('conversation_id', conversationId)
        .order('created_at', ascending: true)
        .limit(limit);
    return rows
        .map((e) => ChatMessage.fromMap(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<ChatMessage>> deleteConversation(String conversationId) async {
    await _client.from('conversations').delete().eq('id', conversationId);
    return [];
  }

  /// Local optimistic user message (server persists the real ones).
  ChatMessage buildPendingMessage({
    required String conversationId,
    required String content,
    String? imageUrl,
  }) {
    return ChatMessage.pending(
      conversationId: conversationId,
      role: 'user',
      content: content,
      imageUrl: imageUrl,
    );
  }
}
