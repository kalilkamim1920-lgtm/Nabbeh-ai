/// A single chat message — mirrors the `messages` table.
class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    this.imageUrl,
    required this.createdAt,
  });

  final String id;
  final String conversationId;
  final String role; // 'user' | 'assistant'
  final String content;
  final String? imageUrl;
  final DateTime createdAt;

  bool get isUser => role == 'user';

  /// Local, optimistic message (before the server confirms it).
  factory ChatMessage.pending({
    required String conversationId,
    required String role,
    required String content,
    String? imageUrl,
  }) {
    return ChatMessage(
      id: 'pending-${DateTime.now().microsecondsSinceEpoch}',
      conversationId: conversationId,
      role: role,
      content: content,
      imageUrl: imageUrl,
      createdAt: DateTime.now(),
    );
  }

  factory ChatMessage.fromMap(Map<String, dynamic> map) {
    return ChatMessage(
      id: (map['id'] ?? '').toString(),
      conversationId: (map['conversation_id'] ?? '').toString(),
      role: (map['role'] ?? 'assistant').toString(),
      content: (map['content'] ?? '').toString(),
      imageUrl: map['image_url'] as String?,
      createdAt: DateTime.tryParse('${map['created_at']}') ??
          DateTime.now(),
    );
  }
}
