import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../l10n_helper.dart';
import '../../providers/auth_provider.dart';
import '../../providers/gallery_provider.dart';
import '../../widgets/credit_chip.dart';
import '../../widgets/promo_banner.dart';
import '../../widgets/section_header.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../models/generation.dart';
import '../../widgets/feature_card.dart';
import '../create/image_analysis_screen.dart';
import '../create/image_edit_screen.dart';
import '../create/image_generation_screen.dart';
import '../create/prompt_generator_screen.dart';
import '../gallery/gallery_screen.dart';
import '../paywall/paywall_screen.dart';
import '../chat/chat_screen.dart';

/// Home: greeting, credits, the five feature cards, recent creations.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final AuthProvider auth = context.watch<AuthProvider>();
    final GalleryProvider gallery = context.watch<GalleryProvider>();

    final List<Generation> recent =
        gallery.images.take(6).toList(growable: false);

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () async {
          await gallery.loadImages();
        },
        child: CustomScrollView(
          slivers: <Widget>[
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${s.homeWelcome}, ${Helpers.clamp(auth.profile?.name ?? s.guestAccount, 14)} 👋',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(fontSize: 22),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                s.homeTagline,
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(color: Colors.grey.shade500),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        CreditChip(
                          credits: auth.credits,
                          onTap: () =>
                              _openPaywall(context, focusCredits: true),
                        ),
                      ],
                    ),
                    if (!auth.isPro) ...[
                      const SizedBox(height: 16),
                      PromoBanner(
                        onUpgrade: () =>
                            _openPaywall(context, focusCredits: false),
                      ),
                    ],
                    const SizedBox(height: 22),
                    SectionHeader(title: s.tabCreate),
                    _HomeCardPair(
                      left: FeatureCard(
                        title: s.featureChatTitle,
                        subtitle: s.featureChatSubtitle,
                        icon: Icons.chat_bubble_rounded,
                        gradient: AppColors.chatGradient,
                        onTap: () => _goChat(context),
                      ),
                      right: FeatureCard(
                        title: s.featureImageTitle,
                        subtitle: s.featureImageSubtitle,
                        icon: Icons.palette_rounded,
                        gradient: AppColors.imageGradient,
                        onTap: () => _push(context,
                            const ImageGenerationScreen()),
                      ),
                    ),
                    const SizedBox(height: 12),
                    _HomeCardPair(
                      left: FeatureCard(
                        title: s.featureEditTitle,
                        subtitle: s.featureEditSubtitle,
                        icon: Icons.edit_rounded,
                        gradient: AppColors.editGradient,
                        onTap: () => _push(context, const ImageEditScreen()),
                      ),
                      right: FeatureCard(
                        title: s.featureAnalyzeTitle,
                        subtitle: s.featureAnalyzeSubtitle,
                        icon: Icons.image_search_rounded,
                        gradient: AppColors.analyzeGradient,
                        onTap: () =>
                            _push(context, const ImageAnalysisScreen()),
                      ),
                    ),
                    const SizedBox(height: 12),
                    FeatureCard(
                      title: s.featurePromptTitle,
                      subtitle: s.featurePromptSubtitle,
                      icon: Icons.tips_and_updates_rounded,
                      gradient: AppColors.promptGradient,
                      wide: true,
                      onTap: () =>
                          _push(context, const PromptGeneratorScreen()),
                    ),
                    const SizedBox(height: 24),
                    SectionHeader(
                      title: s.recentCreations,
                      actionLabel: s.seeAll,
                      onAction: () => _push(context, const GalleryScreen()),
                    ),
                  ],
                ),
              ),
            ),
            if (recent.isEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Column(
                    children: [
                      Icon(Icons.image_not_supported_outlined,
                          size: 44, color: Colors.grey.shade400),
                      const SizedBox(height: 10),
                      Text(
                        s.noCreationsYet,
                        style: TextStyle(color: Colors.grey.shade500),
                      ),
                    ],
                  ),
                ),
              )
            else
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 150,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: recent.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (BuildContext context, int index) {
                      return ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: SizedBox(
                          width: 130,
                          child: Image.network(
                            recent[index].resultUrl ?? '',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: Theme.of(context).dividerColor,
                              child: const Icon(Icons.broken_image_outlined),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            const SliverToBoxAdapter(
              child: SizedBox(height: 32),
            ),
          ],
        ),
      ),
    );
  }

  void _push(BuildContext context, Widget page) {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (_) => page));
  }

  void _goChat(BuildContext context) {
    // Chat lives in the bottom-nav shell; reuse the standalone chat screen.
    _push(context, const ChatScreen());
  }

  void _openPaywall(BuildContext context, {required bool focusCredits}) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => PaywallScreen(focusCreditPacks: focusCredits),
    ));
  }
}

class _HomeCardPair extends StatelessWidget {
  const _HomeCardPair({required this.left, required this.right});

  final Widget left;
  final Widget right;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(child: left),
        const SizedBox(width: 12),
        Expanded(child: right),
      ],
    );
  }
}
