/// An AI creation record — mirrors the `generations` table.
/// Covers generated images, edited images, analyses and saved prompts.
class Generation {
  const Generation({
    required this.id,
    required this.type,
    required this.createdAt,
    this.prompt,
    this.resultUrl,
    this.resultText,
    this.style,
    this.isFavorite = false,
  });

  final String id;

  /// 'image' | 'edit' | 'analysis' | 'prompt'
  final String type;
  final String? prompt;
  final String? resultUrl;
  final String? resultText;
  final String? style;
  final bool isFavorite;
  final DateTime createdAt;

  bool get hasImage =>
      (type == 'image' || type == 'edit') &&
      resultUrl != null &&
      resultUrl!.isNotEmpty;

  factory Generation.fromMap(Map<String, dynamic> map) {
    return Generation(
      id: (map['id'] ?? '').toString(),
      type: (map['type'] ?? 'image').toString(),
      prompt: map['prompt'] as String?,
      resultUrl: map['result_url'] as String?,
      resultText: map['result_text'] as String?,
      style: map['style'] as String?,
      isFavorite: (map['is_favorite'] ?? false) == true,
      createdAt: DateTime.tryParse('${map['created_at']}') ??
          DateTime.now(),
    );
  }
}
