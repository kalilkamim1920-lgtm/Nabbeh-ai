import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

/// NABBEH AI logo mark — gradient rounded square with a spark.
class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 64, this.showText = false});

  final double size;
  final bool showText;

  @override
  Widget build(BuildContext context) {
    final Widget mark = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: AppColors.brandGradient,
        borderRadius: BorderRadius.circular(size * 0.3),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withAlpha(90),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Icon(
        Icons.auto_awesome,
        color: Colors.white,
        size: size * 0.52,
      ),
    );

    if (!showText) return mark;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        mark,
        const SizedBox(height: 16),
        Text(
          'NABBEH AI',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
              ),
        ),
      ],
    );
  }
}
