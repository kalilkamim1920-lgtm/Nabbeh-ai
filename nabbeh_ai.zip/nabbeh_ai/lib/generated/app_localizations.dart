import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of S
/// returned by `S.of(context)`.
///
/// Applications need to include `S.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: S.localizationsDelegates,
///   supportedLocales: S.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the S.supportedLocales
/// property.
abstract class S {
  S(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static S of(BuildContext context) {
    return Localizations.of<S>(context, S)!;
  }

  static const LocalizationsDelegate<S> delegate = _SDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @appName.
  ///
  /// In en, this message translates to:
  /// **'NABBEH AI'**
  String get appName;

  /// No description provided for @ok.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get ok;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @share.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get share;

  /// No description provided for @copy.
  ///
  /// In en, this message translates to:
  /// **'Copy'**
  String get copy;

  /// No description provided for @done.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get done;

  /// No description provided for @retry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retry;

  /// No description provided for @close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// No description provided for @loading.
  ///
  /// In en, this message translates to:
  /// **'Loading…'**
  String get loading;

  /// No description provided for @errorGeneric.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong. Please try again.'**
  String get errorGeneric;

  /// No description provided for @success.
  ///
  /// In en, this message translates to:
  /// **'Done successfully'**
  String get success;

  /// No description provided for @seeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get seeAll;

  /// No description provided for @copiedToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Copied to clipboard'**
  String get copiedToClipboard;

  /// No description provided for @comingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon'**
  String get comingSoon;

  /// No description provided for @loginRequired.
  ///
  /// In en, this message translates to:
  /// **'Sign in required'**
  String get loginRequired;

  /// No description provided for @signInToContinue.
  ///
  /// In en, this message translates to:
  /// **'Please sign in to continue'**
  String get signInToContinue;

  /// No description provided for @tabHome.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get tabHome;

  /// No description provided for @tabChat.
  ///
  /// In en, this message translates to:
  /// **'Chat'**
  String get tabChat;

  /// No description provided for @tabCreate.
  ///
  /// In en, this message translates to:
  /// **'Create'**
  String get tabCreate;

  /// No description provided for @tabHistory.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get tabHistory;

  /// No description provided for @tabProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get tabProfile;

  /// No description provided for @homeWelcome.
  ///
  /// In en, this message translates to:
  /// **'Welcome back'**
  String get homeWelcome;

  /// No description provided for @homeTagline.
  ///
  /// In en, this message translates to:
  /// **'What would you like to create today?'**
  String get homeTagline;

  /// No description provided for @creditsLabel.
  ///
  /// In en, this message translates to:
  /// **'{count} credits'**
  String creditsLabel(int count);

  /// No description provided for @upgradeBannerTitle.
  ///
  /// In en, this message translates to:
  /// **'Unlock NABBEH PRO'**
  String get upgradeBannerTitle;

  /// No description provided for @upgradeBannerSubtitle.
  ///
  /// In en, this message translates to:
  /// **'More messages, HD images, no ads'**
  String get upgradeBannerSubtitle;

  /// No description provided for @upgradeNow.
  ///
  /// In en, this message translates to:
  /// **'Upgrade now'**
  String get upgradeNow;

  /// No description provided for @featureChatTitle.
  ///
  /// In en, this message translates to:
  /// **'Chat with AI'**
  String get featureChatTitle;

  /// No description provided for @featureChatSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Smart conversations in Arabic & English'**
  String get featureChatSubtitle;

  /// No description provided for @featureImageTitle.
  ///
  /// In en, this message translates to:
  /// **'Create Image'**
  String get featureImageTitle;

  /// No description provided for @featureImageSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Turn your words into stunning art'**
  String get featureImageSubtitle;

  /// No description provided for @featureEditTitle.
  ///
  /// In en, this message translates to:
  /// **'Edit Image'**
  String get featureEditTitle;

  /// No description provided for @featureEditSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Modify any photo with AI'**
  String get featureEditSubtitle;

  /// No description provided for @featureAnalyzeTitle.
  ///
  /// In en, this message translates to:
  /// **'Analyze Image'**
  String get featureAnalyzeTitle;

  /// No description provided for @featureAnalyzeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Upload a photo and ask about it'**
  String get featureAnalyzeSubtitle;

  /// No description provided for @featurePromptTitle.
  ///
  /// In en, this message translates to:
  /// **'Create Prompt'**
  String get featurePromptTitle;

  /// No description provided for @featurePromptSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Craft perfect prompts for any AI model'**
  String get featurePromptSubtitle;

  /// No description provided for @recentCreations.
  ///
  /// In en, this message translates to:
  /// **'Recent creations'**
  String get recentCreations;

  /// No description provided for @noCreationsYet.
  ///
  /// In en, this message translates to:
  /// **'Your creations will appear here'**
  String get noCreationsYet;

  /// No description provided for @loginTitle.
  ///
  /// In en, this message translates to:
  /// **'Welcome to NABBEH AI'**
  String get loginTitle;

  /// No description provided for @loginSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Sign in to unlock the full power of AI'**
  String get loginSubtitle;

  /// No description provided for @createAccountTitle.
  ///
  /// In en, this message translates to:
  /// **'Create your account'**
  String get createAccountTitle;

  /// No description provided for @fullName.
  ///
  /// In en, this message translates to:
  /// **'Full name'**
  String get fullName;

  /// No description provided for @fullNameHint.
  ///
  /// In en, this message translates to:
  /// **'Your name'**
  String get fullNameHint;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @emailHint.
  ///
  /// In en, this message translates to:
  /// **'you@example.com'**
  String get emailHint;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @passwordHint.
  ///
  /// In en, this message translates to:
  /// **'At least 6 characters'**
  String get passwordHint;

  /// No description provided for @confirmPassword.
  ///
  /// In en, this message translates to:
  /// **'Confirm password'**
  String get confirmPassword;

  /// No description provided for @signIn.
  ///
  /// In en, this message translates to:
  /// **'Sign in'**
  String get signIn;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign up'**
  String get signUp;

  /// No description provided for @forgotPassword.
  ///
  /// In en, this message translates to:
  /// **'Forgot password?'**
  String get forgotPassword;

  /// No description provided for @resetPassword.
  ///
  /// In en, this message translates to:
  /// **'Reset password'**
  String get resetPassword;

  /// No description provided for @resetPasswordSent.
  ///
  /// In en, this message translates to:
  /// **'Password reset email sent'**
  String get resetPasswordSent;

  /// No description provided for @resetPasswordBody.
  ///
  /// In en, this message translates to:
  /// **'Check your inbox for the reset link.'**
  String get resetPasswordBody;

  /// No description provided for @continueAsGuest.
  ///
  /// In en, this message translates to:
  /// **'Continue as guest'**
  String get continueAsGuest;

  /// No description provided for @guestNote.
  ///
  /// In en, this message translates to:
  /// **'You can create an account later to keep your data safe.'**
  String get guestNote;

  /// No description provided for @authFailed.
  ///
  /// In en, this message translates to:
  /// **'Authentication failed'**
  String get authFailed;

  /// No description provided for @errEmailInvalid.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email'**
  String get errEmailInvalid;

  /// No description provided for @errPasswordShort.
  ///
  /// In en, this message translates to:
  /// **'Password must be at least 6 characters'**
  String get errPasswordShort;

  /// No description provided for @errPasswordMismatch.
  ///
  /// In en, this message translates to:
  /// **'Passwords do not match'**
  String get errPasswordMismatch;

  /// No description provided for @errNameRequired.
  ///
  /// In en, this message translates to:
  /// **'Please enter your name'**
  String get errNameRequired;

  /// No description provided for @errWrongCredentials.
  ///
  /// In en, this message translates to:
  /// **'Wrong email or password'**
  String get errWrongCredentials;

  /// No description provided for @errEmailTaken.
  ///
  /// In en, this message translates to:
  /// **'This email is already registered'**
  String get errEmailTaken;

  /// No description provided for @errTooManyRequests.
  ///
  /// In en, this message translates to:
  /// **'Too many attempts. Please wait and try again.'**
  String get errTooManyRequests;

  /// No description provided for @errNetwork.
  ///
  /// In en, this message translates to:
  /// **'Network error. Check your connection.'**
  String get errNetwork;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Sign out'**
  String get logout;

  /// No description provided for @logoutConfirm.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to sign out?'**
  String get logoutConfirm;

  /// No description provided for @chatTitle.
  ///
  /// In en, this message translates to:
  /// **'AI Chat'**
  String get chatTitle;

  /// No description provided for @newChat.
  ///
  /// In en, this message translates to:
  /// **'New chat'**
  String get newChat;

  /// No description provided for @chatEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'Start a conversation'**
  String get chatEmptyTitle;

  /// No description provided for @chatEmptySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Ask anything — ideas, writing, code, translations…'**
  String get chatEmptySubtitle;

  /// No description provided for @typeMessage.
  ///
  /// In en, this message translates to:
  /// **'Type your message…'**
  String get typeMessage;

  /// No description provided for @send.
  ///
  /// In en, this message translates to:
  /// **'Send'**
  String get send;

  /// No description provided for @attachImage.
  ///
  /// In en, this message translates to:
  /// **'Attach image'**
  String get attachImage;

  /// No description provided for @aiThinking.
  ///
  /// In en, this message translates to:
  /// **'NABBEH is thinking…'**
  String get aiThinking;

  /// No description provided for @conversationsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No conversations yet'**
  String get conversationsEmpty;

  /// No description provided for @deleteConversationTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete conversation?'**
  String get deleteConversationTitle;

  /// No description provided for @deleteConversationBody.
  ///
  /// In en, this message translates to:
  /// **'This conversation and its messages will be removed.'**
  String get deleteConversationBody;

  /// No description provided for @imageAttached.
  ///
  /// In en, this message translates to:
  /// **'Image attached'**
  String get imageAttached;

  /// No description provided for @createHubTitle.
  ///
  /// In en, this message translates to:
  /// **'AI Studio'**
  String get createHubTitle;

  /// No description provided for @createHubSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Everything you need to create with AI'**
  String get createHubSubtitle;

  /// No description provided for @promptLabel.
  ///
  /// In en, this message translates to:
  /// **'Prompt'**
  String get promptLabel;

  /// No description provided for @promptHint.
  ///
  /// In en, this message translates to:
  /// **'Describe what you want to create…'**
  String get promptHint;

  /// No description provided for @styleLabel.
  ///
  /// In en, this message translates to:
  /// **'Style'**
  String get styleLabel;

  /// No description provided for @ratioLabel.
  ///
  /// In en, this message translates to:
  /// **'Aspect ratio'**
  String get ratioLabel;

  /// No description provided for @generate.
  ///
  /// In en, this message translates to:
  /// **'Generate'**
  String get generate;

  /// No description provided for @generatingImage.
  ///
  /// In en, this message translates to:
  /// **'Generating your image…'**
  String get generatingImage;

  /// No description provided for @generationFailed.
  ///
  /// In en, this message translates to:
  /// **'Image generation failed'**
  String get generationFailed;

  /// No description provided for @savedToGallery.
  ///
  /// In en, this message translates to:
  /// **'Saved to your gallery'**
  String get savedToGallery;

  /// No description provided for @styleRealistic.
  ///
  /// In en, this message translates to:
  /// **'Realistic'**
  String get styleRealistic;

  /// No description provided for @styleAnime.
  ///
  /// In en, this message translates to:
  /// **'Anime'**
  String get styleAnime;

  /// No description provided for @styleDigitalArt.
  ///
  /// In en, this message translates to:
  /// **'Digital Art'**
  String get styleDigitalArt;

  /// No description provided for @style3D.
  ///
  /// In en, this message translates to:
  /// **'3D Render'**
  String get style3D;

  /// No description provided for @styleWatercolor.
  ///
  /// In en, this message translates to:
  /// **'Watercolor'**
  String get styleWatercolor;

  /// No description provided for @styleCyberpunk.
  ///
  /// In en, this message translates to:
  /// **'Cyberpunk'**
  String get styleCyberpunk;

  /// No description provided for @styleMinimal.
  ///
  /// In en, this message translates to:
  /// **'Minimal'**
  String get styleMinimal;

  /// No description provided for @styleLogo.
  ///
  /// In en, this message translates to:
  /// **'Logo'**
  String get styleLogo;

  /// No description provided for @styleNone.
  ///
  /// In en, this message translates to:
  /// **'None'**
  String get styleNone;

  /// No description provided for @ratioSquare.
  ///
  /// In en, this message translates to:
  /// **'Square'**
  String get ratioSquare;

  /// No description provided for @ratioLandscape.
  ///
  /// In en, this message translates to:
  /// **'Landscape'**
  String get ratioLandscape;

  /// No description provided for @ratioPortrait.
  ///
  /// In en, this message translates to:
  /// **'Portrait'**
  String get ratioPortrait;

  /// No description provided for @editInstructionLabel.
  ///
  /// In en, this message translates to:
  /// **'What should I change?'**
  String get editInstructionLabel;

  /// No description provided for @editInstructionHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Change the background to a beach at sunset'**
  String get editInstructionHint;

  /// No description provided for @chooseImage.
  ///
  /// In en, this message translates to:
  /// **'Choose image'**
  String get chooseImage;

  /// No description provided for @changeImage.
  ///
  /// In en, this message translates to:
  /// **'Change image'**
  String get changeImage;

  /// No description provided for @applyEdit.
  ///
  /// In en, this message translates to:
  /// **'Apply AI edit'**
  String get applyEdit;

  /// No description provided for @applyingEdit.
  ///
  /// In en, this message translates to:
  /// **'Applying your edit…'**
  String get applyingEdit;

  /// No description provided for @analyzeQuestionLabel.
  ///
  /// In en, this message translates to:
  /// **'Your question (optional)'**
  String get analyzeQuestionLabel;

  /// No description provided for @analyzeQuestionHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. What is in this image?'**
  String get analyzeQuestionHint;

  /// No description provided for @analyzeImage.
  ///
  /// In en, this message translates to:
  /// **'Analyze image'**
  String get analyzeImage;

  /// No description provided for @analyzing.
  ///
  /// In en, this message translates to:
  /// **'Analyzing your image…'**
  String get analyzing;

  /// No description provided for @analysisResult.
  ///
  /// In en, this message translates to:
  /// **'Analysis result'**
  String get analysisResult;

  /// No description provided for @promptIdeaLabel.
  ///
  /// In en, this message translates to:
  /// **'Your idea'**
  String get promptIdeaLabel;

  /// No description provided for @promptIdeaHint.
  ///
  /// In en, this message translates to:
  /// **'Describe your idea in simple words…'**
  String get promptIdeaHint;

  /// No description provided for @platformLabel.
  ///
  /// In en, this message translates to:
  /// **'Target platform'**
  String get platformLabel;

  /// No description provided for @platformMidjourney.
  ///
  /// In en, this message translates to:
  /// **'Midjourney'**
  String get platformMidjourney;

  /// No description provided for @platformStableDiffusion.
  ///
  /// In en, this message translates to:
  /// **'Stable Diffusion'**
  String get platformStableDiffusion;

  /// No description provided for @platformDalle.
  ///
  /// In en, this message translates to:
  /// **'DALL·E'**
  String get platformDalle;

  /// No description provided for @platformGeneric.
  ///
  /// In en, this message translates to:
  /// **'Generic'**
  String get platformGeneric;

  /// No description provided for @generatePrompts.
  ///
  /// In en, this message translates to:
  /// **'Generate prompts'**
  String get generatePrompts;

  /// No description provided for @promptsResult.
  ///
  /// In en, this message translates to:
  /// **'Suggested prompts'**
  String get promptsResult;

  /// No description provided for @savePrompt.
  ///
  /// In en, this message translates to:
  /// **'Save prompt'**
  String get savePrompt;

  /// No description provided for @promptSaved.
  ///
  /// In en, this message translates to:
  /// **'Prompt saved to favorites'**
  String get promptSaved;

  /// No description provided for @historyConversationsTab.
  ///
  /// In en, this message translates to:
  /// **'Chats'**
  String get historyConversationsTab;

  /// No description provided for @historyImagesTab.
  ///
  /// In en, this message translates to:
  /// **'Images'**
  String get historyImagesTab;

  /// No description provided for @historyEmptyImages.
  ///
  /// In en, this message translates to:
  /// **'No generated images yet'**
  String get historyEmptyImages;

  /// No description provided for @historyEmptyConversations.
  ///
  /// In en, this message translates to:
  /// **'No conversations yet'**
  String get historyEmptyConversations;

  /// No description provided for @galleryTitle.
  ///
  /// In en, this message translates to:
  /// **'My Gallery'**
  String get galleryTitle;

  /// No description provided for @favoritesTitle.
  ///
  /// In en, this message translates to:
  /// **'Favorites'**
  String get favoritesTitle;

  /// No description provided for @favTabImages.
  ///
  /// In en, this message translates to:
  /// **'Images'**
  String get favTabImages;

  /// No description provided for @favTabPrompts.
  ///
  /// In en, this message translates to:
  /// **'Prompts'**
  String get favTabPrompts;

  /// No description provided for @noFavoritesYet.
  ///
  /// In en, this message translates to:
  /// **'Nothing here yet. Tap the star on any item to save it.'**
  String get noFavoritesYet;

  /// No description provided for @copyPrompt.
  ///
  /// In en, this message translates to:
  /// **'Copy prompt'**
  String get copyPrompt;

  /// No description provided for @deleteImageTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete this image?'**
  String get deleteImageTitle;

  /// No description provided for @deleteImageBody.
  ///
  /// In en, this message translates to:
  /// **'It will be removed from your gallery permanently.'**
  String get deleteImageBody;

  /// No description provided for @imageDetails.
  ///
  /// In en, this message translates to:
  /// **'Image details'**
  String get imageDetails;

  /// No description provided for @favoriteAdded.
  ///
  /// In en, this message translates to:
  /// **'Added to favorites'**
  String get favoriteAdded;

  /// No description provided for @favoriteRemoved.
  ///
  /// In en, this message translates to:
  /// **'Removed from favorites'**
  String get favoriteRemoved;

  /// No description provided for @profileTitle.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get profileTitle;

  /// No description provided for @planFree.
  ///
  /// In en, this message translates to:
  /// **'FREE'**
  String get planFree;

  /// No description provided for @planPro.
  ///
  /// In en, this message translates to:
  /// **'PRO'**
  String get planPro;

  /// No description provided for @creditsBalance.
  ///
  /// In en, this message translates to:
  /// **'Credits balance'**
  String get creditsBalance;

  /// No description provided for @manageSubscription.
  ///
  /// In en, this message translates to:
  /// **'Manage subscription'**
  String get manageSubscription;

  /// No description provided for @myFavorites.
  ///
  /// In en, this message translates to:
  /// **'My favorites'**
  String get myFavorites;

  /// No description provided for @myGallery.
  ///
  /// In en, this message translates to:
  /// **'My gallery'**
  String get myGallery;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settingsTitle;

  /// No description provided for @aboutTitle.
  ///
  /// In en, this message translates to:
  /// **'About'**
  String get aboutTitle;

  /// No description provided for @signOut.
  ///
  /// In en, this message translates to:
  /// **'Sign out'**
  String get signOut;

  /// No description provided for @memberSince.
  ///
  /// In en, this message translates to:
  /// **'Member since {date}'**
  String memberSince(String date);

  /// No description provided for @guestAccount.
  ///
  /// In en, this message translates to:
  /// **'Guest account'**
  String get guestAccount;

  /// No description provided for @editProfile.
  ///
  /// In en, this message translates to:
  /// **'Edit profile'**
  String get editProfile;

  /// No description provided for @editNameTitle.
  ///
  /// In en, this message translates to:
  /// **'Edit name'**
  String get editNameTitle;

  /// No description provided for @appearance.
  ///
  /// In en, this message translates to:
  /// **'Appearance'**
  String get appearance;

  /// No description provided for @themeSystem.
  ///
  /// In en, this message translates to:
  /// **'System default'**
  String get themeSystem;

  /// No description provided for @themeLight.
  ///
  /// In en, this message translates to:
  /// **'Light'**
  String get themeLight;

  /// No description provided for @themeDark.
  ///
  /// In en, this message translates to:
  /// **'Dark'**
  String get themeDark;

  /// No description provided for @language.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// No description provided for @arabic.
  ///
  /// In en, this message translates to:
  /// **'العربية'**
  String get arabic;

  /// No description provided for @english.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get english;

  /// No description provided for @notifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// No description provided for @notificationsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'In-app alerts and updates'**
  String get notificationsSubtitle;

  /// No description provided for @clearCache.
  ///
  /// In en, this message translates to:
  /// **'Clear image cache'**
  String get clearCache;

  /// No description provided for @cacheCleared.
  ///
  /// In en, this message translates to:
  /// **'Cache cleared'**
  String get cacheCleared;

  /// No description provided for @aboutApp.
  ///
  /// In en, this message translates to:
  /// **'About NABBEH AI'**
  String get aboutApp;

  /// No description provided for @version.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get version;

  /// No description provided for @paywallTitle.
  ///
  /// In en, this message translates to:
  /// **'NABBEH PRO'**
  String get paywallTitle;

  /// No description provided for @paywallSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Create more, create better'**
  String get paywallSubtitle;

  /// No description provided for @freeLabel.
  ///
  /// In en, this message translates to:
  /// **'Free'**
  String get freeLabel;

  /// No description provided for @proLabel.
  ///
  /// In en, this message translates to:
  /// **'Pro'**
  String get proLabel;

  /// No description provided for @featureMessagesFree.
  ///
  /// In en, this message translates to:
  /// **'20 AI messages / day'**
  String get featureMessagesFree;

  /// No description provided for @featureMessagesPro.
  ///
  /// In en, this message translates to:
  /// **'500 AI messages / day'**
  String get featureMessagesPro;

  /// No description provided for @featureImagesFree.
  ///
  /// In en, this message translates to:
  /// **'5 images / day'**
  String get featureImagesFree;

  /// No description provided for @featureImagesPro.
  ///
  /// In en, this message translates to:
  /// **'100 images / day'**
  String get featureImagesPro;

  /// No description provided for @featureQualityStandard.
  ///
  /// In en, this message translates to:
  /// **'Standard image quality'**
  String get featureQualityStandard;

  /// No description provided for @featureQualityHd.
  ///
  /// In en, this message translates to:
  /// **'HD image quality'**
  String get featureQualityHd;

  /// No description provided for @featureAdsFree.
  ///
  /// In en, this message translates to:
  /// **'Shows occasional promos'**
  String get featureAdsFree;

  /// No description provided for @featureAdsPro.
  ///
  /// In en, this message translates to:
  /// **'Completely ad-free'**
  String get featureAdsPro;

  /// No description provided for @featurePriorityFree.
  ///
  /// In en, this message translates to:
  /// **'Standard queue'**
  String get featurePriorityFree;

  /// No description provided for @featurePriorityPro.
  ///
  /// In en, this message translates to:
  /// **'Priority generation queue'**
  String get featurePriorityPro;

  /// No description provided for @featureEditFree.
  ///
  /// In en, this message translates to:
  /// **'Basic tools'**
  String get featureEditFree;

  /// No description provided for @featureEditPro.
  ///
  /// In en, this message translates to:
  /// **'Full AI studio + image editing'**
  String get featureEditPro;

  /// No description provided for @monthlyPlan.
  ///
  /// In en, this message translates to:
  /// **'Monthly'**
  String get monthlyPlan;

  /// No description provided for @yearlyPlan.
  ///
  /// In en, this message translates to:
  /// **'Yearly'**
  String get yearlyPlan;

  /// No description provided for @perMonth.
  ///
  /// In en, this message translates to:
  /// **'/month'**
  String get perMonth;

  /// No description provided for @perYear.
  ///
  /// In en, this message translates to:
  /// **'/year'**
  String get perYear;

  /// No description provided for @saveBadge.
  ///
  /// In en, this message translates to:
  /// **'Save {percent}%'**
  String saveBadge(int percent);

  /// No description provided for @mostPopular.
  ///
  /// In en, this message translates to:
  /// **'Most popular'**
  String get mostPopular;

  /// No description provided for @creditPacksTitle.
  ///
  /// In en, this message translates to:
  /// **'Credit packs'**
  String get creditPacksTitle;

  /// No description provided for @creditPacksSubtitle.
  ///
  /// In en, this message translates to:
  /// **'One-time purchase, never expires'**
  String get creditPacksSubtitle;

  /// No description provided for @creditsSmall.
  ///
  /// In en, this message translates to:
  /// **'100 credits'**
  String get creditsSmall;

  /// No description provided for @creditsMedium.
  ///
  /// In en, this message translates to:
  /// **'500 credits'**
  String get creditsMedium;

  /// No description provided for @creditsLarge.
  ///
  /// In en, this message translates to:
  /// **'1500 credits'**
  String get creditsLarge;

  /// No description provided for @purchaseNow.
  ///
  /// In en, this message translates to:
  /// **'Subscribe now'**
  String get purchaseNow;

  /// No description provided for @restorePurchases.
  ///
  /// In en, this message translates to:
  /// **'Restore purchases'**
  String get restorePurchases;

  /// No description provided for @purchasing.
  ///
  /// In en, this message translates to:
  /// **'Processing purchase…'**
  String get purchasing;

  /// No description provided for @restored.
  ///
  /// In en, this message translates to:
  /// **'Purchases restored'**
  String get restored;

  /// No description provided for @purchaseSuccess.
  ///
  /// In en, this message translates to:
  /// **'Purchase successful! Welcome to PRO 🎉'**
  String get purchaseSuccess;

  /// No description provided for @purchaseFailed.
  ///
  /// In en, this message translates to:
  /// **'Purchase failed. Please try again.'**
  String get purchaseFailed;

  /// No description provided for @demoModeTitle.
  ///
  /// In en, this message translates to:
  /// **'Demo mode'**
  String get demoModeTitle;

  /// No description provided for @demoModeBody.
  ///
  /// In en, this message translates to:
  /// **'RevenueCat is not configured yet. Add your public SDK keys in .env to enable real purchases. For now you can try PRO features in demo mode.'**
  String get demoModeBody;

  /// No description provided for @subscriptionNote.
  ///
  /// In en, this message translates to:
  /// **'Subscriptions renew automatically until cancelled. Credit packs are one-time purchases that never expire.'**
  String get subscriptionNote;

  /// No description provided for @limitReachedTitle.
  ///
  /// In en, this message translates to:
  /// **'Limit reached'**
  String get limitReachedTitle;

  /// No description provided for @limitDailyChat.
  ///
  /// In en, this message translates to:
  /// **'You have used all your AI messages for today. Upgrade to PRO for 500 messages per day, or buy credits.'**
  String get limitDailyChat;

  /// No description provided for @limitDailyImages.
  ///
  /// In en, this message translates to:
  /// **'You have used all your daily images. Upgrade to PRO for 100 images per day, or buy credits.'**
  String get limitDailyImages;

  /// No description provided for @limitCredits.
  ///
  /// In en, this message translates to:
  /// **'You do not have enough credits. Buy a credit pack or upgrade to PRO.'**
  String get limitCredits;

  /// No description provided for @goPro.
  ///
  /// In en, this message translates to:
  /// **'Go PRO'**
  String get goPro;

  /// No description provided for @getCredits.
  ///
  /// In en, this message translates to:
  /// **'Get credits'**
  String get getCredits;

  /// No description provided for @setupTitle.
  ///
  /// In en, this message translates to:
  /// **'Configuration required'**
  String get setupTitle;

  /// No description provided for @setupBody.
  ///
  /// In en, this message translates to:
  /// **'NABBEH AI is not connected to a backend yet.\n\n1. Copy .env.example to .env\n2. Add your Supabase URL and anon key\n3. Restart the app\n\nAll AI keys stay on the server — see README.md.'**
  String get setupBody;

  /// No description provided for @setupHint.
  ///
  /// In en, this message translates to:
  /// **'This screen appears because .env has empty values.'**
  String get setupHint;

  /// No description provided for @networkError.
  ///
  /// In en, this message translates to:
  /// **'Connection problem. Please try again.'**
  String get networkError;

  /// No description provided for @serverError.
  ///
  /// In en, this message translates to:
  /// **'Server error. Please try again later.'**
  String get serverError;

  /// No description provided for @imageTooLarge.
  ///
  /// In en, this message translates to:
  /// **'Image is too large. Please choose a smaller image.'**
  String get imageTooLarge;

  /// No description provided for @uploadFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not read the image. Please try another one.'**
  String get uploadFailed;
}

class _SDelegate extends LocalizationsDelegate<S> {
  const _SDelegate();

  @override
  Future<S> load(Locale locale) {
    return SynchronousFuture<S>(lookupS(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_SDelegate old) => false;
}

S lookupS(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return SAr();
    case 'en': return SEn();
  }

  throw FlutterError(
    'S.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
