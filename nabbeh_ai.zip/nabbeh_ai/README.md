# NABBEH AI 🤖✨

**تطبيق ذكاء اصطناعي احترافي كامل — Flutter + Android + iOS**

محادثة ذكية، توليد صور، تعديل صور، تحليل صور، إنشاء Prompts، نظام Credits، اشتراكات PRO عبر RevenueCat، ونظام مجاني بحدود يومية — كل ذلك بباك-إند آمن لا يحتوي على أي مفاتيح سرية داخل التطبيق.

---

## 📁 1) الملفات والهيكل

```
nabbeh_ai/
├── lib/
│   ├── main.dart                  # نقطة انطلاق التطبيق + كل الـ Providers
│   ├── l10n_helper.dart           # استيراد موحّد للترجمات
│   ├── core/
│   │   ├── config/env_config.dart     # قراءة .env (مفاتيح عامة فقط)
│   │   ├── constants/app_constants.dart  # الأسعار، الأنماط، معرفات المنتجات
│   │   ├── errors/app_exception.dart  # أخطاء مُنمّطة (حدود، شبكة...)
│   │   ├── theme/ (app_colors, app_theme)  # Material 3 فاتح/داكن
│   │   └── utils/helpers.dart
│   ├── models/   (app_user, conversation, chat_message, generation, favorite_item)
│   ├── services/ (supabase_service, ai_service, revenuecat_service,
│   │              settings_storage, ad_service)
│   ├── repositories/ (user, chat, generation, favorite)
│   ├── providers/ (auth, chat, creation, gallery, settings, subscription)
│   ├── screens/
│   │   ├── splash / setup / main_shell (5 تبويبات)
│   │   ├── auth/login_screen
│   │   ├── home/home_screen            # 5 بطاقات الميزات
│   │   ├── chat/ (chat_list_screen, chat_screen)
│   │   ├── create/ (create_hub, image_generation, image_edit,
│   │   │            image_analysis, prompt_generator)
│   │   ├── history/ + gallery/ (gallery_screen, image_detail_screen)
│   │   ├── favorites/favorites_screen
│   │   ├── profile/profile_screen
│   │   ├── settings/settings_screen    # ثيم + لغة + إعدادات
│   │   └── paywall/paywall_screen      # Free vs PRO + حزم الكريدت
│   ├── widgets/  (12 ويدجت مشتركة)
│   ├── l10n/     (app_en.arb, app_ar.arb — عربي/إنجليزي كامل)
│   └── generated/ (يُولَّد تلقائيًا)
├── android/      # جاهز — applicationId: com.nabbeh.ai
├── ios/          # جاهز — Bundle ID: com.nabbeh.ai + Podfile
├── supabase/
│   ├── migrations/0001_init.sql        # كل قاعدة البيانات (شغّله مرة واحدة)
│   ├── functions/                      # 7 دوال Edge Functions (Deno/TypeScript)
│   └── .env.example                    # أسماء أسرار السيرفر
├── .github/workflows/
│   ├── build-android.yml               # بناء APK/AAB مجانًا من GitHub
│   ├── build-ios-unsigned.yml          # التحقق من بناء iOS
│   └── deploy-supabase.yml             # نشر الباك-إند تلقائيًا
├── codemagic.yaml                      # بناء Codemagic (Android + iOS موقّع)
├── .env / .env.example                 # مفاتيح عامة فقط (آمنة للنشر)
└── pubspec.yaml
```

---

## 📦 2) الحزم المطلوبة

مثبّتة بالفعل في `pubspec.yaml` (شغّل `flutter pub get` فقط):

| الحزمة | الغرض |
|---|---|
| `provider` | إدارة الحالة |
| `supabase_flutter` | المصادقة + قاعدة البيانات + التخزين + استدعاء الدوال |
| `functions_client` | أنواع استجابة Edge Functions |
| `purchases_flutter` | RevenueCat للاشتراكات والشراء داخل التطبيق |
| `image_picker` | اختيار/تصوير الصور |
| `cached_network_image` | عرض صور المعرض بكفاءة |
| `share_plus` | مشاركة الصور والنصوص |
| `shared_preferences` | حفظ الثيم واللغة |
| `flutter_dotenv` | قراءة ملف `.env` |
| `flutter_localizations` + `intl` | العربية/الإنجليزية وRTL |

---

## 🔑 3) إعدادات API

### قاعدة أمان المشروع
- **داخل التطبيق (`.env`)**: مفاتيح **عامة فقط** — Supabase URL + anon key + مفاتيح RevenueCat العامة. هذه مصمّمة أصلًا لتكون داخل التطبيقات ولا تُعتبر أسرارًا.
- **على السيرفر (Supabase Secrets)**: كل الأسرار الحقيقية — مفاتيح OpenAI/Gemini/Stability/RevenueCat السرية. **لا يوجد أي مفتاح AI داخل كود Flutter إطلاقًا.**

### ملف `.env` (انسخ من `.env.example` واملأ)
```
SUPABASE_URL=https://XXXX.supabase.co
SUPABASE_ANON_KEY=eyJ...
REVENUECAT_APPLE_API_KEY=appl_...
REVENUECAT_GOOGLE_API_KEY=goog_...
```

### أسرار السيرفر (Supabase → Edge Functions → Secrets)
```
AI_TEXT_PROVIDER=openai        # openai | gemini | openrouter | groq
AI_CHAT_MODEL=gpt-4o-mini
AI_IMAGE_PROVIDER=openai       # openai | stability
AI_IMAGE_MODEL=dall-e-3
AI_EDIT_MODEL=gpt-image-1
OPENAI_API_KEY=sk-...          # أو أي مزود آخر تختاره
REVENUECAT_SECRET_API_KEY=sk_...
REVENUECAT_WEBHOOK_AUTH=سلسلة_عشوائية_طويلة
```

**مزود AI قابل للتغيير بالكامل من السيرفر** — غيّر `AI_TEXT_PROVIDER` أو `AI_IMAGE_PROVIDER` بدون لمس التطبيق.

---

## 🗄️ 4) إعداد Supabase (من الهاتف — 10 دقائق)

1. **أنشئ مشروعًا**: [supabase.com](https://supabase.com) → New project (احفظ كلمة مرور قاعدة البيانات).
2. **شغّل قاعدة البيانات**: SQL Editor → New query → الصق محتوى `supabase/migrations/0001_init.sql` كاملًا → Run.
   - ينشئ: الجداول + RLS + بوكِت الصور + عمود Profile تلقائيًا عند التسجيل.
3. **المصادقة**: Authentication → Providers → Email مفعّل. ثم Authentication → Sign In / Up:
   - فعّل **Anonymous sign-ins** (لزر "المتابعة كضيف").
4. **انسخ المفاتيح العامة**: Project Settings → API → انسخ Project URL و anon/publishable key → ضعهما في `.env`.
5. **انشر الدوال** (اختر إحدى الطريقتين):
   - **الأسهل — GitHub Actions**: ارفع المشروع إلى GitHub → Settings → Secrets → Actions → أضف `SUPABASE_ACCESS_TOKEN` (من Account → Access Tokens) و `SUPABASE_PROJECT_ID` → شغّل workflow باسم **Deploy Supabase Edge Functions** → ينشر الدوال السبع ويضبط الأسرار تلقائيًا من أسرار GitHub.
   - **يدويًا — GitHub Codespaces من الهاتف**: افتح المستودع في Codespaces من متصفح الهاتف ثم:
     ```bash
     npm i -g supabase
     supabase login
     supabase functions deploy chat generate-image edit-image analyze-image generate-prompt sync-subscription revenuecat-webhook --project-ref <PROJECT_ID> --use-api
     supabase secrets set OPENAI_API_KEY=sk-... AI_TEXT_PROVIDER=openai REVENUECAT_SECRET_API_KEY=sk_... REVENUECAT_WEBHOOK_AUTH=xxxx --project-ref <PROJECT_ID>
     ```
6. **أضف مفتاح AI واحدًا على الأقل** (مثل `OPENAI_API_KEY`) وإلا ستعيد الدوال رسالة "Missing API key".

### حدود الخطط (قابلة للتعديل في `supabase/functions/_shared/utils.ts`)
| | مجاني (FREE) | PRO |
|---|---|---|
| رسائل AI يوميًا | 20 | 500 |
| صور يوميًا | 5 | 100 |
| كريدت يومي مجاني | +25 | +600 |
| جودة الصور | عادية | HD |
| إعلانات/ترويج | شريط ترويجي | بدون |
| أولوية التوليد | عادي | أولوية + HD |

**تكلفة الكريدت لكل عملية** (على السيرفر): محادثة 1 · Prompt 1 · تحليل 2 · تعديل صورة 8 · توليد صورة 10 (HD للمشتركين 15).

---

## 💰 5) إعداد RevenueCat

1. **أنشئ حسابًا**: [app.revenuecat.com](https://app.revenuecat.com) → New project.
2. **أضف التطبيقين**: Android (استخدم `com.nabbeh.ai`) و Apple (Bundle ID: `com.nabbeh.ai`).
   - لنظام iOS ستحتاج ربط حساب Apple Developer لاحقًا داخل RevenueCat.
3. **أنشئ المنتجات** بنفس المعرفات (موجودة في `lib/core/constants/app_constants.dart`):
   - اشتراكات تلقائية: `nabbeh_pro_monthly`، `nabbeh_pro_yearly`
   - منتجات استهلاكية (Consumable): `nabbeh_credits_small`، `nabbeh_credits_medium`، `nabbeh_credits_large`
   - في Google Play أنشئها كـ "In-app products" / "Subscriptions"، وفي App Store Connect كـ Subscriptions + Consumable IAP.
4. **أنشئ Entitlement** باسم `pro_access` وأرفق `nabbeh_pro_monthly` و `nabbeh_pro_yearly` له.
5. **أنشئ Offering** (Default) وأضف الحزم الخمس — ستظهر مباشرة في شاشة Paywall بالأسعار من المتجر.
6. **المفاتيح**:
   - Public SDK keys (Apple + Google) → ضعها في `.env` (آمنة).
   - **Secret API key** (يبدأ بـ `sk_`) → ضعه في أسرار السيرفر فقط.
7. **Webhook**: RevenueCat → Integrations → Webhooks:
   - URL: `https://<PROJECT_ID>.supabase.co/functions/v1/revenuecat-webhook`
   - Authorization header: `Bearer <نفس قيمة REVENUECAT_WEBHOOK_AUTH>`
8. بعد أي شراء يستدعي التطبيق دالة `sync-subscription` التي تتحقق من RevenueCat على السيرفر وتحدّث `profiles.plan` وتمنح الكريدت (مع حماية تكرار عبر جدول `rc_grants`).

> **وضع تجريبي**: قبل إضافة مفاتيح RevenueCat، يعمل Paywall في وضع تجريبي يمنح PRO للاختبار — يتوقف تلقائيًا بمجرد ضبط `REVENUECAT_SECRET_API_KEY` على السيرفر.

---

## 📱 6) التشغيل من الهاتف (بدون كمبيوتر)

### الطريقة الموصى بها: GitHub Codespaces
1. ارفع المشروع إلى مستودع GitHub (من تطبيق GitHub على الهاتف أو المتصفح).
2. في المتصفح: المستودع → زر **Code** → **Codespaces** → Create codespace.
3. في الطرفية (Terminal):
   ```bash
   # التحقق من الكود
   flutter pub get
   flutter analyze
   ```
4. لتجربة التطبيق فعليًا من الهاتف، ابعنِ APK:
   ```bash
   flutter build apk --release
   ```
   ثم حمّل `build/app/outputs/flutter-apk/app-release.apk` (كليك يمين على الملف → Download) وثبّته على هاتفك مباشرة.

> ملاحظة: Codespaces المجاني يكفي للتحليل والبناء البسيط؛ للبناء السريع المنتظم استخدم GitHub Actions (التالي).

---

## 🤖 7) بناء Android (APK / AAB) — بدون كمبيوتر

### أ) GitHub Actions (مجاني وأسهل)
1. المستودع → تبويب **Actions** → **Build Android (APK + AAB)** → **Run workflow**.
2. بعد دقيقتين–خمس حمّل `nabbeh-ai-android-apk` من Artifacts وثبّته.
3. ملف AAB جاهز لرفعه إلى Google Play.

> ملاحظة توقيع Google Play: رفع AAB الأول إلى Play Console يتطلب مفتاح توقيع. فعّل **Play App Signing** (تلقائي في الحسابات الجديدة) — Google يوقّع النسخة النهائية ومفتاح الرفع يمكن أن يبقى debug أو أنشئ upload keystore لاحقًا في Codemagic.

### ب) Codemagic
- [codemagic.io](https://codemagic.io) → Add application من GitHub → اختر workflow `android-release` (مضبوط في `codemagic.yaml`) → Start build → تحصل على APK/AAB موقّع بـ debug key جاهز للتجربة.

### ج) Appcircle
- [appcircle.io](https://appcircle.io) → Create profile → اربط المستودع → Build Configuration: Flutter → Release → Build. حمّل APK/AAB من Artifacts.

---

## 🍎 8) بناء iOS (IPA) — بدون Mac

**المتطلب الوحيد**: حساب **Apple Developer** (99$/سنة) — لا يمكن تجاوزه قانونيًا لأي بناء موقّع.

### الطريقة الأسهل: Codemagic (يوقّع وينشئ الشهادات عنك)
1. [codemagic.io](https://codemagic.io) → Teams → **Apple Developer account** → اربط حسابك بـ App Store Connect API (المفتاح من App Store Connect → Users and Access → Keys).
2. اختر workflow `ios-release` من `codemagic.yaml` → Start build.
3. Codemagic ينشئ تلقائيًا: الشهادات + Provisioning Profiles لـ `com.nabbeh.ai` ويبني IPA موقّع.
4. للتوزيع: ارفع IPA إلى **TestFlight** (من Codemagic مباشرة) ثم جرّبه من تطبيق TestFlight على آيفونك.

### بديل: Appcircle
- نفس الخطوات: اربط Apple Developer account → profile جديد → Build → IPA موقّع → TestFlight أو تثبيت مباشر (Ad Hoc).

### للتحقق من بناء iOS فقط (بدون حساب مدفوع)
- شغّل workflow **Build iOS (unsigned IPA)** في GitHub Actions — ينتج IPA غير موقّع للتأكد أن الكود يبني بنجاح على iOS.

### إعداد App Store Connect قبل الرفع
1. أنشئ App جديد باسم **Nabbeh AI** و Bundle ID `com.nabbeh.ai`.
2. فعّل In-App Purchases وأنشئ المنتجات الخمسة (نفس المعرفات أعلاه) وأرفقها بـ RevenueCat.

---

## 🛠️ استكشاف الأخطاء

| المشكلة | الحل |
|---|---|
| شاشة "Configuration required" | `.env` فارغ — أضف SUPABASE_URL و SUPABASE_ANON_KEY |
| "Missing API key for provider" | أضف مفتاح المزود في Supabase secrets ثم أعد نشر الدوال |
| فشل تسجيل الدخول كضيف | فعّل Anonymous sign-ins في Supabase Auth |
| Paywall لا يعرض الأسعار | أنشئ Offering في RevenueCat وأضف المفاتيح العامة في `.env` |
| `limit_reached` باستمرار | طبيعي — انتهت الحصة اليومية؛ اشترِ كريدت أو PRO |
| فشل بناء iOS محليًا في Codespaces | iOS يُبنى فقط على macOS (GitHub Actions macos / Codemagic / Appcircle) |

## 🔐 ملخص الأمان
- ✅ لا يوجد أي مفتاح AI داخل تطبيق Flutter — كل الاستدعاءات تمر عبر Edge Functions.
- ✅ RLS مفعل على كل الجداول — المستخدم يرى بياناته فقط.
- ✅ الحدود والكريدت تُحسب وتُخصم على السيرفر (لا يمكن التلاعب بها من العميل).
- ✅ مفاتيح Supabase/RevenueCat داخل `.env` عامة بطبيعتها ومصممة للتطبيقات.
- ✅ Webhook محمي بمفتاح مشترك، ومنح الكريدت مرة واحدة فقط لكل معاملة.
