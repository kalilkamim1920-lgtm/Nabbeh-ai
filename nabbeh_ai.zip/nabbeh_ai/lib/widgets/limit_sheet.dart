import 'package:flutter/material.dart';

import '../core/errors/app_exception.dart';
import '../l10n_helper.dart';
import '../core/theme/app_colors.dart';

/// Bottom sheet shown when the backend reports a daily/credit limit.
/// Offers the paywall (PRO) or the credit packs section.
Future<void> showLimitReachedSheet(
  BuildContext context,
  AppErrorType type,
) async {
  final S s = S.of(context);
  final String body = switch (type) {
    AppErrorType.limitDailyChat => s.limitDailyChat,
    AppErrorType.limitDailyImages => s.limitDailyImages,
    _ => s.limitCredits,
  };

  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (BuildContext sheetContext) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                gradient: AppColors.proGradient,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.bolt_rounded,
                color: Color(0xFF5C3A00),
                size: 32,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              s.limitReachedTitle,
              style: Theme.of(sheetContext).textTheme.titleLarge,
            ),
            const SizedBox(height: 10),
            Text(
              body,
              textAlign: TextAlign.center,
              style: Theme.of(sheetContext).textTheme.bodyMedium,
            ),
            const SizedBox(height: 22),
            if (type != AppErrorType.limitCredits)
              FilledButton(
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                ),
                onPressed: () {
                  Navigator.of(sheetContext).pop('pro');
                },
                child: Text(s.goPro),
              ),
            const SizedBox(height: 10),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              onPressed: () {
                Navigator.of(sheetContext).pop('credits');
              },
              child: Text(s.getCredits),
            ),
          ],
        ),
      );
    },
  );
}
