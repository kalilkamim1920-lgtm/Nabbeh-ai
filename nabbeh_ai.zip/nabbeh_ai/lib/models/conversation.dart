/// A chat conversation — mirrors the `conversations` table.
class Conversation {
  const Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.lastMessage,
  });

  final String id;
  final String title;
  final String? lastMessage;
  final DateTime createdAt;
  final DateTime updatedAt;

  factory Conversation.fromMap(Map<String, dynamic> map) {
    return Conversation(
      id: (map['id'] ?? '').toString(),
      title: (map['title'] ?? 'Chat').toString(),
      lastMessage: map['last_message'] as String?,
      createdAt: DateTime.tryParse('${map['created_at']}') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse('${map['updated_at']}') ??
          DateTime.now(),
    );
  }
}
