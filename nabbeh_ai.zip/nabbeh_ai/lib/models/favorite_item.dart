/// A saved favorite item — mirrors the `favorites` table.
/// Used for text items (prompts); images use `generations.is_favorite`.
class FavoriteItem {
  const FavoriteItem({
    required this.id,
    required this.itemType,
    required this.createdAt,
    this.title,
    this.content,
  });

  final String id;

  /// 'prompt' | 'message'
  final String itemType;
  final String? title;
  final String? content;
  final DateTime createdAt;

  factory FavoriteItem.fromMap(Map<String, dynamic> map) {
    return FavoriteItem(
      id: (map['id'] ?? '').toString(),
      itemType: (map['item_type'] ?? 'prompt').toString(),
      title: map['title'] as String?,
      content: map['content'] as String?,
      createdAt: DateTime.tryParse('${map['created_at']}') ??
          DateTime.now(),
    );
  }
}
