import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/config/env_config.dart';
import '../l10n_helper.dart';
import '../providers/auth_provider.dart';
import '../widgets/app_logo.dart';
import 'auth/login_screen.dart';
import 'main_shell.dart';
import 'setup_screen.dart';

/// Brand splash + routing decision:
/// no backend config -> SetupScreen, guest -> Login, signed in -> MainShell.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _decide());
  }

  Future<void> _decide() async {
    await Future<void>.delayed(const Duration(milliseconds: 1400));
    if (!mounted) return;

    if (!EnvConfig.isConfigured) {
      _go(const SetupScreen());
      return;
    }

    final AuthProvider auth = context.read<AuthProvider>();
    // Wait briefly for the auth bootstrap to settle.
    int tries = 0;
    while (!auth.initialized && tries < 20) {
      await Future<void>.delayed(const Duration(milliseconds: 150));
      tries++;
      if (!mounted) return;
    }
    if (!mounted) return;

    if (auth.isSignedIn) {
      _go(const MainShell());
    } else {
      _go(const LoginScreen());
    }
  }

  void _go(Widget page) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const AppLogo(size: 92, showText: true),
            const SizedBox(height: 28),
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
            const SizedBox(height: 16),
            Text(
              s.homeTagline,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium
                  ?.copyWith(color: Colors.grey.shade500),
            ),
          ],
        ),
      ),
    );
  }
}
