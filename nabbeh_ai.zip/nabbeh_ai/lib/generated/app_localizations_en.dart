import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class SEn extends S {
  SEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'NABBEH AI';

  @override
  String get ok => 'OK';

  @override
  String get cancel => 'Cancel';

  @override
  String get save => 'Save';

  @override
  String get delete => 'Delete';

  @override
  String get share => 'Share';

  @override
  String get copy => 'Copy';

  @override
  String get done => 'Done';

  @override
  String get retry => 'Retry';

  @override
  String get close => 'Close';

  @override
  String get loading => 'Loading…';

  @override
  String get errorGeneric => 'Something went wrong. Please try again.';

  @override
  String get success => 'Done successfully';

  @override
  String get seeAll => 'See all';

  @override
  String get copiedToClipboard => 'Copied to clipboard';

  @override
  String get comingSoon => 'Coming soon';

  @override
  String get loginRequired => 'Sign in required';

  @override
  String get signInToContinue => 'Please sign in to continue';

  @override
  String get tabHome => 'Home';

  @override
  String get tabChat => 'Chat';

  @override
  String get tabCreate => 'Create';

  @override
  String get tabHistory => 'History';

  @override
  String get tabProfile => 'Profile';

  @override
  String get homeWelcome => 'Welcome back';

  @override
  String get homeTagline => 'What would you like to create today?';

  @override
  String creditsLabel(int count) {
    return '$count credits';
  }

  @override
  String get upgradeBannerTitle => 'Unlock NABBEH PRO';

  @override
  String get upgradeBannerSubtitle => 'More messages, HD images, no ads';

  @override
  String get upgradeNow => 'Upgrade now';

  @override
  String get featureChatTitle => 'Chat with AI';

  @override
  String get featureChatSubtitle => 'Smart conversations in Arabic & English';

  @override
  String get featureImageTitle => 'Create Image';

  @override
  String get featureImageSubtitle => 'Turn your words into stunning art';

  @override
  String get featureEditTitle => 'Edit Image';

  @override
  String get featureEditSubtitle => 'Modify any photo with AI';

  @override
  String get featureAnalyzeTitle => 'Analyze Image';

  @override
  String get featureAnalyzeSubtitle => 'Upload a photo and ask about it';

  @override
  String get featurePromptTitle => 'Create Prompt';

  @override
  String get featurePromptSubtitle => 'Craft perfect prompts for any AI model';

  @override
  String get recentCreations => 'Recent creations';

  @override
  String get noCreationsYet => 'Your creations will appear here';

  @override
  String get loginTitle => 'Welcome to NABBEH AI';

  @override
  String get loginSubtitle => 'Sign in to unlock the full power of AI';

  @override
  String get createAccountTitle => 'Create your account';

  @override
  String get fullName => 'Full name';

  @override
  String get fullNameHint => 'Your name';

  @override
  String get email => 'Email';

  @override
  String get emailHint => 'you@example.com';

  @override
  String get password => 'Password';

  @override
  String get passwordHint => 'At least 6 characters';

  @override
  String get confirmPassword => 'Confirm password';

  @override
  String get signIn => 'Sign in';

  @override
  String get signUp => 'Sign up';

  @override
  String get forgotPassword => 'Forgot password?';

  @override
  String get resetPassword => 'Reset password';

  @override
  String get resetPasswordSent => 'Password reset email sent';

  @override
  String get resetPasswordBody => 'Check your inbox for the reset link.';

  @override
  String get continueAsGuest => 'Continue as guest';

  @override
  String get guestNote => 'You can create an account later to keep your data safe.';

  @override
  String get authFailed => 'Authentication failed';

  @override
  String get errEmailInvalid => 'Please enter a valid email';

  @override
  String get errPasswordShort => 'Password must be at least 6 characters';

  @override
  String get errPasswordMismatch => 'Passwords do not match';

  @override
  String get errNameRequired => 'Please enter your name';

  @override
  String get errWrongCredentials => 'Wrong email or password';

  @override
  String get errEmailTaken => 'This email is already registered';

  @override
  String get errTooManyRequests => 'Too many attempts. Please wait and try again.';

  @override
  String get errNetwork => 'Network error. Check your connection.';

  @override
  String get logout => 'Sign out';

  @override
  String get logoutConfirm => 'Are you sure you want to sign out?';

  @override
  String get chatTitle => 'AI Chat';

  @override
  String get newChat => 'New chat';

  @override
  String get chatEmptyTitle => 'Start a conversation';

  @override
  String get chatEmptySubtitle => 'Ask anything — ideas, writing, code, translations…';

  @override
  String get typeMessage => 'Type your message…';

  @override
  String get send => 'Send';

  @override
  String get attachImage => 'Attach image';

  @override
  String get aiThinking => 'NABBEH is thinking…';

  @override
  String get conversationsEmpty => 'No conversations yet';

  @override
  String get deleteConversationTitle => 'Delete conversation?';

  @override
  String get deleteConversationBody => 'This conversation and its messages will be removed.';

  @override
  String get imageAttached => 'Image attached';

  @override
  String get createHubTitle => 'AI Studio';

  @override
  String get createHubSubtitle => 'Everything you need to create with AI';

  @override
  String get promptLabel => 'Prompt';

  @override
  String get promptHint => 'Describe what you want to create…';

  @override
  String get styleLabel => 'Style';

  @override
  String get ratioLabel => 'Aspect ratio';

  @override
  String get generate => 'Generate';

  @override
  String get generatingImage => 'Generating your image…';

  @override
  String get generationFailed => 'Image generation failed';

  @override
  String get savedToGallery => 'Saved to your gallery';

  @override
  String get styleRealistic => 'Realistic';

  @override
  String get styleAnime => 'Anime';

  @override
  String get styleDigitalArt => 'Digital Art';

  @override
  String get style3D => '3D Render';

  @override
  String get styleWatercolor => 'Watercolor';

  @override
  String get styleCyberpunk => 'Cyberpunk';

  @override
  String get styleMinimal => 'Minimal';

  @override
  String get styleLogo => 'Logo';

  @override
  String get styleNone => 'None';

  @override
  String get ratioSquare => 'Square';

  @override
  String get ratioLandscape => 'Landscape';

  @override
  String get ratioPortrait => 'Portrait';

  @override
  String get editInstructionLabel => 'What should I change?';

  @override
  String get editInstructionHint => 'e.g. Change the background to a beach at sunset';

  @override
  String get chooseImage => 'Choose image';

  @override
  String get changeImage => 'Change image';

  @override
  String get applyEdit => 'Apply AI edit';

  @override
  String get applyingEdit => 'Applying your edit…';

  @override
  String get analyzeQuestionLabel => 'Your question (optional)';

  @override
  String get analyzeQuestionHint => 'e.g. What is in this image?';

  @override
  String get analyzeImage => 'Analyze image';

  @override
  String get analyzing => 'Analyzing your image…';

  @override
  String get analysisResult => 'Analysis result';

  @override
  String get promptIdeaLabel => 'Your idea';

  @override
  String get promptIdeaHint => 'Describe your idea in simple words…';

  @override
  String get platformLabel => 'Target platform';

  @override
  String get platformMidjourney => 'Midjourney';

  @override
  String get platformStableDiffusion => 'Stable Diffusion';

  @override
  String get platformDalle => 'DALL·E';

  @override
  String get platformGeneric => 'Generic';

  @override
  String get generatePrompts => 'Generate prompts';

  @override
  String get promptsResult => 'Suggested prompts';

  @override
  String get savePrompt => 'Save prompt';

  @override
  String get promptSaved => 'Prompt saved to favorites';

  @override
  String get historyConversationsTab => 'Chats';

  @override
  String get historyImagesTab => 'Images';

  @override
  String get historyEmptyImages => 'No generated images yet';

  @override
  String get historyEmptyConversations => 'No conversations yet';

  @override
  String get galleryTitle => 'My Gallery';

  @override
  String get favoritesTitle => 'Favorites';

  @override
  String get favTabImages => 'Images';

  @override
  String get favTabPrompts => 'Prompts';

  @override
  String get noFavoritesYet => 'Nothing here yet. Tap the star on any item to save it.';

  @override
  String get copyPrompt => 'Copy prompt';

  @override
  String get deleteImageTitle => 'Delete this image?';

  @override
  String get deleteImageBody => 'It will be removed from your gallery permanently.';

  @override
  String get imageDetails => 'Image details';

  @override
  String get favoriteAdded => 'Added to favorites';

  @override
  String get favoriteRemoved => 'Removed from favorites';

  @override
  String get profileTitle => 'Profile';

  @override
  String get planFree => 'FREE';

  @override
  String get planPro => 'PRO';

  @override
  String get creditsBalance => 'Credits balance';

  @override
  String get manageSubscription => 'Manage subscription';

  @override
  String get myFavorites => 'My favorites';

  @override
  String get myGallery => 'My gallery';

  @override
  String get settingsTitle => 'Settings';

  @override
  String get aboutTitle => 'About';

  @override
  String get signOut => 'Sign out';

  @override
  String memberSince(String date) {
    return 'Member since $date';
  }

  @override
  String get guestAccount => 'Guest account';

  @override
  String get editProfile => 'Edit profile';

  @override
  String get editNameTitle => 'Edit name';

  @override
  String get appearance => 'Appearance';

  @override
  String get themeSystem => 'System default';

  @override
  String get themeLight => 'Light';

  @override
  String get themeDark => 'Dark';

  @override
  String get language => 'Language';

  @override
  String get arabic => 'العربية';

  @override
  String get english => 'English';

  @override
  String get notifications => 'Notifications';

  @override
  String get notificationsSubtitle => 'In-app alerts and updates';

  @override
  String get clearCache => 'Clear image cache';

  @override
  String get cacheCleared => 'Cache cleared';

  @override
  String get aboutApp => 'About NABBEH AI';

  @override
  String get version => 'Version';

  @override
  String get paywallTitle => 'NABBEH PRO';

  @override
  String get paywallSubtitle => 'Create more, create better';

  @override
  String get freeLabel => 'Free';

  @override
  String get proLabel => 'Pro';

  @override
  String get featureMessagesFree => '20 AI messages / day';

  @override
  String get featureMessagesPro => '500 AI messages / day';

  @override
  String get featureImagesFree => '5 images / day';

  @override
  String get featureImagesPro => '100 images / day';

  @override
  String get featureQualityStandard => 'Standard image quality';

  @override
  String get featureQualityHd => 'HD image quality';

  @override
  String get featureAdsFree => 'Shows occasional promos';

  @override
  String get featureAdsPro => 'Completely ad-free';

  @override
  String get featurePriorityFree => 'Standard queue';

  @override
  String get featurePriorityPro => 'Priority generation queue';

  @override
  String get featureEditFree => 'Basic tools';

  @override
  String get featureEditPro => 'Full AI studio + image editing';

  @override
  String get monthlyPlan => 'Monthly';

  @override
  String get yearlyPlan => 'Yearly';

  @override
  String get perMonth => '/month';

  @override
  String get perYear => '/year';

  @override
  String saveBadge(int percent) {
    return 'Save $percent%';
  }

  @override
  String get mostPopular => 'Most popular';

  @override
  String get creditPacksTitle => 'Credit packs';

  @override
  String get creditPacksSubtitle => 'One-time purchase, never expires';

  @override
  String get creditsSmall => '100 credits';

  @override
  String get creditsMedium => '500 credits';

  @override
  String get creditsLarge => '1500 credits';

  @override
  String get purchaseNow => 'Subscribe now';

  @override
  String get restorePurchases => 'Restore purchases';

  @override
  String get purchasing => 'Processing purchase…';

  @override
  String get restored => 'Purchases restored';

  @override
  String get purchaseSuccess => 'Purchase successful! Welcome to PRO 🎉';

  @override
  String get purchaseFailed => 'Purchase failed. Please try again.';

  @override
  String get demoModeTitle => 'Demo mode';

  @override
  String get demoModeBody => 'RevenueCat is not configured yet. Add your public SDK keys in .env to enable real purchases. For now you can try PRO features in demo mode.';

  @override
  String get subscriptionNote => 'Subscriptions renew automatically until cancelled. Credit packs are one-time purchases that never expire.';

  @override
  String get limitReachedTitle => 'Limit reached';

  @override
  String get limitDailyChat => 'You have used all your AI messages for today. Upgrade to PRO for 500 messages per day, or buy credits.';

  @override
  String get limitDailyImages => 'You have used all your daily images. Upgrade to PRO for 100 images per day, or buy credits.';

  @override
  String get limitCredits => 'You do not have enough credits. Buy a credit pack or upgrade to PRO.';

  @override
  String get goPro => 'Go PRO';

  @override
  String get getCredits => 'Get credits';

  @override
  String get setupTitle => 'Configuration required';

  @override
  String get setupBody => 'NABBEH AI is not connected to a backend yet.\n\n1. Copy .env.example to .env\n2. Add your Supabase URL and anon key\n3. Restart the app\n\nAll AI keys stay on the server — see README.md.';

  @override
  String get setupHint => 'This screen appears because .env has empty values.';

  @override
  String get networkError => 'Connection problem. Please try again.';

  @override
  String get serverError => 'Server error. Please try again later.';

  @override
  String get imageTooLarge => 'Image is too large. Please choose a smaller image.';

  @override
  String get uploadFailed => 'Could not read the image. Please try another one.';
}
