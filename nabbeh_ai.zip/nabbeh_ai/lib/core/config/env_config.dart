import 'package:flutter_dotenv/flutter_dotenv.dart';

/// Reads the app's public client configuration from `.env`.
///
/// SECURITY MODEL:
/// - This file contains ONLY public identifiers (Supabase URL + anon key,
///   RevenueCat public SDK keys).
/// - Real secrets (OpenAI / Gemini / Stability keys, RevenueCat secret key)
///   NEVER touch the app — they live in Supabase Edge Function env vars.
class EnvConfig {
  EnvConfig._();

  static bool _loaded = false;

  static Future<void> load() async {
    try {
      await dotenv.load(fileName: '.env');
      _loaded = true;
    } catch (_) {
      // .env missing or malformed -> run in unconfigured mode.
      _loaded = false;
    }
  }

  static bool get loaded => _loaded;

  static String get supabaseUrl => dotenv.maybeGet('SUPABASE_URL') ?? '';
  static String get supabaseAnonKey =>
      dotenv.maybeGet('SUPABASE_ANON_KEY') ?? '';
  static String get revenueCatAppleKey =>
      dotenv.maybeGet('REVENUECAT_APPLE_API_KEY') ?? '';
  static String get revenueCatGoogleKey =>
      dotenv.maybeGet('REVENUECAT_GOOGLE_API_KEY') ?? '';

  /// The app cannot work without a backend connection.
  static bool get isConfigured =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  static bool get isRevenueCatConfigured =>
      revenueCatAppleKey.isNotEmpty || revenueCatGoogleKey.isNotEmpty;
}
