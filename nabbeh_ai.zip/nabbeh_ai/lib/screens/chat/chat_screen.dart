import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/errors/app_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../models/chat_message.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/message_bubble.dart';
import '../../widgets/limit_sheet.dart';

/// Live chat with NABBEH AI (text + optional attached image).
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final ImagePicker _picker = ImagePicker();

  Uint8List? _attachedBytes;
  String _attachedMime = 'image/jpeg';

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _attach() async {
    try {
      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: AppConstants.maxPickDimension.toDouble(),
        imageQuality: AppConstants.pickQuality,
      );
      if (file == null) return;
      final Uint8List bytes = await file.readAsBytes();
      if (bytes.lengthInBytes > AppConstants.maxImageBytes) {
        throw const AppException(AppErrorType.imageTooLarge);
      }
      if (!mounted) return;
      setState(() {
        _attachedBytes = bytes;
        _attachedMime = file.mimeType ?? 'image/jpeg';
      });
    } on AppException catch (e) {
      if (!mounted) return;
      if (e.type == AppErrorType.imageTooLarge) {
        Helpers.showSnack(context, S.of(context).imageTooLarge, error: true);
      } else {
        Helpers.showSnack(context, S.of(context).uploadFailed, error: true);
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, S.of(context).uploadFailed, error: true);
    }
  }

  Future<void> _send() async {
    final String text = _input.text.trim();
    if ((text.isEmpty && _attachedBytes == null)) return;
    final ChatProvider chat = context.read<ChatProvider>();
    final S s = S.of(context);

    final Uint8List? bytes = _attachedBytes;
    final String mime = _attachedMime;

    setState(() {
      _input.clear();
      _attachedBytes = null;
    });
    _scrollToBottom();

    try {
      await chat.sendMessage(
        text: text,
        imageBase64: bytes == null ? null : base64Encode(bytes),
        imageMime: bytes == null ? null : mime,
      );
      if (!mounted) return;
      setState(() {});
      _scrollToBottom();
    } on AppException catch (e) {
      if (!mounted) return;
      if (e.isLimitReached) {
        await showLimitReachedSheet(context, e.type);
      } else {
        Helpers.showSnack(context, s.serverError, error: true);
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.networkError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final ChatProvider chat = context.watch<ChatProvider>();
    final AuthProvider auth = context.watch<AuthProvider>();
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    if (!auth.isSignedIn) {
      return Scaffold(
        appBar: AppBar(title: Text(s.chatTitle)),
        body: EmptyState(
          icon: Icons.lock_outline_rounded,
          title: s.loginRequired,
          subtitle: s.signInToContinue,
        ),
      );
    }

    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (didPop) {
          context.read<ChatProvider>().loadConversations();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: const BoxDecoration(
                  gradient: AppColors.brandGradient,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.auto_awesome,
                    color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Text(s.chatTitle),
            ],
          ),
        ),
        body: Column(
          children: <Widget>[
            Expanded(
              child: chat.loadingMessages && chat.messages.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : chat.messages.isEmpty
                      ? EmptyState(
                          icon: Icons.auto_awesome_outlined,
                          title: s.chatEmptyTitle,
                          subtitle: s.chatEmptySubtitle,
                        )
                      : ListView.builder(
                            controller: _scroll,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 12),
                            itemCount: chat.messages.length +
                                (chat.sending ? 1 : 0),
                            itemBuilder: (BuildContext context, int index) {
                              if (index == chat.messages.length) {
                                return _ThinkingBubble(isDark: isDark);
                              }
                              final ChatMessage m = chat.messages[index];
                              return MessageBubble(message: m);
                            },
                          ),
            ),
            if (_attachedBytes != null)
              Container(
                margin: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isDark ? AppColors.darkCard : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Theme.of(context).dividerColor),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.memory(
                        _attachedBytes!,
                        width: 44,
                        height: 44,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        s.imageAttached,
                        style: const TextStyle(fontSize: 13),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 18),
                      onPressed: () =>
                          setState(() => _attachedBytes = null),
                    ),
                  ],
                ),
              ),
            SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    IconButton(
                      onPressed: _attach,
                      icon: Icon(
                        Icons.add_photo_alternate_outlined,
                        color: Colors.grey.shade500,
                      ),
                      tooltip: s.attachImage,
                    ),
                    Expanded(
                      child: TextField(
                        controller: _input,
                        minLines: 1,
                        maxLines: 5,
                        textInputAction: TextInputAction.newline,
                        decoration: InputDecoration(
                          hintText: s.typeMessage,
                          fillColor:
                              isDark ? AppColors.darkCard : Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 46,
                      height: 46,
                      decoration: const BoxDecoration(
                        gradient: AppColors.brandGradient,
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        onPressed: chat.sending ? null : _send,
                        icon: chat.sending
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.send_rounded,
                                color: Colors.white, size: 20),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ThinkingBubble extends StatelessWidget {
  const _ThinkingBubble({required this.isDark});

  final bool isDark;

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    return Align(
      alignment: AlignmentDirectional.centerStart,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : Colors.white,
          borderRadius: const BorderRadiusDirectional.only(
            topStart: Radius.circular(4),
            topEnd: Radius.circular(18),
            bottomStart: Radius.circular(18),
            bottomEnd: Radius.circular(18),
          ),
          border: Border.all(
            color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            const SizedBox(width: 10),
            Text(
              s.aiThinking,
              style: TextStyle(fontSize: 13, color: Colors.grey.shade500),
            ),
          ],
        ),
      ),
    );
  }
}
