import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/errors/app_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/creation_provider.dart';
import '../../providers/settings_provider.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/section_header.dart';
import '../../widgets/limit_sheet.dart';

/// Upload a photo + optional question -> AI analysis result.
class ImageAnalysisScreen extends StatefulWidget {
  const ImageAnalysisScreen({super.key});

  @override
  State<ImageAnalysisScreen> createState() => _ImageAnalysisScreenState();
}

class _ImageAnalysisScreenState extends State<ImageAnalysisScreen> {
  final TextEditingController _question = TextEditingController();

  Future<void> _pick() async {
    final CreationProvider creation = context.read<CreationProvider>();
    try {
      await creation.pickSourceImage(forAnalysis: true);
    } on AppException catch (e) {
      if (!mounted) return;
      Helpers.showSnack(
        context,
        e.type == AppErrorType.imageTooLarge
            ? S.of(context).imageTooLarge
            : S.of(context).uploadFailed,
        error: true,
      );
    }
  }

  Future<void> _analyze() async {
    final CreationProvider creation = context.read<CreationProvider>();
    final SettingsProvider settings = context.read<SettingsProvider>();
    final S s = S.of(context);
    try {
      await creation.analyze(
        question: _question.text,
        language: settings.locale.languageCode,
      );
    } on AppException catch (e) {
      if (!mounted) return;
      if (e.isLimitReached) {
        await showLimitReachedSheet(context, e.type);
      } else {
        Helpers.showSnack(context, s.serverError, error: true);
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.networkError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final CreationProvider creation = context.watch<CreationProvider>();
    final Uint8List? source = creation.analysisBytes;

    return Scaffold(
      appBar: AppBar(title: Text(s.featureAnalyzeTitle)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            GestureDetector(
              onTap: _pick,
              child: Container(
                height: 220,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Theme.of(context).dividerColor,
                    width: 1.4,
                  ),
                ),
                child: source == null
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.image_search_rounded,
                              size: 42, color: AppColors.success),
                          const SizedBox(height: 10),
                          Text(s.chooseImage,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600)),
                        ],
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Image.memory(source, fit: BoxFit.cover),
                      ),
              ),
            ),
            const SizedBox(height: 18),
            SectionHeader(title: s.analyzeQuestionLabel),
            TextField(
              controller: _question,
              decoration: InputDecoration(hintText: s.analyzeQuestionHint),
            ),
            const SizedBox(height: 20),
            PrimaryButton(
              label: s.analyzeImage,
              icon: Icons.psychology_alt_rounded,
              onPressed: source == null ? null : _analyze,
              busy: creation.busy,
              gradient: AppColors.analyzeGradient,
            ),
            const SizedBox(height: 24),
            if (creation.busy)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 14),
                    Text(s.analyzing,
                        style: TextStyle(color: Colors.grey.shade500)),
                  ],
                ),
              )
            else if (creation.analysisText != null &&
                creation.analysisText!.isNotEmpty) ...[
              SectionHeader(title: s.analysisResult),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? AppColors.darkCard
                      : Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border:
                      Border.all(color: Theme.of(context).dividerColor),
                ),
                child: SelectableText(
                  creation.analysisText!,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(
                          ClipboardData(text: creation.analysisText ?? ''),
                        );
                        if (!context.mounted) return;
                        Helpers.showSnack(
                            context, S.of(context).copiedToClipboard);
                      },
                      icon: const Icon(Icons.copy_rounded, size: 18),
                      label: Text(s.copy),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () =>
                          Share.share(creation.analysisText ?? ''),
                      icon: const Icon(Icons.ios_share, size: 18),
                      label: Text(s.share),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
