import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../models/generation.dart';

/// Masonry-less responsive grid tile for generated images.
class GenerationGridTileWidget extends StatelessWidget {
  const GenerationGridTileWidget({
    super.key,
    required this.generation,
    required this.onTap,
  });

  final Generation generation;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          fit: StackFit.expand,
          children: [
            CachedNetworkImage(
              imageUrl: generation.resultUrl ?? '',
              fit: BoxFit.cover,
              placeholder: (_, __) => Container(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkCard
                    : AppColors.lightBorder,
              ),
              errorWidget: (_, __, ___) => Container(
                color: AppColors.error.withAlpha(40),
                child: const Icon(Icons.broken_image_outlined),
              ),
            ),
            if (generation.isFavorite)
              const PositionedDirectional(
                top: 8,
                end: 8,
                child: Icon(
                  Icons.star_rounded,
                  color: AppColors.star,
                  size: 22,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Reusable images grid (gallery / history / favorites).
class GenerationGrid extends StatelessWidget {
  const GenerationGrid({
    super.key,
    required this.generations,
    required this.onTap,
    this.padding = const EdgeInsets.all(16),
  });

  final List<Generation> generations;
  final void Function(Generation) onTap;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: padding,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
      ),
      itemCount: generations.length,
      itemBuilder: (BuildContext context, int index) =>
          GenerationGridTileWidget(
        generation: generations[index],
        onTap: () => onTap(generations[index]),
      ),
    );
  }
}
