import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../models/app_user.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/credit_chip.dart';
import '../../widgets/pro_badge.dart';
import '../../widgets/section_header.dart';
import '../../widgets/primary_button.dart';
import '../auth/login_screen.dart';
import '../favorites/favorites_screen.dart';
import '../gallery/gallery_screen.dart';
import '../paywall/paywall_screen.dart';
import '../settings/settings_screen.dart';

/// User account: identity, plan, credits, quick links.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _editName(BuildContext context) async {
    final AuthProvider auth = context.read<AuthProvider>();
    final S s = S.of(context);
    final TextEditingController name =
        TextEditingController(text: auth.profile?.displayName ?? '');
    final bool? saved = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text(s.editNameTitle),
        content: TextField(
          controller: name,
          decoration: InputDecoration(hintText: s.fullNameHint),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(s.cancel),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(s.save),
          ),
        ],
      ),
    );
    if (saved == true && name.text.trim().isNotEmpty) {
      await auth.updateDisplayName(name.text.trim());
    }
  }

  Future<void> _signOut(BuildContext context) async {
    final S s = S.of(context);
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text(s.logout),
        content: Text(s.logoutConfirm),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(s.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(
              s.logout,
              style: const TextStyle(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      final AuthProvider auth = context.read<AuthProvider>();
      await auth.signOut();
      if (!context.mounted) return;
      Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
        MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
        (Route<dynamic> route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final AuthProvider auth = context.watch<AuthProvider>();
    final AppUser? profile = auth.profile;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 8),
          // Header card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: auth.isPro
                  ? AppColors.proGradient
                  : AppColors.brandGradient,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white.withAlpha(60),
                      child: Text(
                        profile?.initial ?? 'N',
                        style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  Helpers.clamp(
                                      profile?.name ?? s.guestAccount, 18),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 18,
                                  ),
                                ),
                              ),
                              if (auth.isPro) ...[
                                const SizedBox(width: 8),
                                const ProBadge(height: 22),
                              ],
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            profile?.email ??
                                (profile?.isAnonymous == true
                                    ? s.guestAccount
                                    : ''),
                            style: TextStyle(
                              color: Colors.white.withAlpha(220),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(36),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.bolt, color: Colors.white, size: 22),
                      const SizedBox(width: 8),
                      Text(
                        s.creditsBalance,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600),
                      ),
                      const Spacer(),
                      Text(
                        '${profile?.credits ?? 0}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          if (!auth.isPro) ...[
            PrimaryButton(
              label: s.upgradeBannerTitle,
              icon: Icons.workspace_premium,
              onPressed: () => _go(
                context,
                PaywallScreen(focusCreditPacks: false),
              ),
              gradient: AppColors.proGradient,
            ),
            const SizedBox(height: 22),
          ],
          SectionHeader(title: s.tabProfile),
          _Tile(
            icon: Icons.workspace_premium_rounded,
            title: s.manageSubscription,
            onTap: () => _go(context, const PaywallScreen()),
          ),
          _Tile(
            icon: Icons.star_rounded,
            title: s.myFavorites,
            onTap: () => _go(context, const FavoritesScreen()),
          ),
          _Tile(
            icon: Icons.photo_library_rounded,
            title: s.myGallery,
            onTap: () => _go(context, const GalleryScreen()),
          ),
          _Tile(
            icon: Icons.settings_rounded,
            title: s.settingsTitle,
            onTap: () => _go(context, const SettingsScreen()),
          ),
          _Tile(
            icon: Icons.edit_rounded,
            title: s.editProfile,
            onTap: () => _editName(context),
          ),
          const SizedBox(height: 8),
          _Tile(
            icon: Icons.logout_rounded,
            title: s.signOut,
            danger: true,
            onTap: () => _signOut(context),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              profile?.createdAt == null
                  ? ''
                  : s.memberSince(
                      Helpers.formatDay(
                        profile!.createdAt!,
                        Localizations.localeOf(context).languageCode,
                      ),
                    ),
              style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: CreditChip(
              credits: auth.credits,
              onTap: () => _go(
                context,
                PaywallScreen(focusCreditPacks: true),
              ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  void _go(BuildContext context, Widget page) {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (_) => page));
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.danger = false,
  });

  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: isDark ? AppColors.darkSurface : Colors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border:
                  Border.all(color: Theme.of(context).dividerColor),
            ),
            child: Row(
              children: [
                Icon(icon,
                    size: 21,
                    color: danger
                        ? AppColors.error
                        : Theme.of(context).colorScheme.primary),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14.5,
                      color: danger ? AppColors.error : null,
                    ),
                  ),
                ),
                Icon(Icons.chevron_right,
                    size: 20, color: Colors.grey.shade500),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
