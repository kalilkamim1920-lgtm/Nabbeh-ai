import 'dart:convert';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/errors/app_exception.dart';

/// Talks to the secure Supabase Edge Functions backend.
///
/// The app NEVER talks to AI providers directly. The backend chooses the
/// provider (OpenAI / Gemini / OpenRouter / Groq / Stability), enforces
/// usage limits and credits, and stores results.
class AiService {
  AiService._();

  static FunctionsClient get _functions =>
      Supabase.instance.client.functions;

  static Future<Map<String, dynamic>> _invoke(
    String name,
    Map<String, dynamic> body,
  ) async {
    try {
      final FunctionResponse res = await _functions.invoke(name, body: body);
      final dynamic data = res.data;
      if (data is Map<String, dynamic>) return data;
      if (data is String) {
        return jsonDecode(data) as Map<String, dynamic>;
      }
      throw const AppException(AppErrorType.server);
    } on FunctionException catch (e) {
      throw _mapFunctionException(e);
    } on AppException {
      rethrow;
    } catch (_) {
      throw const AppException(AppErrorType.network);
    }
  }

  static AppException _mapFunctionException(FunctionException e) {
    Map<String, dynamic>? body;
    final dynamic details = e.details;
    if (details is Map<String, dynamic>) {
      body = details;
    } else if (details is String && details.isNotEmpty) {
      try {
        final dynamic decoded = jsonDecode(details);
        if (decoded is Map<String, dynamic>) body = decoded;
      } catch (_) {/* ignore */}
    }

    if (body?['error'] == 'limit_reached') {
      switch (body?['type']) {
        case 'daily_chat':
          return const AppException(AppErrorType.limitDailyChat);
        case 'daily_images':
          return const AppException(AppErrorType.limitDailyImages);
        default:
          return const AppException(AppErrorType.limitCredits);
      }
    }
    if (e.status == 401 || e.status == 403) {
      return const AppException(AppErrorType.unauthorized);
    }
    if (e.status >= 500) {
      return AppException(AppErrorType.server, body?['message']);
    }
    return AppException(
      AppErrorType.server,
      (body?['message'] ?? body?['error'])?.toString(),
    );
  }

  // ----- Chat -----

  static Future<Map<String, dynamic>> chat({
    String? conversationId,
    required String message,
    String? imageBase64,
    String? imageMime,
    String language = 'en',
  }) {
    return _invoke('chat', {
      'conversation_id': conversationId,
      'message': message,
      'image_base64': imageBase64,
      'image_mime': imageMime,
      'language': language,
    });
  }

  // ----- Image generation -----

  static Future<Map<String, dynamic>> generateImage({
    required String prompt,
    String? style,
    required String aspectRatio,
    String language = 'en',
  }) {
    return _invoke('generate-image', {
      'prompt': prompt,
      'style': style,
      'aspect_ratio': aspectRatio,
      'language': language,
    });
  }

  // ----- Image editing -----

  static Future<Map<String, dynamic>> editImage({
    required String imageBase64,
    required String imageMime,
    required String instruction,
    String? style,
    String language = 'en',
  }) {
    return _invoke('edit-image', {
      'image_base64': imageBase64,
      'image_mime': imageMime,
      'instruction': instruction,
      'style': style,
      'language': language,
    });
  }

  // ----- Image analysis -----

  static Future<Map<String, dynamic>> analyzeImage({
    required String imageBase64,
    required String imageMime,
    String? question,
    String language = 'en',
  }) {
    return _invoke('analyze-image', {
      'image_base64': imageBase64,
      'image_mime': imageMime,
      'question': question,
      'language': language,
    });
  }

  // ----- Prompt generation -----

  static Future<Map<String, dynamic>> generatePrompts({
    required String idea,
    required String platform,
    String? style,
    String language = 'en',
  }) {
    return _invoke('generate-prompt', {
      'idea': idea,
      'platform': platform,
      'style': style,
      'language': language,
    });
  }

  // ----- Subscription sync (server verifies entitlement) -----

  /// [demo] is honoured by the backend ONLY while RevenueCat secrets are
  /// not configured on the server — a safe dev-mode switch, not a bypass.
  static Future<Map<String, dynamic>?> syncSubscription({bool demo = false}) async {
    try {
      return await _invoke('sync-subscription', {'demo': demo});
    } on AppException {
      rethrow;
    } catch (_) {
      return null;
    }
  }
}
