import 'package:flutter/material.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/auth_provider.dart';
import '../../providers/subscription_provider.dart';

/// NABBEH PRO paywall: Free vs PRO comparison, subscription packages,
/// and one-time credit packs — all driven by RevenueCat offerings.
class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key, this.focusCreditPacks = false});

  final bool focusCreditPacks;

  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SubscriptionProvider>().loadOfferings();
      context.read<SubscriptionProvider>().syncWithBackend(
            context.read<AuthProvider>(),
          );
    });
  }

  Future<void> _buy(Package package) async {
    final SubscriptionProvider sub = context.read<SubscriptionProvider>();
    final AuthProvider auth = context.read<AuthProvider>();
    final S s = S.of(context);
    try {
      final bool ok = await sub.purchase(package, auth);
      if (!mounted) return;
      if (ok) {
        Helpers.showSnack(context, s.purchaseSuccess);
        Navigator.of(context).pop();
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.purchaseFailed, error: true);
    }
  }

  Future<void> _restore() async {
    final SubscriptionProvider sub = context.read<SubscriptionProvider>();
    final AuthProvider auth = context.read<AuthProvider>();
    final S s = S.of(context);
    try {
      await sub.restore(auth);
      if (!mounted) return;
      Helpers.showSnack(context, s.restored);
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.serverError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final SubscriptionProvider sub = context.watch<SubscriptionProvider>();
    final AuthProvider auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(s.manageSubscription)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: AppColors.proGradient,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: [
                const Icon(Icons.workspace_premium,
                    size: 46, color: Color(0xFF5C3A00)),
                const SizedBox(height: 8),
                Text(
                  s.paywallTitle,
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF5C3A00),
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  s.paywallSubtitle,
                  style: TextStyle(
                    color: const Color(0xFF5C3A00).withAlpha(200),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),

          // Demo mode notice
          if (!sub.revenueCatReady) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.warning.withAlpha(30),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.warning),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline,
                      color: AppColors.warning, size: 22),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s.demoModeTitle,
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                color: AppColors.warning)),
                        const SizedBox(height: 4),
                        Text(s.demoModeBody,
                            style: const TextStyle(fontSize: 12.5)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // Comparison
          _CompareTable(isPro: auth.isPro),
          const SizedBox(height: 26),

          // Subscription packages
          if (sub.revenueCatReady) ...[
            if (sub.loading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: CircularProgressIndicator(),
                ),
              )
            else ...[
              _PackageList(
                packages: sub.subscriptionPackages,
                sub: sub,
                onBuy: _buy,
                s: s,
                purchasing: sub.purchasing,
              ),
              const SizedBox(height: 24),
            ],
          ],

          // Credit packs
          _SectionTitle(title: s.creditPacksTitle),
          Text(s.creditPacksSubtitle,
              style: TextStyle(color: Colors.grey.shade500, fontSize: 12.5)),
          const SizedBox(height: 12),
          if (sub.revenueCatReady)
            _PackageList(
              packages: sub.creditPackages,
              sub: sub,
              onBuy: _buy,
              s: s,
              purchasing: sub.purchasing,
            )
          else
            _DemoCreditPacks(),
          const SizedBox(height: 24),

          if (sub.revenueCatReady)
            TextButton(
              onPressed: _restore,
              child: Text(s.restorePurchases),
            ),
          Text(
            s.subscriptionNote,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade500, fontSize: 11.5),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .titleLarge
            ?.copyWith(fontSize: 18),
      ),
    );
  }
}

class _CompareTable extends StatelessWidget {
  const _CompareTable({required this.isPro});

  final bool isPro;

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color card = isDark ? AppColors.darkSurface : Colors.white;

    final List<(String, String)> rows = <(String, String)>[
      (s.featureMessagesFree, s.featureMessagesPro),
      (s.featureImagesFree, s.featureImagesPro),
      (s.featureQualityStandard, s.featureQualityHd),
      (s.featureEditFree, s.featureEditPro),
      (s.featurePriorityFree, s.featurePriorityPro),
      (s.featureAdsFree, s.featureAdsPro),
    ];

    return Container(
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Theme.of(context).dividerColor),
              ),
            ),
            child: Row(
              children: [
                const Expanded(child: SizedBox()),
                SizedBox(
                  width: 92,
                  child: Text(
                    s.freeLabel,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12.5,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ),
                Container(
                  width: 92,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  decoration: BoxDecoration(
                    gradient: AppColors.proGradient,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    s.proLabel,
                    style: const TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 12.5,
                      color: Color(0xFF5C3A00),
                    ),
                  ),
                ),
              ],
            ),
          ),
          ...rows.map(
            ((String, String) row) => Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Theme.of(context).dividerColor),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      row.$1,
                      style: const TextStyle(fontSize: 12.5),
                    ),
                  ),
                  SizedBox(
                    width: 92,
                    child: Icon(Icons.close_rounded,
                        size: 17, color: Colors.grey.shade400),
                  ),
                  SizedBox(
                    width: 92,
                    child: Icon(Icons.check_circle_rounded,
                        size: 17, color: AppColors.success),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PackageList extends StatelessWidget {
  const _PackageList({
    required this.packages,
    required this.sub,
    required this.onBuy,
    required this.s,
    required this.purchasing,
  });

  final List<Package> packages;
  final SubscriptionProvider sub;
  final Future<void> Function(Package) onBuy;
  final S s;
  final bool purchasing;

  @override
  Widget build(BuildContext context) {
    if (packages.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Text(
          '—  ${s.loading}',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.grey.shade500),
        ),
      );
    }
    return Column(
      children: packages.map((Package package) {
        final bool isYearly = sub.isYearly(package);
        final bool isCredit = sub.isCreditPack(package);
        final String price = sub.priceFor(package);
        String title;
        if (isCredit) {
          switch (package.storeProduct.identifier) {
            case AppConstants.productIdCreditsLarge:
              title = s.creditsLarge;
              break;
            case AppConstants.productIdCreditsMedium:
              title = s.creditsMedium;
              break;
            default:
              title = s.creditsSmall;
          }
        } else {
          title = isYearly ? s.yearlyPlan : s.monthlyPlan;
        }
        final String suffix =
            isCredit ? '' : (isYearly ? s.perYear : s.perMonth);

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Material(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkSurface
                    : Colors.white,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  onTap: purchasing ? null : () => onBuy(package),
                  borderRadius: BorderRadius.circular(18),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: isYearly
                            ? AppColors.primary
                            : Theme.of(context).dividerColor,
                        width: isYearly ? 1.6 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isCredit
                              ? Icons.bolt_rounded
                              : isYearly
                                  ? Icons.calendar_month_rounded
                                  : Icons.event_repeat_rounded,
                          color: AppColors.primary,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                ),
                              ),
                              Text(
                                package.storeProduct.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  color: Colors.grey.shade500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '$price $suffix'.trim(),
                          style: const TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (isYearly)
                PositionedDirectional(
                  top: -8,
                  end: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      gradient: AppColors.proGradient,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      s.saveBadge(35),
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF5C3A00),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _DemoCreditPacks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    return Column(
      children: <Widget>[
        _demoRow(
          context,
          s.creditsSmall,
          AppConstants.demoPrices[AppConstants.productIdCreditsSmall]!,
        ),
        _demoRow(
          context,
          s.creditsMedium,
          AppConstants.demoPrices[AppConstants.productIdCreditsMedium]!,
        ),
        _demoRow(
          context,
          s.creditsLarge,
          AppConstants.demoPrices[AppConstants.productIdCreditsLarge]!,
        ),
      ],
    );
  }

  Widget _demoRow(BuildContext context, String title, String price) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          const Icon(Icons.bolt_rounded, color: AppColors.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Text(title,
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 15)),
          ),
          Text(price,
              style: const TextStyle(
                  fontWeight: FontWeight.w900, fontSize: 15)),
        ],
      ),
    );
  }
}
