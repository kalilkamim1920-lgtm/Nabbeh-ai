/// Types of errors the UI knows how to present.
enum AppErrorType {
  network,
  server,
  unauthorized,
  limitDailyChat,
  limitDailyImages,
  limitCredits,
  imageTooLarge,
  uploadFailed,
}

/// A typed exception thrown by services/repositories and translated into
/// localized messages by the UI layer.
class AppException implements Exception {
  const AppException(this.type, [this.detail]);

  final AppErrorType type;
  final String? detail;

  bool get isLimitReached =>
      type == AppErrorType.limitDailyChat ||
      type == AppErrorType.limitDailyImages ||
      type == AppErrorType.limitCredits;

  @override
  String toString() => 'AppException($type, $detail)';
}
