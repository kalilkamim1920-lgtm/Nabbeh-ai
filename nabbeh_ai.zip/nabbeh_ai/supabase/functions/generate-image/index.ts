// NABBEH AI — text-to-image generation.
// POST /functions/v1/generate-image
// body: { prompt, style?, aspect_ratio, language? }

import {
  adminClient,
  aiImage,
  consume,
  COSTS,
  corsHeaders,
  fail,
  getProfile,
  json,
  refillIfNeeded,
  requireUser,
  saveGeneration,
  uploadToStorage,
} from "../_shared/utils.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return fail("bad_request", "method", "POST only", 405);
  }

  const auth = await requireUser(req);
  if (auth instanceof Response) return auth;
  const admin = adminClient();

  try {
    const body = await req.json();
    const prompt: string = (body.prompt ?? "").toString().trim();
    const style: string | null = body.style ? body.style.toString() : null;
    const aspectRatio: string = (body.aspect_ratio ?? "1:1").toString();

    if (!prompt) {
      return fail("bad_request", "input", "prompt is required", 400);
    }

    let profile = await getProfile(admin, auth.user.id);
    if (!profile) return fail("unauthorized", "profile", "Profile missing", 401);
    profile = await refillIfNeeded(admin, profile);

    // PRO users get HD quality (higher credit cost).
    const hd = profile.plan === "pro";
    const cost = hd ? COSTS.image_hd : COSTS.image;

    const result = await consume(admin, profile, "image", cost);
    if (result instanceof Response) return result;

    // Style suffix + priority note for PRO.
    const styleHint = style ? styleHints[style] ?? "" : "";
    const fullPrompt = [prompt, styleHint].filter(Boolean).join(", ");

    const bytes = await aiImage({
      prompt: fullPrompt,
      aspectRatio,
      hd,
    });
    const url = await uploadToStorage(admin, auth.user.id, bytes);

    const generation = await saveGeneration(admin, auth.user.id, {
      type: "image",
      prompt,
      result_url: url,
      style,
      metadata: { aspect_ratio: aspectRatio, quality: hd ? "hd" : "standard" },
    });

    return json({
      generation,
      image_url: url,
      credits_left: result.creditsLeft,
      plan: profile.plan,
    });
  } catch (e) {
    return fail("server", "ai", e instanceof Error ? e.message : String(e), 500);
  }
});

const styleHints: Record<string, string> = {
  realistic: "ultra realistic photograph, natural lighting, 8k, sharp focus",
  anime: "anime style, vibrant colors, studio anime key visual, clean lineart",
  digital_art: "digital art, intricate details, trending on artstation",
  "3d_render": "3d render, octane render, soft studio lighting, high detail",
  watercolor: "delicate watercolor painting, textured paper, soft washes",
  cyberpunk: "cyberpunk style, neon lights, rain, cinematic atmosphere",
  minimal: "minimalist flat design, clean geometric shapes, pastel palette",
  logo: "clean vector logo design, flat, centered, white background",
};
