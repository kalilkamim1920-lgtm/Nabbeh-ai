// NABBEH AI — prompt engineering helper (3 polished prompts per idea).
// POST /functions/v1/generate-prompt
// body: { idea, platform, style?, language? }

import {
  adminClient,
  aiChat,
  consume,
  COSTS,
  corsHeaders,
  fail,
  getProfile,
  json,
  refillIfNeeded,
  requireUser,
  saveGeneration,
} from "../_shared/utils.ts";

const PROMPT_ENGINEER_PROMPT = `You are NABBEH AI, a world-class prompt engineer.
The user gives you a rough idea and a target AI platform.
Produce EXACTLY 3 high-quality, ready-to-use prompts optimized for that platform.
Each prompt must be a single paragraph, 40-80 words, rich in concrete visual/writing details.
Separate the three prompts with a line containing only '---'.
Do not add numbering, titles, explanations or any extra text.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return fail("bad_request", "method", "POST only", 405);
  }

  const auth = await requireUser(req);
  if (auth instanceof Response) return auth;
  const admin = adminClient();

  try {
    const body = await req.json();
    const idea: string = (body.idea ?? "").toString().trim();
    const platform: string = (body.platform ?? "generic").toString();
    const language: string = (body.language ?? "en").toString();

    if (!idea) {
      return fail("bad_request", "input", "idea is required", 400);
    }

    let profile = await getProfile(admin, auth.user.id);
    if (!profile) return fail("unauthorized", "profile", "Profile missing", 401);
    profile = await refillIfNeeded(admin, profile);

    const result = await consume(admin, profile, "chat", COSTS.prompt);
    if (result instanceof Response) return result;

    const userText =
      `Idea: ${idea}\nTarget platform: ${platform}\n` +
      (language === "ar"
        ? "Write the prompts in Arabic."
        : "Write the prompts in English.");

    const { text } = await aiChat(PROMPT_ENGINEER_PROMPT, [], userText);

    const prompts = text
      .split("---")
      .map((p) => p.replace(/^\s*\d+[.)]\s*/gm, "").trim())
      .filter((p) => p.length > 0)
      .slice(0, 3);

    await saveGeneration(admin, auth.user.id, {
      type: "prompt",
      prompt: idea,
      result_text: prompts.join("\n\n"),
      metadata: { platform },
    });

    return json({
      prompts,
      credits_left: result.creditsLeft,
      plan: profile.plan,
    });
  } catch (e) {
    return fail("server", "ai", e instanceof Error ? e.message : String(e), 500);
  }
});
