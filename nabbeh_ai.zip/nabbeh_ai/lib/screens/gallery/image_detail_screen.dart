import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../models/generation.dart';
import '../../providers/gallery_provider.dart';

/// Full view of one generated image: favorite, share, copy prompt, delete.
class ImageDetailScreen extends StatefulWidget {
  const ImageDetailScreen({super.key, required this.generation});

  final Generation generation;

  @override
  State<ImageDetailScreen> createState() => _ImageDetailScreenState();
}

class _ImageDetailScreenState extends State<ImageDetailScreen> {
  late bool _favorite = widget.generation.isFavorite;

  Future<void> _delete() async {
    final S s = S.of(context);
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text(s.deleteImageTitle),
        content: Text(s.deleteImageBody),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(s.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(s.delete,
                style: const TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    await context.read<GalleryProvider>().deleteImage(widget.generation);
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final Generation g = widget.generation;
    final String styleLabel = switch (g.style) {
      'realistic' => s.styleRealistic,
      'anime' => s.styleAnime,
      'digital_art' => s.styleDigitalArt,
      '3d_render' => s.style3D,
      'watercolor' => s.styleWatercolor,
      'cyberpunk' => s.styleCyberpunk,
      'minimal' => s.styleMinimal,
      'logo' => s.styleLogo,
      _ => s.styleNone,
    };

    return Scaffold(
      appBar: AppBar(
        title: Text(s.imageDetails),
        actions: [
          IconButton(
            tooltip: s.delete,
            onPressed: _delete,
            icon: const Icon(Icons.delete_outline, color: AppColors.error),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: CachedNetworkImage(
              imageUrl: g.resultUrl ?? '',
              fit: BoxFit.cover,
              placeholder: (_, __) => const AspectRatio(
                aspectRatio: 1,
                child: Center(child: CircularProgressIndicator()),
              ),
              errorWidget: (_, __, ___) => const AspectRatio(
                aspectRatio: 1,
                child: Center(child: Icon(Icons.broken_image_outlined)),
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (g.prompt != null && g.prompt!.isNotEmpty) ...[
            Text(s.copyPrompt,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppColors.darkCard
                    : Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SelectableText(g.prompt!,
                      style: Theme.of(context).textTheme.bodyLarge),
                  const SizedBox(height: 8),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () async {
                        await Clipboard.setData(
                            ClipboardData(text: g.prompt ?? ''));
                        if (!context.mounted) return;
                        Helpers.showSnack(
                            context, s.copiedToClipboard);
                      },
                      icon: const Icon(Icons.copy_rounded, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
          ],
          Row(
            children: [
              _Meta(
                icon: Icons.style_rounded,
                label: styleLabel,
              ),
              const SizedBox(width: 12),
              _Meta(
                icon: Icons.schedule_rounded,
                label: Helpers.formatDay(
                    g.createdAt,
                    Localizations.localeOf(context).languageCode),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    setState(() => _favorite = !_favorite);
                    await context
                        .read<GalleryProvider>()
                        .toggleFavorite(g);
                    if (!context.mounted) return;
                    Helpers.showSnack(
                      context,
                      _favorite ? s.favoriteAdded : s.favoriteRemoved,
                    );
                  },
                  icon: Icon(
                    _favorite
                        ? Icons.star_rounded
                        : Icons.star_border_rounded,
                    size: 20,
                    color: AppColors.star,
                  ),
                  label: Text(s.favoritesTitle),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Share.share(g.resultUrl ?? ''),
                  icon: const Icon(Icons.ios_share, size: 18),
                  label: Text(s.share),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? AppColors.darkCard
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Colors.grey.shade500),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5),
            ),
          ),
        ],
      ),
    );
  }
}
