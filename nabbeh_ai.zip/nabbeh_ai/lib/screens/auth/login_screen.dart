import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/app_logo.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/styled_text_field.dart';
import '../main_shell.dart';

/// Email/password sign-in + sign-up + guest mode + password reset.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirm = TextEditingController();
  final TextEditingController _name = TextEditingController();

  bool _isSignUp = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    _name.dispose();
    super.dispose();
  }

  S get s => S.of(context);

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final AuthProvider auth = context.read<AuthProvider>();
    try {
      if (_isSignUp) {
        await auth.signUp(_email.text.trim(), _password.text, _name.text.trim());
      } else {
        await auth.signIn(_email.text.trim(), _password.text);
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const MainShell()),
      );
    } catch (e) {
      if (!mounted) return;
      Helpers.showSnack(context, s.mapKey(Helpers.mapAuthError(e)),
          error: true);
    }
  }

  Future<void> _guest() async {
    final AuthProvider auth = context.read<AuthProvider>();
    try {
      await auth.signInAsGuest();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const MainShell()),
      );
    } catch (e) {
      if (!mounted) return;
      Helpers.showSnack(context, s.mapKey(Helpers.mapAuthError(e)),
          error: true);
    }
  }

  Future<void> _resetPassword() async {
    final String email = _email.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      Helpers.showSnack(context, s.errEmailInvalid, error: true);
      return;
    }
    final AuthProvider auth = context.read<AuthProvider>();
    try {
      await auth.resetPassword(email);
      if (!mounted) return;
      Helpers.showSnack(context, s.resetPasswordSent);
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.serverError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final AuthProvider auth = context.watch<AuthProvider>();

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const AppLogo(size: 68, showText: true),
                    const SizedBox(height: 28),
                    Text(
                      _isSignUp ? s.createAccountTitle : s.loginTitle,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      s.loginSubtitle,
                      textAlign: TextAlign.center,
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(color: Colors.grey.shade500),
                    ),
                    const SizedBox(height: 28),
                    if (_isSignUp) ...[
                      StyledTextField(
                        controller: _name,
                        hint: s.fullNameHint,
                        label: s.fullName,
                        prefixIcon: Icons.person_outline,
                        validator: (v) =>
                            (v == null || v.trim().isEmpty) ? s.errNameRequired : null,
                      ),
                      const SizedBox(height: 14),
                    ],
                    StyledTextField(
                      controller: _email,
                      hint: s.emailHint,
                      label: s.email,
                      prefixIcon: Icons.alternate_email,
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) =>
                          (v == null || !v.contains('@')) ? s.errEmailInvalid : null,
                    ),
                    const SizedBox(height: 14),
                    StyledTextField(
                      controller: _password,
                      hint: s.passwordHint,
                      label: s.password,
                      prefixIcon: Icons.lock_outline,
                      obscure: true,
                      validator: (v) => (v == null || v.length < 6)
                          ? s.errPasswordShort
                          : null,
                    ),
                    if (_isSignUp) ...[
                      const SizedBox(height: 14),
                      StyledTextField(
                        controller: _confirm,
                        hint: s.confirmPassword,
                        label: s.confirmPassword,
                        prefixIcon: Icons.lock_outline,
                        obscure: true,
                        validator: (v) => (v != _password.text)
                            ? s.errPasswordMismatch
                            : null,
                      ),
                    ],
                    Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: TextButton(
                        onPressed: _resetPassword,
                        child: Text(s.forgotPassword),
                      ),
                    ),
                    const SizedBox(height: 8),
                    PrimaryButton(
                      label: _isSignUp ? s.signUp : s.signIn,
                      onPressed: _submit,
                      busy: auth.loading,
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: auth.loading
                          ? null
                          : () => setState(() => _isSignUp = !_isSignUp),
                      child: Text(_isSignUp ? s.signIn : s.signUp),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        const Expanded(child: Divider()),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Text(
                            s.guestNote,
                            style: TextStyle(
                              color: Colors.grey.shade500,
                              fontSize: 11,
                            ),
                          ),
                        ),
                        const Expanded(child: Divider()),
                      ],
                    ),
                    const SizedBox(height: 18),
                    OutlinedButton(
                      onPressed: auth.loading ? null : _guest,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.bolt, size: 20),
                          const SizedBox(width: 8),
                          Text(s.continueAsGuest),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

extension _SMap on S {
  String mapKey(String key) {
    switch (key) {
      case 'errWrongCredentials':
        return errWrongCredentials;
      case 'errEmailTaken':
        return errEmailTaken;
      case 'errTooManyRequests':
        return errTooManyRequests;
      case 'errNetwork':
        return errNetwork;
      case 'authFailed':
        return authFailed;
      case 'loginRequired':
        return loginRequired;
      case 'networkError':
        return networkError;
      default:
        return authFailed;
    }
  }
}
