// Barrel export so every file imports localization with one stable path:
// `import '../l10n_helper.dart';`
export 'generated/app_localizations.dart';
