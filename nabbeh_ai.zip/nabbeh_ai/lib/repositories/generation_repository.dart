import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/generation.dart';
import '../services/supabase_service.dart';

/// Generated/edited images, analyses and prompts.
class GenerationRepository {
  const GenerationRepository();

  SupabaseClient get _client => SupabaseService.client;
  String? get _uid => SupabaseService.currentUser?.id;

  /// Only visual creations have a URL — used by gallery/history grids.
  Future<List<Generation>> listImageGenerations({
    int limit = 60,
    int offset = 0,
    bool onlyFavorites = false,
  }) async {
    final String? uid = _uid;
    if (uid == null) return [];
    PostgrestFilterBuilder<List<Map<String, dynamic>>> query = _client
        .from('generations')
        .select()
        .eq('user_id', uid)
        .inFilter('type', <String>['image', 'edit'])
        .not('result_url', 'is', null);
    if (onlyFavorites) {
      query = query.eq('is_favorite', true);
    }
    final List<dynamic> rows = await query
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);
    return rows
        .map((e) => Generation.fromMap(e as Map<String, dynamic>))
        .toList();
  }

  Future<Generation> setFavorite(String id, bool favorite) async {
    final List<dynamic> rows = await _client
        .from('generations')
        .update({'is_favorite': favorite})
        .eq('id', id)
        .select()
        .limit(1);
    if (rows.isEmpty) throw StateError('generation not found');
    return Generation.fromMap(rows.first as Map<String, dynamic>);
  }

  Future<void> delete(String id) async {
    await _client.from('generations').delete().eq('id', id);
  }
}
