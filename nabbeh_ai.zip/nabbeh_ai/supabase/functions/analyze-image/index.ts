// NABBEH AI — image analysis (vision).
// POST /functions/v1/analyze-image
// body: { image_base64, image_mime, question?, language? }

import {
  adminClient,
  aiChat,
  consume,
  COSTS,
  corsHeaders,
  fail,
  getProfile,
  json,
  refillIfNeeded,
  requireUser,
  saveGeneration,
} from "../_shared/utils.ts";

const ANALYST_PROMPT =
  "You are NABBEH AI, an expert image analyst. Analyze the provided image and answer " +
  "accurately and helpfully. Describe what you see first, then answer the user's specific " +
  "question if they asked one. Reply in the SAME language the user writes in (Arabic or English). " +
  "Structure the answer with short clear sections.";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return fail("bad_request", "method", "POST only", 405);
  }

  const auth = await requireUser(req);
  if (auth instanceof Response) return auth;
  const admin = adminClient();

  try {
    const body = await req.json();
    const imageBase64: string | null = body.image_base64 ?? null;
    const imageMime: string = (body.image_mime ?? "image/jpeg").toString();
    const question: string = (body.question ?? "").toString().trim();
    const language: string = (body.language ?? "en").toString();

    if (!imageBase64) {
      return fail("bad_request", "input", "image_base64 is required", 400);
    }

    let profile = await getProfile(admin, auth.user.id);
    if (!profile) return fail("unauthorized", "profile", "Profile missing", 401);
    profile = await refillIfNeeded(admin, profile);

    const result = await consume(admin, profile, "chat", COSTS.analysis);
    if (result instanceof Response) return result;

    const { text } = await aiChat(
      ANALYST_PROMPT + (language === "ar" ? " The user interface language is Arabic." : ""),
      [],
      question || "What is in this image? Give a clear, useful analysis.",
      `data:${imageMime};base64,${imageBase64}`,
    );

    const generation = await saveGeneration(admin, auth.user.id, {
      type: "analysis",
      prompt: question || null,
      result_text: text,
      metadata: { mime: imageMime },
    });

    return json({
      generation,
      analysis: text,
      credits_left: result.creditsLeft,
      plan: profile.plan,
    });
  } catch (e) {
    return fail("server", "ai", e instanceof Error ? e.message : String(e), 500);
  }
});
