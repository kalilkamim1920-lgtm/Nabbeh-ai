/// User profile — mirrors the `profiles` table in Supabase.
class AppUser {
  const AppUser({
    required this.id,
    this.email,
    this.displayName,
    this.avatarUrl,
    this.plan = 'free',
    this.credits = 0,
    this.isAnonymous = false,
    this.createdAt,
  });

  final String id;
  final String? email;
  final String? displayName;
  final String? avatarUrl;

  /// 'free' | 'pro' (synced from RevenueCat server-side).
  final String plan;
  final int credits;
  final bool isAnonymous;
  final DateTime? createdAt;

  bool get isPro => plan == 'pro';

  String get name {
    if (displayName != null && displayName!.trim().isNotEmpty) {
      return displayName!.trim();
    }
    if (email != null && email!.trim().isNotEmpty) {
      return email!.split('@').first;
    }
    return 'Guest';
  }

  String get initial => name.isNotEmpty ? name[0].toUpperCase() : 'N';

  factory AppUser.fromMap(Map<String, dynamic> map) {
    return AppUser(
      id: (map['id'] ?? '').toString(),
      email: map['email'] as String?,
      displayName: map['display_name'] as String?,
      avatarUrl: map['avatar_url'] as String?,
      plan: (map['plan'] ?? 'free').toString(),
      credits: (map['credits'] is int)
          ? map['credits'] as int
          : int.tryParse('${map['credits'] ?? 0}') ?? 0,
      isAnonymous: (map['is_anonymous'] ?? false) == true,
      createdAt: map['created_at'] == null
          ? null
          : DateTime.tryParse(map['created_at'].toString()),
    );
  }
}
