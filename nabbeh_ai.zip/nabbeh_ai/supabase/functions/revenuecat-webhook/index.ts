// NABBEH AI — RevenueCat server webhook.
// Configure in RevenueCat Dashboard -> Integrations -> Webhooks:
//   URL:    https://<PROJECT_REF>.supabase.co/functions/v1/revenuecat-webhook
//   Header: Authorization: Bearer <REVENUECAT_WEBHOOK_AUTH>
//
// Handles subscription lifecycle + one-time credit pack purchases.

import { adminClient, corsHeaders, json } from "../_shared/utils.ts";

const CREDIT_PACKS: Record<string, number> = {
  nabbeh_credits_small: 100,
  nabbeh_credits_medium: 500,
  nabbeh_credits_large: 1500,
};

const GRANTING_EVENTS = new Set([
  "INITIAL_PURCHASE",
  "RENEWAL",
  "PRODUCT_CHANGE",
  "NON_RENEWING_PURCHASE",
  "UNCANCELLATION",
]);
const REVOKING_EVENTS = new Set(["EXPIRATION", "REFUND_REVERSED", "CANCELLATION"]);

interface RcEvent {
  type: string;
  app_user_id?: string | null;
  product_id?: string | null;
  transaction_id?: string | null;
  expiration_at_ms?: number | null;
  env?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return json({ error: "POST only" }, 405);
  }

  // Shared-secret authentication for the webhook.
  const expected = Deno.env.get("REVENUECAT_WEBHOOK_AUTH") ?? "";
  const got = (req.headers.get("Authorization") ?? "").replace("Bearer ", "").trim();
  if (!expected || got !== expected) {
    return json({ error: "unauthorized" }, 401);
  }

  const admin = adminClient();

  try {
    const payload = await req.json();
    const event = payload?.event as RcEvent | undefined;
    if (!event?.app_user_id) {
      return json({ ok: true, skipped: "no app_user_id" });
    }
    const userId = event.app_user_id;
    const productId = event.product_id ?? "";
    const transactionId = event.transaction_id ?? `${event.type}:${Date.now()}`;

    // Ensure the profile exists (webhook may arrive before first login).
    const { data: profile } = await admin
      .from("profiles")
      .select("id, plan, credits")
      .eq("id", userId)
      .maybeSingle();
    if (!profile) {
      return json({ ok: true, skipped: "profile not found yet" });
    }

    // ----- Credit pack grant (idempotent) -----
    const packCredits = CREDIT_PACKS[productId];
    if (packCredits && (event.type === "NON_RENEWING_PURCHASE" || event.type === "INITIAL_PURCHASE")) {
      const { data: existing } = await admin
        .from("rc_grants")
        .select("user_id")
        .eq("user_id", userId)
        .eq("product_id", productId)
        .eq("transaction_id", transactionId)
        .maybeSingle();
      if (!existing) {
        await admin
          .from("profiles")
          .update({ credits: (profile.credits as number) + packCredits })
          .eq("id", userId);
        await admin.from("rc_grants").insert({
          user_id: userId,
          product_id: productId,
          transaction_id: transactionId,
        });
        await admin.from("credit_transactions").insert({
          user_id: userId,
          amount: packCredits,
          reason: `credit_pack:${productId}`,
        });
      }
    }

    // ----- Subscription plan sync -----
    if (GRANTING_EVENTS.has(event.type)) {
      // Only subscription products change the plan.
      if (productId.startsWith("nabbeh_pro_")) {
        await admin.from("profiles").update({ plan: "pro" }).eq("id", userId);
      }
    } else if (REVOKING_EVENTS.has(event.type)) {
      if (productId.startsWith("nabbeh_pro_")) {
        await admin.from("profiles").update({ plan: "free" }).eq("id", userId);
      }
    }

    return json({ ok: true });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});
