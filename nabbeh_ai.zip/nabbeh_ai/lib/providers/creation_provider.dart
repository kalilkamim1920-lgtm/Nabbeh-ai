import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

import '../core/constants/app_constants.dart';
import '../core/errors/app_exception.dart';
import '../models/generation.dart';
import '../services/ai_service.dart';

/// State for the four creation flows:
/// image generation / image editing / image analysis / prompt generation.
class CreationProvider extends ChangeNotifier {
  final ImagePicker _picker = ImagePicker();

  // Image generation
  String? _generatedImageUrl;
  Generation? _generated;
  String? _lastPrompt;

  // Image editing
  Uint8List? _sourceBytes;
  String _sourceMime = 'image/jpeg';
  String? _editedImageUrl;
  Generation? _edited;

  // Analysis
  Uint8List? _analysisBytes;
  String _analysisMime = 'image/jpeg';
  String? _analysisText;
  Generation? _analysis;

  // Prompt generator
  List<String> _prompts = <String>[];

  bool _busy = false;

  String? get generatedImageUrl => _generatedImageUrl;
  Generation? get generated => _generated;
  Uint8List? get sourceBytes => _sourceBytes;
  String get sourceMime => _sourceMime;
  String? get editedImageUrl => _editedImageUrl;
  Generation? get edited => _edited;
  Uint8List? get analysisBytes => _analysisBytes;
  String get analysisMime => _analysisMime;
  String? get analysisText => _analysisText;
  Generation? get analysis => _analysis;
  List<String> get prompts => _prompts;
  bool get busy => _busy;
  String? get lastPrompt => _lastPrompt;

  void setLastPrompt(String p) {
    _lastPrompt = p;
    notifyListeners();
  }

  // ----- Image picking -----

  Future<Uint8List?> pickSourceImage({
    required bool forAnalysis,
    bool fromCamera = false,
  }) async {
    final XFile? file = await _picker.pickImage(
      source: fromCamera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: AppConstants.maxPickDimension.toDouble(),
      imageQuality: AppConstants.pickQuality,
    );
    if (file == null) return null;
    final Uint8List bytes = await file.readAsBytes();
    if (bytes.lengthInBytes > AppConstants.maxImageBytes) {
      throw const AppException(AppErrorType.imageTooLarge);
    }
    final String mime = file.mimeType ?? _mimeFromName(file.name);
    if (forAnalysis) {
      _analysisBytes = bytes;
      _analysisMime = mime;
      _analysisText = null;
      _analysis = null;
    } else {
      _sourceBytes = bytes;
      _sourceMime = mime;
      _editedImageUrl = null;
      _edited = null;
    }
    notifyListeners();
    return bytes;
  }

  void clearEditSource() {
    _sourceBytes = null;
    _editedImageUrl = null;
    _edited = null;
    notifyListeners();
  }

  void clearAnalysisSource() {
    _analysisBytes = null;
    _analysisText = null;
    _analysis = null;
    notifyListeners();
  }

  // ----- Image generation -----

  Future<void> generateImage({
    required String prompt,
    String? style,
    required String aspectRatio,
    required String language,
  }) async {
    final String trimmed = prompt.trim();
    if (trimmed.isEmpty) return;
    _busy = true;
    _generatedImageUrl = null;
    _generated = null;
    _lastPrompt = trimmed;
    notifyListeners();
    try {
      final Map<String, dynamic> res = await AiService.generateImage(
        prompt: trimmed,
        style: style,
        aspectRatio: aspectRatio,
        language: language,
      );
      _generatedImageUrl = res['image_url']?.toString();
      _generated = res['generation'] is Map<String, dynamic>
          ? Generation.fromMap(res['generation'] as Map<String, dynamic>)
          : null;
    } catch (_) {
      _generatedImageUrl = null;
      rethrow;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  // ----- Image editing -----

  Future<void> applyEdit({
    required String instruction,
    String? style,
    required String language,
  }) async {
    final Uint8List? bytes = _sourceBytes;
    if (bytes == null || instruction.trim().isEmpty) return;
    _busy = true;
    _editedImageUrl = null;
    _edited = null;
    notifyListeners();
    try {
      final Map<String, dynamic> res = await AiService.editImage(
        imageBase64: base64Encode(bytes),
        imageMime: _sourceMime,
        instruction: instruction.trim(),
        style: style,
        language: language,
      );
      _editedImageUrl = res['image_url']?.toString();
      _edited = res['generation'] is Map<String, dynamic>
          ? Generation.fromMap(res['generation'] as Map<String, dynamic>)
          : null;
    } catch (_) {
      _editedImageUrl = null;
      rethrow;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  // ----- Analysis -----

  Future<void> analyze({
    String? question,
    required String language,
  }) async {
    final Uint8List? bytes = _analysisBytes;
    if (bytes == null) return;
    _busy = true;
    _analysisText = null;
    _analysis = null;
    notifyListeners();
    try {
      final Map<String, dynamic> res = await AiService.analyzeImage(
        imageBase64: base64Encode(bytes),
        imageMime: _analysisMime,
        question: question?.trim().isEmpty == true ? null : question?.trim(),
        language: language,
      );
      _analysisText = (res['analysis'] ?? '').toString();
      _analysis = res['generation'] is Map<String, dynamic>
          ? Generation.fromMap(res['generation'] as Map<String, dynamic>)
          : null;
    } catch (_) {
      _analysisText = null;
      rethrow;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  // ----- Prompt generation -----

  Future<void> generatePrompts({
    required String idea,
    required String platform,
    String? style,
    required String language,
  }) async {
    if (idea.trim().isEmpty) return;
    _busy = true;
    _prompts = <String>[];
    notifyListeners();
    try {
      final Map<String, dynamic> res = await AiService.generatePrompts(
        idea: idea.trim(),
        platform: platform,
        style: style,
        language: language,
      );
      final dynamic raw = res['prompts'];
      if (raw is List) {
        _prompts = raw.map((e) => e.toString()).toList();
      } else if ((res['text'] ?? '').toString().isNotEmpty) {
        _prompts = (res['text'] as String)
            .split(RegExp(r'\n\s*\n|---'))
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList();
      }
    } catch (_) {
      _prompts = <String>[];
      rethrow;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  String _mimeFromName(String name) {
    final String ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      default:
        return 'image/jpeg';
    }
  }

  void resetAll() {
    _generatedImageUrl = null;
    _generated = null;
    _sourceBytes = null;
    _editedImageUrl = null;
    _edited = null;
    _analysisBytes = null;
    _analysisText = null;
    _analysis = null;
    _prompts = <String>[];
    _busy = false;
    notifyListeners();
  }
}
