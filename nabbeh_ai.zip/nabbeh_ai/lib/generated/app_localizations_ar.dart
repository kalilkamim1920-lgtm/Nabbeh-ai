import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class SAr extends S {
  SAr([String locale = 'ar']) : super(locale);

  @override
  String get appName => 'NABBEH AI';

  @override
  String get ok => 'حسنًا';

  @override
  String get cancel => 'إلغاء';

  @override
  String get save => 'حفظ';

  @override
  String get delete => 'حذف';

  @override
  String get share => 'مشاركة';

  @override
  String get copy => 'نسخ';

  @override
  String get done => 'تم';

  @override
  String get retry => 'إعادة المحاولة';

  @override
  String get close => 'إغلاق';

  @override
  String get loading => 'جارٍ التحميل…';

  @override
  String get errorGeneric => 'حدث خطأ ما. حاول مرة أخرى.';

  @override
  String get success => 'تم بنجاح';

  @override
  String get seeAll => 'عرض الكل';

  @override
  String get copiedToClipboard => 'تم النسخ إلى الحافظة';

  @override
  String get comingSoon => 'قريبًا';

  @override
  String get loginRequired => 'تسجيل الدخول مطلوب';

  @override
  String get signInToContinue => 'يرجى تسجيل الدخول للمتابعة';

  @override
  String get tabHome => 'الرئيسية';

  @override
  String get tabChat => 'المحادثة';

  @override
  String get tabCreate => 'الإبداع';

  @override
  String get tabHistory => 'السجل';

  @override
  String get tabProfile => 'حسابي';

  @override
  String get homeWelcome => 'أهلًا بعودتك';

  @override
  String get homeTagline => 'ماذا تريد أن تنشئ اليوم؟';

  @override
  String creditsLabel(int count) {
    return '$count كريدت';
  }

  @override
  String get upgradeBannerTitle => 'افتح NABBEH PRO';

  @override
  String get upgradeBannerSubtitle => 'رسائل أكثر، صور بجودة HD، بدون إعلانات';

  @override
  String get upgradeNow => 'اشترك الآن';

  @override
  String get featureChatTitle => 'محادثة الذكاء الاصطناعي';

  @override
  String get featureChatSubtitle => 'محادثات ذكية بالعربية والإنجليزية';

  @override
  String get featureImageTitle => 'إنشاء صورة';

  @override
  String get featureImageSubtitle => 'حوّل كلماتك إلى أعمال مذهلة';

  @override
  String get featureEditTitle => 'تعديل صورة';

  @override
  String get featureEditSubtitle => 'عدّل أي صورة بالذكاء الاصطناعي';

  @override
  String get featureAnalyzeTitle => 'تحليل صورة';

  @override
  String get featureAnalyzeSubtitle => 'ارفع صورة واسأل عنها';

  @override
  String get featurePromptTitle => 'إنشاء Prompt';

  @override
  String get featurePromptSubtitle => 'اكتب أوامر مثالية لأي نموذج ذكاء اصطناعي';

  @override
  String get recentCreations => 'أحدث إبداعاتك';

  @override
  String get noCreationsYet => 'ستظهر إبداعاتك هنا';

  @override
  String get loginTitle => 'أهلًا بك في NABBEH AI';

  @override
  String get loginSubtitle => 'سجّل الدخول لاستخدام كامل قوة الذكاء الاصطناعي';

  @override
  String get createAccountTitle => 'أنشئ حسابك';

  @override
  String get fullName => 'الاسم الكامل';

  @override
  String get fullNameHint => 'اسمك';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get emailHint => 'you@example.com';

  @override
  String get password => 'كلمة المرور';

  @override
  String get passwordHint => '6 أحرف على الأقل';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get signIn => 'تسجيل الدخول';

  @override
  String get signUp => 'إنشاء حساب';

  @override
  String get forgotPassword => 'نسيت كلمة المرور؟';

  @override
  String get resetPassword => 'استعادة كلمة المرور';

  @override
  String get resetPasswordSent => 'تم إرسال بريد استعادة كلمة المرور';

  @override
  String get resetPasswordBody => 'تحقق من بريدك الوارد للحصول على رابط الاستعادة.';

  @override
  String get continueAsGuest => 'المتابعة كضيف';

  @override
  String get guestNote => 'يمكنك إنشاء حساب لاحقًا للحفاظ على بياناتك.';

  @override
  String get authFailed => 'فشل تسجيل الدخول';

  @override
  String get errEmailInvalid => 'يرجى إدخال بريد إلكتروني صحيح';

  @override
  String get errPasswordShort => 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';

  @override
  String get errPasswordMismatch => 'كلمتا المرور غير متطابقتين';

  @override
  String get errNameRequired => 'يرجى إدخال اسمك';

  @override
  String get errWrongCredentials => 'البريد الإلكتروني أو كلمة المرور غير صحيحة';

  @override
  String get errEmailTaken => 'هذا البريد الإلكتروني مسجل مسبقًا';

  @override
  String get errTooManyRequests => 'محاولات كثيرة جدًا. انتظر قليلًا ثم أعد المحاولة.';

  @override
  String get errNetwork => 'خطأ في الشبكة. تحقق من اتصالك.';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get logoutConfirm => 'هل أنت متأكد من تسجيل الخروج؟';

  @override
  String get chatTitle => 'محادثة AI';

  @override
  String get newChat => 'محادثة جديدة';

  @override
  String get chatEmptyTitle => 'ابدأ محادثة';

  @override
  String get chatEmptySubtitle => 'اسأل عن أي شيء — أفكار، كتابة، برمجة، ترجمة…';

  @override
  String get typeMessage => 'اكتب رسالتك…';

  @override
  String get send => 'إرسال';

  @override
  String get attachImage => 'إرفاق صورة';

  @override
  String get aiThinking => 'نبّه يفكر…';

  @override
  String get conversationsEmpty => 'لا توجد محادثات بعد';

  @override
  String get deleteConversationTitle => 'حذف المحادثة؟';

  @override
  String get deleteConversationBody => 'سيتم حذف هذه المحادثة ورسائلها.';

  @override
  String get imageAttached => 'صورة مرفقة';

  @override
  String get createHubTitle => 'استوديو الذكاء الاصطناعي';

  @override
  String get createHubSubtitle => 'كل ما تحتاجه للإبداع بالذكاء الاصطناعي';

  @override
  String get promptLabel => 'الوصف (Prompt)';

  @override
  String get promptHint => 'صف ما تريد إنشاءه…';

  @override
  String get styleLabel => 'الأسلوب';

  @override
  String get ratioLabel => 'أبعاد الصورة';

  @override
  String get generate => 'توليد';

  @override
  String get generatingImage => 'جارٍ توليد صورتك…';

  @override
  String get generationFailed => 'فشل توليد الصورة';

  @override
  String get savedToGallery => 'تم الحفظ في معرضك';

  @override
  String get styleRealistic => 'واقعي';

  @override
  String get styleAnime => 'أنمي';

  @override
  String get styleDigitalArt => 'فن رقمي';

  @override
  String get style3D => 'ثلاثي الأبعاد';

  @override
  String get styleWatercolor => 'ألوان مائية';

  @override
  String get styleCyberpunk => 'سايبربانك';

  @override
  String get styleMinimal => 'بسيط';

  @override
  String get styleLogo => 'شعار';

  @override
  String get styleNone => 'بدون';

  @override
  String get ratioSquare => 'مربع';

  @override
  String get ratioLandscape => 'أفقي';

  @override
  String get ratioPortrait => 'عمودي';

  @override
  String get editInstructionLabel => 'ما التغيير المطلوب؟';

  @override
  String get editInstructionHint => 'مثال: غيّر الخلفية إلى شاطئ عند الغروب';

  @override
  String get chooseImage => 'اختر صورة';

  @override
  String get changeImage => 'تغيير الصورة';

  @override
  String get applyEdit => 'تطبيق التعديل بالذكاء الاصطناعي';

  @override
  String get applyingEdit => 'جارٍ تطبيق التعديل…';

  @override
  String get analyzeQuestionLabel => 'سؤالك (اختياري)';

  @override
  String get analyzeQuestionHint => 'مثال: ما الموجود في هذه الصورة؟';

  @override
  String get analyzeImage => 'تحليل الصورة';

  @override
  String get analyzing => 'جارٍ تحليل صورتك…';

  @override
  String get analysisResult => 'نتيجة التحليل';

  @override
  String get promptIdeaLabel => 'فكرتك';

  @override
  String get promptIdeaHint => 'اشرح فكرتك بكلمات بسيطة…';

  @override
  String get platformLabel => 'المنصة المستهدفة';

  @override
  String get platformMidjourney => 'Midjourney';

  @override
  String get platformStableDiffusion => 'Stable Diffusion';

  @override
  String get platformDalle => 'DALL·E';

  @override
  String get platformGeneric => 'عام';

  @override
  String get generatePrompts => 'توليد أوامر';

  @override
  String get promptsResult => 'الأوامر المقترحة';

  @override
  String get savePrompt => 'حفظ الأمر';

  @override
  String get promptSaved => 'تم حفظ الأمر في المفضلة';

  @override
  String get historyConversationsTab => 'المحادثات';

  @override
  String get historyImagesTab => 'الصور';

  @override
  String get historyEmptyImages => 'لا توجد صور مولدة بعد';

  @override
  String get historyEmptyConversations => 'لا توجد محادثات بعد';

  @override
  String get galleryTitle => 'معرضي';

  @override
  String get favoritesTitle => 'المفضلة';

  @override
  String get favTabImages => 'الصور';

  @override
  String get favTabPrompts => 'الأوامر';

  @override
  String get noFavoritesYet => 'لا شيء هنا بعد. اضغط على النجمة لحفظ أي عنصر.';

  @override
  String get copyPrompt => 'نسخ الأمر';

  @override
  String get deleteImageTitle => 'حذف هذه الصورة؟';

  @override
  String get deleteImageBody => 'سيتم حذفها من معرضك نهائيًا.';

  @override
  String get imageDetails => 'تفاصيل الصورة';

  @override
  String get favoriteAdded => 'أُضيفت إلى المفضلة';

  @override
  String get favoriteRemoved => 'أُزيلت من المفضلة';

  @override
  String get profileTitle => 'حسابي';

  @override
  String get planFree => 'مجاني';

  @override
  String get planPro => 'PRO';

  @override
  String get creditsBalance => 'رصيد الكريدت';

  @override
  String get manageSubscription => 'إدارة الاشتراك';

  @override
  String get myFavorites => 'مفضلتي';

  @override
  String get myGallery => 'معرضي';

  @override
  String get settingsTitle => 'الإعدادات';

  @override
  String get aboutTitle => 'حول التطبيق';

  @override
  String get signOut => 'تسجيل الخروج';

  @override
  String memberSince(String date) {
    return 'عضو منذ $date';
  }

  @override
  String get guestAccount => 'حساب ضيف';

  @override
  String get editProfile => 'تعديل الملف الشخصي';

  @override
  String get editNameTitle => 'تعديل الاسم';

  @override
  String get appearance => 'المظهر';

  @override
  String get themeSystem => 'حسب النظام';

  @override
  String get themeLight => 'فاتح';

  @override
  String get themeDark => 'داكن';

  @override
  String get language => 'اللغة';

  @override
  String get arabic => 'العربية';

  @override
  String get english => 'English';

  @override
  String get notifications => 'التنبيهات';

  @override
  String get notificationsSubtitle => 'تنبيهات وتحديثات داخل التطبيق';

  @override
  String get clearCache => 'مسح ذاكرة الصور المؤقتة';

  @override
  String get cacheCleared => 'تم مسح الذاكرة المؤقتة';

  @override
  String get aboutApp => 'حول NABBEH AI';

  @override
  String get version => 'الإصدار';

  @override
  String get paywallTitle => 'NABBEH PRO';

  @override
  String get paywallSubtitle => 'أنشئ أكثر، وأنشئ أفضل';

  @override
  String get freeLabel => 'مجاني';

  @override
  String get proLabel => 'Pro';

  @override
  String get featureMessagesFree => '20 رسالة ذكاء اصطناعي يوميًا';

  @override
  String get featureMessagesPro => '500 رسالة يوميًا';

  @override
  String get featureImagesFree => '5 صور يوميًا';

  @override
  String get featureImagesPro => '100 صورة يوميًا';

  @override
  String get featureQualityStandard => 'جودة صور عادية';

  @override
  String get featureQualityHd => 'جودة صور HD';

  @override
  String get featureAdsFree => 'إعلانات ترويجية أحيانًا';

  @override
  String get featureAdsPro => 'بدون أي إعلانات';

  @override
  String get featurePriorityFree => 'طابور توليد عادي';

  @override
  String get featurePriorityPro => 'أولوية في التوليد';

  @override
  String get featureEditFree => 'أدوات أساسية';

  @override
  String get featureEditPro => 'استوديو كامل + تعديل الصور';

  @override
  String get monthlyPlan => 'شهري';

  @override
  String get yearlyPlan => 'سنوي';

  @override
  String get perMonth => '/شهريًا';

  @override
  String get perYear => '/سنويًا';

  @override
  String saveBadge(int percent) {
    return 'وفّر $percent%';
  }

  @override
  String get mostPopular => 'الأكثر اختيارًا';

  @override
  String get creditPacksTitle => 'حزم الكريدت';

  @override
  String get creditPacksSubtitle => 'شراء لمرة واحدة، لا تنتهي أبدًا';

  @override
  String get creditsSmall => '100 كريدت';

  @override
  String get creditsMedium => '500 كريدت';

  @override
  String get creditsLarge => '1500 كريدت';

  @override
  String get purchaseNow => 'اشترك الآن';

  @override
  String get restorePurchases => 'استعادة المشتريات';

  @override
  String get purchasing => 'جارٍ إتمام الشراء…';

  @override
  String get restored => 'تمت استعادة المشتريات';

  @override
  String get purchaseSuccess => 'تم الشراء بنجاح! أهلًا بك في PRO 🎉';

  @override
  String get purchaseFailed => 'فشل الشراء. حاول مرة أخرى.';

  @override
  String get demoModeTitle => 'وضع تجريبي';

  @override
  String get demoModeBody => 'لم يتم ضبط RevenueCat بعد. أضف مفاتيح SDK العامة في ملف .env لتفعيل الشراء الحقيقي. يمكنك حاليًا تجربة مزايا PRO في وضع تجريبي.';

  @override
  String get subscriptionNote => 'يتجدد الاشتراك تلقائيًا حتى يتم إلغاؤه. حزم الكريدت شراء لمرة واحدة ولا تنتهي.';

  @override
  String get limitReachedTitle => 'وصلت إلى الحد';

  @override
  String get limitDailyChat => 'استهلكت كل رسائل اليوم. اشترك في PRO للحصول على 500 رسالة يوميًا أو اشترِ كريدت.';

  @override
  String get limitDailyImages => 'استهلكت صور اليوم. اشترك في PRO للحصول على 100 صورة يوميًا أو اشترِ كريدت.';

  @override
  String get limitCredits => 'لا يوجد رصيد كريدت كافٍ. اشترِ حزمة كريدت أو اشترك في PRO.';

  @override
  String get goPro => 'اشترك في PRO';

  @override
  String get getCredits => 'شراء كريدت';

  @override
  String get setupTitle => 'الإعداد مطلوب';

  @override
  String get setupBody => 'لم يتم ربط NABBEH AI بأي باك-إند بعد.\n\n1. انسخ .env.example إلى .env\n2. أضف رابط Supabase ومفتاح anon\n3. أعد تشغيل التطبيق\n\nكل مفاتيح AI تبقى على السيرفر — راجع README.md.';

  @override
  String get setupHint => 'تظهر هذه الشاشة لأن قيم .env فارغة.';

  @override
  String get networkError => 'مشكلة في الاتصال. حاول مرة أخرى.';

  @override
  String get serverError => 'خطأ في السيرفر. حاول لاحقًا.';

  @override
  String get imageTooLarge => 'الصورة كبيرة جدًا. اختر صورة أصغر.';

  @override
  String get uploadFailed => 'تعذر قراءة الصورة. جرّب صورة أخرى.';
}
