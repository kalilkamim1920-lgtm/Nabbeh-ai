import 'package:flutter/material.dart';

/// NABBEH AI brand palette.
class AppColors {
  AppColors._();

  // Brand
  static const Color primary = Color(0xFF6C5CE7);
  static const Color primaryDark = Color(0xFF5A4BD1);
  static const Color secondary = Color(0xFF00C2A8);

  // Gradients
  static const LinearGradient brandGradient = LinearGradient(
    colors: [Color(0xFF7C4DFF), Color(0xFF6C5CE7), Color(0xFF4FACFE)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient proGradient = LinearGradient(
    colors: [Color(0xFFF7971E), Color(0xFFFFD200)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient successGradient = LinearGradient(
    colors: [Color(0xFF11998E), Color(0xFF38EF7D)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Dark theme surfaces
  static const Color darkBg = Color(0xFF0B0B14);
  static const Color darkSurface = Color(0xFF151522);
  static const Color darkCard = Color(0xFF1D1D2E);
  static const Color darkBorder = Color(0xFF2A2A3E);

  // Light theme surfaces
  static const Color lightBg = Color(0xFFF6F6FB);
  static const Color lightCard = Colors.white;
  static const Color lightBorder = Color(0xFFE4E4EF);

  // Semantic
  static const Color success = Color(0xFF27AE60);
  static const Color warning = Color(0xFFF2994A);
  static const Color error = Color(0xFFEB5757);
  static const Color star = Color(0xFFF2C94C);

  // Feature card icon gradients
  static const LinearGradient chatGradient = LinearGradient(
    colors: [Color(0xFF6C5CE7), Color(0xFFa29bfe)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient imageGradient = LinearGradient(
    colors: [Color(0xFF00C2A8), Color(0xFF4FACFE)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient editGradient = LinearGradient(
    colors: [Color(0xFFEB5757), Color(0xFFF2994A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient analyzeGradient = LinearGradient(
    colors: [Color(0xFF11998E), Color(0xFF38EF7D)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient promptGradient = LinearGradient(
    colors: [Color(0xFFF7971E), Color(0xFFEC6F66)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
