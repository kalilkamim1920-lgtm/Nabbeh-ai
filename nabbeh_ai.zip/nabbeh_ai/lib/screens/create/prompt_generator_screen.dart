import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/errors/app_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/creation_provider.dart';
import '../../providers/gallery_provider.dart';
import '../../providers/settings_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/section_header.dart';
import '../../widgets/limit_sheet.dart';

/// Idea -> three polished prompts for the chosen AI platform.
class PromptGeneratorScreen extends StatefulWidget {
  const PromptGeneratorScreen({super.key});

  @override
  State<PromptGeneratorScreen> createState() => _PromptGeneratorScreenState();
}

class _PromptGeneratorScreenState extends State<PromptGeneratorScreen> {
  final TextEditingController _idea = TextEditingController();
  String _platform = 'generic';
  bool _savedAll = false;

  String _platformLabel(S s, String id) {
    switch (id) {
      case 'midjourney':
        return s.platformMidjourney;
      case 'stable_diffusion':
        return s.platformStableDiffusion;
      case 'dalle':
        return s.platformDalle;
      default:
        return s.platformGeneric;
    }
  }

  Future<void> _generate() async {
    final CreationProvider creation = context.read<CreationProvider>();
    final SettingsProvider settings = context.read<SettingsProvider>();
    final S s = S.of(context);
    setState(() => _savedAll = false);
    try {
      await creation.generatePrompts(
        idea: _idea.text,
        platform: _platform,
        language: settings.locale.languageCode,
      );
    } on AppException catch (e) {
      if (!mounted) return;
      if (e.isLimitReached) {
        await showLimitReachedSheet(context, e.type);
      } else {
        Helpers.showSnack(context, s.serverError, error: true);
      }
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.networkError, error: true);
    }
  }

  Future<void> _savePrompt(String prompt) async {
    final GalleryProvider gallery = context.read<GalleryProvider>();
    final S s = S.of(context);
    try {
      await gallery.savePrompt(
        Helpers.clamp(prompt, 48),
        prompt,
      );
      if (!mounted) return;
      Helpers.showSnack(context, s.promptSaved);
    } catch (_) {
      if (!mounted) return;
      Helpers.showSnack(context, s.serverError, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final CreationProvider creation = context.watch<CreationProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(s.featurePromptTitle)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            SectionHeader(title: s.promptIdeaLabel),
            TextField(
              controller: _idea,
              minLines: 2,
              maxLines: 4,
              decoration: InputDecoration(hintText: s.promptIdeaHint),
            ),
            const SizedBox(height: 18),
            SectionHeader(title: s.platformLabel),
            SizedBox(
              height: 42,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: AppConstants.promptPlatforms.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (BuildContext context, int index) {
                  final String id = AppConstants.promptPlatforms[index];
                  final bool selected = _platform == id;
                  return ChoiceChip(
                    label: Text(_platformLabel(s, id)),
                    selected: selected,
                    onSelected: (_) => setState(() => _platform = id),
                    showCheckmark: false,
                    labelStyle: TextStyle(
                      color: selected ? Colors.white : null,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.w500,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 22),
            PrimaryButton(
              label: s.generatePrompts,
              icon: Icons.tips_and_updates_rounded,
              onPressed: _idea.text.trim().isEmpty ? null : _generate,
              busy: creation.busy,
              gradient: AppColors.promptGradient,
            ),
            const SizedBox(height: 24),
            if (creation.busy)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 14),
                    Text(s.generatingImage,
                        style: TextStyle(color: Colors.grey.shade500)),
                  ],
                ),
              )
            else if (creation.prompts.isNotEmpty) ...[
              Row(
                children: [
                  Expanded(child: SectionHeader(title: s.promptsResult)),
                  TextButton.icon(
                    onPressed: _savedAll
                        ? null
                        : () async {
                            for (final String p in creation.prompts) {
                              await _savePrompt(p);
                            }
                            if (!mounted) return;
                            setState(() => _savedAll = true);
                          },
                    icon: const Icon(Icons.star_border_rounded, size: 18),
                    label: Text(s.savePrompt),
                  ),
                ],
              ),
              ...creation.prompts.map(
                (String prompt) => Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? AppColors.darkCard
                        : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border:
                        Border.all(color: Theme.of(context).dividerColor),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SelectableText(
                        prompt,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: () async {
                              await Clipboard.setData(
                                  ClipboardData(text: prompt));
                              if (!context.mounted) return;
                              Helpers.showSnack(context,
                                  S.of(context).copiedToClipboard);
                            },
                            icon: const Icon(Icons.copy_rounded, size: 16),
                            label: Text(s.copy,
                                style: const TextStyle(fontSize: 13)),
                          ),
                          const SizedBox(width: 6),
                          TextButton.icon(
                            onPressed: () => _savePrompt(prompt),
                            icon: const Icon(Icons.star_border_rounded,
                                size: 16),
                            label: Text(s.save,
                                style: const TextStyle(fontSize: 13)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ] else
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 30),
                child: EmptyState(
                  icon: Icons.tips_and_updates_outlined,
                  title: s.promptIdeaHint,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
