import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../l10n_helper.dart';
import '../../providers/auth_provider.dart';
import '../../providers/gallery_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/generation_grid.dart';
import '../../models/generation.dart';
import '../chat/chat_list_screen.dart';
import '../gallery/image_detail_screen.dart';

/// History tab: conversations + generated images.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final AuthProvider auth = context.watch<AuthProvider>();

    if (!auth.isSignedIn) {
      return Scaffold(
        appBar: AppBar(title: Text(s.tabHistory)),
        body: EmptyState(
          icon: Icons.lock_outline_rounded,
          title: s.loginRequired,
          subtitle: s.signInToContinue,
        ),
      );
    }

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.tabHistory),
          bottom: TabBar(
            tabs: <Widget>[
              Tab(text: s.historyConversationsTab),
              Tab(text: s.historyImagesTab),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            const ChatListScreen(),
            const _ImagesHistoryTab(),
          ],
        ),
      ),
    );
  }
}

class _ImagesHistoryTab extends StatefulWidget {
  const _ImagesHistoryTab();

  @override
  State<_ImagesHistoryTab> createState() => _ImagesHistoryTabState();
}

class _ImagesHistoryTabState extends State<_ImagesHistoryTab> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<GalleryProvider>().loadImages();
    });
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final GalleryProvider gallery = context.watch<GalleryProvider>();

    if (gallery.loadingImages && gallery.images.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (gallery.images.isEmpty) {
      return EmptyState(
        icon: Icons.image_not_supported_outlined,
        title: s.historyEmptyImages,
      );
    }
    return NotificationListener<ScrollNotification>(
      onNotification: (ScrollNotification n) {
        if (n.metrics.pixels >= n.metrics.maxScrollExtent - 240) {
          context.read<GalleryProvider>().loadMoreImages();
        }
        return false;
      },
      child: GenerationGrid(
        generations: gallery.images,
        onTap: (Generation g) => _open(context, g),
      ),
    );
  }

  Future<void> _open(BuildContext context, Generation g) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ImageDetailScreen(generation: g),
      ),
    );
    if (!context.mounted) return;
    context.read<GalleryProvider>().loadImages();
  }
}
