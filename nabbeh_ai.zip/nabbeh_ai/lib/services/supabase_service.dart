import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/config/env_config.dart';

/// Central access point to Supabase (auth, database, storage, functions).
class SupabaseService {
  SupabaseService._();

  static Future<void> init() async {
    await Supabase.initialize(
      url: EnvConfig.supabaseUrl,
      publishableKey: EnvConfig.supabaseAnonKey,
    );
  }

  static SupabaseClient get client => Supabase.instance.client;

  static User? get currentUser => client.auth.currentUser;

  // ----- Auth -----

  static Future<void> signIn(String email, String password) =>
      client.auth.signInWithPassword(email: email, password: password);

  static Future<void> signUp(String email, String password, String name) =>
      client.auth.signUp(email: email, password: password, data: {
        'display_name': name,
      });

  static Future<void> signInAsGuest() => client.auth.signInAnonymously();

  static Future<void> resetPassword(String email) =>
      client.auth.resetPasswordForEmail(email);

  static Future<void> signOut() => client.auth.signOut();
}
