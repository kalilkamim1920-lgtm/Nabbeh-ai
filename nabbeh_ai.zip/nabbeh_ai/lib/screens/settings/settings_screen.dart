import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../providers/settings_provider.dart';
import '../../services/settings_storage.dart';
import '../../widgets/section_header.dart';

/// Appearance, language, notifications, cache.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final SettingsProvider settings = context.watch<SettingsProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(s.settingsTitle)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          SectionHeader(title: s.appearance),
          SegmentedButton<ThemeMode>(
            segments: <ButtonSegment<ThemeMode>>[
              ButtonSegment<ThemeMode>(
                value: ThemeMode.system,
                icon: const Icon(Icons.brightness_auto_rounded, size: 18),
                label: Text(s.themeSystem),
              ),
              ButtonSegment<ThemeMode>(
                value: ThemeMode.light,
                icon: const Icon(Icons.light_mode_rounded, size: 18),
                label: Text(s.themeLight),
              ),
              ButtonSegment<ThemeMode>(
                value: ThemeMode.dark,
                icon: const Icon(Icons.dark_mode_rounded, size: 18),
                label: Text(s.themeDark),
              ),
            ],
            selected: <ThemeMode>{settings.themeMode},
            onSelectionChanged: (Set<ThemeMode> selection) {
              context
                  .read<SettingsProvider>()
                  .setThemeMode(selection.first);
            },
          ),
          const SizedBox(height: 24),
          SectionHeader(title: s.language),
          SegmentedButton<String>(
            segments: <ButtonSegment<String>>[
              ButtonSegment<String>(
                value: 'ar',
                label: Text(s.arabic),
              ),
              ButtonSegment<String>(
                value: 'en',
                label: Text(s.english),
              ),
            ],
            selected: <String>{settings.locale.languageCode},
            onSelectionChanged: (Set<String> selection) {
              context
                  .read<SettingsProvider>()
                  .setLocale(Locale(selection.first));
            },
          ),
          const SizedBox(height: 24),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.notifications,
                style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(s.notificationsSubtitle,
                style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
            value: SettingsStorage.notificationsEnabled,
            activeColor: Theme.of(context).colorScheme.primary,
            onChanged: (bool v) {
              SettingsStorage.setNotificationsEnabled(v);
              (context as Element).markNeedsBuild();
            },
          ),
          const SizedBox(height: 16),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.cleaning_services_rounded),
            title: Text(s.clearCache,
                style: const TextStyle(fontWeight: FontWeight.w600)),
            onTap: () {
              imageCache.clear();
              imageCache.clearLiveImages();
              Helpers.showSnack(context, s.cacheCleared);
            },
          ),
          const Divider(height: 32),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.info_outline_rounded),
            title: Text(s.aboutApp,
                style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(
              '${s.version} ${AppConstants.appVersion}',
              style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
