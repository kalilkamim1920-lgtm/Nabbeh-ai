import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../models/conversation.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../widgets/empty_state.dart';
import 'chat_screen.dart';

/// Conversations list (the "Chat" tab).
class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ChatProvider>().loadConversations();
    });
  }

  Future<void> _newChat() async {
    final ChatProvider chat = context.read<ChatProvider>();
    chat.startNewChat();
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const ChatScreen()),
    );
    if (!mounted) return;
    context.read<ChatProvider>().loadConversations();
  }

  Future<void> _open(Conversation conversation) async {
    final ChatProvider chat = context.read<ChatProvider>();
    await chat.openConversation(conversation.id);
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const ChatScreen()),
    );
    if (!mounted) return;
    context.read<ChatProvider>().loadConversations();
  }

  Future<void> _delete(Conversation conversation) async {
    final S s = S.of(context);
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text(s.deleteConversationTitle),
        content: Text(s.deleteConversationBody),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(s.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(
              s.delete,
              style: const TextStyle(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await context.read<ChatProvider>().deleteConversation(conversation.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final ChatProvider chat = context.watch<ChatProvider>();
    final AuthProvider auth = context.watch<AuthProvider>();

    if (!auth.isSignedIn) {
      return Center(child: EmptyState(
        icon: Icons.lock_outline_rounded,
        title: s.loginRequired,
        subtitle: s.signInToContinue,
      ));
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(title: Text(s.tabChat)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _newChat,
        icon: const Icon(Icons.add_comment_rounded),
        label: Text(s.newChat),
      ),
      body: RefreshIndicator(
        onRefresh: () => context.read<ChatProvider>().loadConversations(),
        child: chat.loadingConversations && chat.conversations.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : chat.conversations.isEmpty
                ? EmptyState(
                    icon: Icons.forum_outlined,
                    title: s.conversationsEmpty,
                    actionLabel: s.newChat,
                    onAction: _newChat,
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: chat.conversations.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 4),
                    itemBuilder: (BuildContext context, int index) {
                      final Conversation c = chat.conversations[index];
                      return Dismissible(
                        key: ValueKey<String>(c.id),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: AlignmentDirectional.centerEnd,
                          padding: const EdgeInsetsDirectional.only(end: 24),
                          decoration: BoxDecoration(
                            color: AppColors.error.withAlpha(30),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(Icons.delete_outline,
                              color: AppColors.error),
                        ),
                        confirmDismiss: (_) async {
                          await _delete(c);
                          return false;
                        },
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor:
                                AppColors.primary.withAlpha(40),
                            child: const Text(
                              '🤖',
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                          title: Text(
                            Helpers.clamp(c.title, 42),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            Helpers.formatDay(c.updatedAt,
                                Localizations.localeOf(context)
                                    .languageCode),
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade500),
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline,
                                size: 20),
                            onPressed: () => _delete(c),
                          ),
                          onTap: () => _open(c),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
