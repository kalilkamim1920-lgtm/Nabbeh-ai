import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/helpers.dart';
import '../../l10n_helper.dart';
import '../../models/favorite_item.dart';
import '../../models/generation.dart';
import '../../providers/auth_provider.dart';
import '../../providers/gallery_provider.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/generation_grid.dart';
import '../gallery/image_detail_screen.dart';

/// Favorites: favorite images + saved prompts.
class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<GalleryProvider>().loadFavorites();
    });
  }

  @override
  Widget build(BuildContext context) {
    final S s = S.of(context);
    final AuthProvider auth = context.watch<AuthProvider>();
    final GalleryProvider gallery = context.watch<GalleryProvider>();

    if (!auth.isSignedIn) {
      return Scaffold(
        appBar: AppBar(title: Text(s.favoritesTitle)),
        body: EmptyState(
          icon: Icons.lock_outline_rounded,
          title: s.loginRequired,
          subtitle: s.signInToContinue,
        ),
      );
    }

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.favoritesTitle),
          bottom: TabBar(
            tabs: <Widget>[
              Tab(text: s.favTabImages),
              Tab(text: s.favTabPrompts),
            ],
          ),
        ),
        body: gallery.loadingFavorites
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: <Widget>[
                  gallery.favoriteImages.isEmpty
                      ? EmptyState(
                          icon: Icons.star_border_rounded,
                          title: s.noFavoritesYet,
                        )
                      : GenerationGrid(
                          generations: gallery.favoriteImages,
                          onTap: (Generation g) async {
                            await Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) =>
                                    ImageDetailScreen(generation: g),
                              ),
                            );
                            if (!context.mounted) return;
                            context
                                .read<GalleryProvider>()
                                .loadFavorites();
                          },
                        ),
                  gallery.favoritePrompts.isEmpty
                      ? EmptyState(
                          icon: Icons.tips_and_updates_outlined,
                          title: s.noFavoritesYet,
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: gallery.favoritePrompts.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 10),
                          itemBuilder: (BuildContext context, int index) {
                            final FavoriteItem item =
                                gallery.favoritePrompts[index];
                            return Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? AppColors.darkCard
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                    color:
                                        Theme.of(context).dividerColor),
                              ),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  if (item.title != null)
                                    Text(
                                      item.title!,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleMedium
                                          ?.copyWith(fontSize: 14),
                                    ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item.content ?? '',
                                    maxLines: 4,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyMedium,
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      TextButton.icon(
                                        onPressed: () async {
                                          await Clipboard.setData(
                                            ClipboardData(
                                                text:
                                                    item.content ?? ''),
                                          );
                                          if (!context.mounted) return;
                                          Helpers.showSnack(context,
                                              S.of(context).copiedToClipboard);
                                        },
                                        icon: const Icon(
                                            Icons.copy_rounded,
                                            size: 16),
                                        label: Text(s.copy,
                                            style: const TextStyle(
                                                fontSize: 13)),
                                      ),
                                      const SizedBox(width: 6),
                                      TextButton.icon(
                                        onPressed: () => context
                                            .read<GalleryProvider>()
                                            .removePromptFavorite(
                                                item.id),
                                        icon: const Icon(
                                            Icons.delete_outline,
                                            size: 16,
                                            color: AppColors.error),
                                        label: Text(s.delete,
                                            style: const TextStyle(
                                                fontSize: 13,
                                                color: AppColors.error)),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ],
              ),
      ),
    );
  }
}
