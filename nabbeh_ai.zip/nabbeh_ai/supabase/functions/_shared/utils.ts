// Shared helpers for all NABBEH AI Edge Functions.
// Provider switching, credits, usage limits, storage upload.

import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

// ---------- CORS ----------
export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function fail(error: string, type: string, message: string, status = 400): Response {
  return json({ error, type, message }, status);
}

// ---------- Clients ----------

export function anonClient(): SupabaseClient {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
  );
}

export function adminClient(): SupabaseClient {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false } },
  );
}

export async function requireUser(req: Request): Promise<{ user: any; token: string } | Response> {
  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.replace("Bearer ", "").trim();
  if (!token) {
    return fail("unauthorized", "auth", "Missing bearer token", 401);
  }
  const { data, error } = await anonClient().auth.getUser(token);
  if (error || !data?.user) {
    return fail("unauthorized", "auth", "Invalid or expired token", 401);
  }
  return { user: data.user, token };
}

// ---------- Plans / limits / credits ----------

export const LIMITS: Record<string, { dailyChat: number; dailyImages: number; refill: number }> = {
  free: { dailyChat: 20, dailyImages: 5, refill: 25 },
  pro: { dailyChat: 500, dailyImages: 100, refill: 600 },
};

export const COSTS = {
  chat: 1,
  prompt: 1,
  analysis: 2,
  edit: 8,
  image: 10,
  image_hd: 15,
};

export interface Profile {
  id: string;
  email: string | null;
  display_name: string | null;
  plan: "free" | "pro";
  credits: number;
  last_refill_date: string;
  is_anonymous: boolean;
  [key: string]: unknown;
}

export async function getProfile(admin: SupabaseClient, userId: string): Promise<Profile | null> {
  const { data } = await admin
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .maybeSingle();
  return (data as Profile) ?? null;
}

/** Daily credit refill — adds the plan allowance once per UTC day. */
export async function refillIfNeeded(admin: SupabaseClient, profile: Profile): Promise<Profile> {
  const today = new Date().toISOString().slice(0, 10);
  if (profile.last_refill_date >= today) return profile;
  const allowance = LIMITS[profile.plan]?.refill ?? LIMITS.free.refill;
  const credits = Math.min(profile.credits + allowance, 9999);
  const { data } = await admin
    .from("profiles")
    .update({ credits, last_refill_date: today })
    .eq("id", profile.id)
    .select()
    .single();
  if (data) {
    await admin.from("credit_transactions").insert({
      user_id: profile.id,
      amount: allowance,
      reason: "daily_refill",
    });
    return data as Profile;
  }
  profile.credits = credits;
  profile.last_refill_date = today;
  return profile;
}

export type UsageKind = "chat" | "image";

/** Enforce daily plan limits + consume credits. Throws a Response on failure. */
export async function consume(
  admin: SupabaseClient,
  profile: Profile,
  kind: UsageKind,
  cost: number,
): Promise<Response | { ok: true; creditsLeft: number }> {
  const today = new Date().toISOString().slice(0, 10);
  const limits = LIMITS[profile.plan] ?? LIMITS.free;

  // 1) Daily plan limits
  const { data: usage } = await admin
    .from("usage_daily")
    .select("chat_count, image_count")
    .eq("user_id", profile.id)
    .eq("day", today)
    .maybeSingle();

  const chatCount = usage?.chat_count ?? 0;
  const imageCount = usage?.image_count ?? 0;

  if (kind === "chat" && chatCount >= limits.dailyChat) {
    return fail("limit_reached", "daily_chat", "Daily chat limit reached", 402);
  }
  if (kind === "image" && imageCount >= limits.dailyImages) {
    return fail("limit_reached", "daily_images", "Daily image limit reached", 402);
  }

  // 2) Credits
  if (profile.credits < cost) {
    return fail("limit_reached", "credits", "Not enough credits", 402);
  }

  // 3) Consume
  const credits = profile.credits - cost;
  await admin.from("profiles").update({ credits }).eq("id", profile.id);
  await admin.from("credit_transactions").insert({
    user_id: profile.id,
    amount: -cost,
    reason: kind,
  });

  const patch: Record<string, number> =
    kind === "chat" ? { chat_count: chatCount + 1 } : { image_count: imageCount + 1 };
  await admin
    .from("usage_daily")
    .upsert({ user_id: profile.id, day: today, ...patch });

  return { ok: true, creditsLeft: credits };
}

// ---------- AI provider switching (server-side only) ----------

export interface TextResult {
  text: string;
}

function textProviderConfig(): { provider: string; baseUrl: string; key: string; model: string } {
  const provider = (Deno.env.get("AI_TEXT_PROVIDER") ?? "openai").toLowerCase();

  if (provider === "gemini") {
    return {
      provider,
      baseUrl: "https://generativelanguage.googleapis.com/v1beta",
      key: Deno.env.get("GEMINI_API_KEY") ?? "",
      model: Deno.env.get("AI_CHAT_MODEL") ?? "gemini-1.5-flash",
    };
  }
  if (provider === "openrouter") {
    return {
      provider,
      baseUrl: "https://openrouter.ai/api/v1",
      key: Deno.env.get("OPENROUTER_API_KEY") ?? "",
      model: Deno.env.get("AI_CHAT_MODEL") ?? "openai/gpt-4o-mini",
    };
  }
  if (provider === "groq") {
    return {
      provider,
      baseUrl: "https://api.groq.com/openai/v1",
      key: Deno.env.get("GROQ_API_KEY") ?? "",
      model: Deno.env.get("AI_CHAT_MODEL") ?? "llama-3.3-70b-versatile",
    };
  }
  return {
    provider: "openai",
    baseUrl: "https://api.openai.com/v1",
    key: Deno.env.get("OPENAI_API_KEY") ?? "",
    model: Deno.env.get("AI_CHAT_MODEL") ?? "gpt-4o-mini",
  };
}

export interface ChatTurn {
  role: "system" | "user" | "assistant";
  content: string | Array<Record<string, unknown>>;
}

/** OpenAI-compatible chat completion (also used for vision via image data URI). */
export async function openAiCompatibleChat(
  baseUrl: string,
  key: string,
  model: string,
  messages: ChatTurn[],
): Promise<TextResult> {
  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, messages, max_tokens: 2000 }),
  });
  const bodyText = await res.text();
  if (!res.ok) {
    throw new Error(`chat provider ${res.status}: ${bodyText.slice(0, 400)}`);
  }
  const data = JSON.parse(bodyText);
  const text = data?.choices?.[0]?.message?.content;
  if (typeof text !== "string") throw new Error("empty chat response");
  return { text };
}

/** Google Gemini generateContent (text + optional inline image). */
export async function geminiChat(
  cfg: { baseUrl: string; key: string; model: string },
  systemPrompt: string,
  history: Array<{ role: "user" | "assistant"; content: string }>,
  userText: string,
  imageDataUri?: string,
): Promise<TextResult> {
  const parts: Array<Record<string, unknown>> = [];
  if (userText) parts.push({ text: userText });
  if (imageDataUri) {
    const match = /^data:([^;]+);base64,(.*)$/.exec(imageDataUri);
    if (match) {
      parts.push({ inline_data: { mime_type: match[1], data: match[2] } });
    }
  }
  const contents = [
    ...history.map((h) => ({
      role: h.role === "assistant" ? "model" : "user",
      parts: [{ text: h.content }],
    })),
    { role: "user", parts },
  ];
  const res = await fetch(`${cfg.baseUrl}/models/${cfg.model}:generateContent?key=${cfg.key}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents,
      system_instruction: { parts: [{ text: systemPrompt }] },
      generationConfig: { maxOutputTokens: 2048 },
    }),
  });
  const bodyText = await res.text();
  if (!res.ok) {
    throw new Error(`gemini ${res.status}: ${bodyText.slice(0, 400)}`);
  }
  const data = JSON.parse(bodyText);
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (typeof text !== "string") throw new Error("empty gemini response");
  return { text };
}

/** Unified text call: routes to the configured provider. */
export async function aiChat(
  systemPrompt: string,
  history: Array<{ role: "user" | "assistant"; content: string }>,
  userText: string,
  imageDataUri?: string,
): Promise<TextResult> {
  const cfg = textProviderConfig();
  if (!cfg.key) {
    throw new Error(`Missing API key for provider '${cfg.provider}'. Set it in Supabase secrets.`);
  }

  if (cfg.provider === "gemini") {
    return geminiChat(cfg, systemPrompt, history, userText, imageDataUri);
  }

  const messages: ChatTurn[] = [{ role: "system", content: systemPrompt }];
  for (const h of history) {
    messages.push({ role: h.role === "assistant" ? "assistant" : "user", content: h.content });
  }
  if (imageDataUri) {
    messages.push({
      role: "user",
      content: [
        { type: "text", text: userText || "Analyze this image." },
        { type: "image_url", image_url: { url: imageDataUri } },
      ],
    });
  } else {
    messages.push({ role: "user", content: userText });
  }
  return openAiCompatibleChat(cfg.baseUrl, cfg.key, cfg.model, messages);
}

// ---------- Image generation / editing ----------

export interface ImageOptions {
  prompt: string;
  aspectRatio: string; // '1:1' | '16:9' | '9:16'
  hd: boolean;
  sourceBase64?: string; // for edit
  sourceMime?: string;
}

function imageProvider(): { provider: string; key: string } {
  const provider = (Deno.env.get("AI_IMAGE_PROVIDER") ?? "openai").toLowerCase();
  if (provider === "stability") {
    return { provider, key: Deno.env.get("STABILITY_API_KEY") ?? "" };
  }
  return { provider: "openai", key: Deno.env.get("OPENAI_API_KEY") ?? "" };
}

function openAiSize(aspectRatio: string, model: string): string {
  if (model.startsWith("gpt-image")) {
    return aspectRatio === "16:9" ? "1536x1024" : aspectRatio === "9:16" ? "1024x1536" : "1024x1024";
  }
  return aspectRatio === "16:9" ? "1792x1024" : aspectRatio === "9:16" ? "1024x1792" : "1024x1024";
}

/** Returns raw image bytes from the configured image provider. */
export async function aiImage(opts: ImageOptions): Promise<Uint8Array> {
  const { provider, key } = imageProvider();
  if (!key) {
    throw new Error(`Missing API key for image provider '${provider}'. Set it in Supabase secrets.`);
  }

  if (provider === "stability") {
    const form = new FormData();
    if (opts.sourceBase64) {
      const bytes = base64ToBytes(opts.sourceBase64);
      form.append("image", new Blob([bytes], { type: opts.sourceMime ?? "image/png" }), "source.png");
      form.append("mode", "image-to-image");
      form.append("strength", "0.55");
    } else {
      form.append("mode", "text-to-image");
    }
    form.append("prompt", opts.prompt);
    form.append("aspect_ratio", opts.aspectRatio);
    form.append("output_format", "png");
    const res = await fetch("https://api.stability.ai/v2beta/stable-image/generate/core", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, Accept: "image/*" },
      body: form,
    });
    if (!res.ok) {
      throw new Error(`stability ${res.status}: ${(await res.text()).slice(0, 400)}`);
    }
    return new Uint8Array(await res.arrayBuffer());
  }

  // OpenAI path
  const model = Deno.env.get("AI_IMAGE_MODEL") ?? "dall-e-3";
  const quality = opts.hd && !model.startsWith("gpt-image") ? "hd" : "standard";

  if (opts.sourceBase64) {
    // Image edit via multipart (gpt-image-1 / dall-e-2)
    const editModel = Deno.env.get("AI_EDIT_MODEL") ?? "gpt-image-1";
    const form = new FormData();
    const bytes = base64ToBytes(opts.sourceBase64);
    form.append("image", new Blob([bytes], { type: opts.sourceMime ?? "image/png" }), "source.png");
    form.append("prompt", opts.prompt);
    form.append("model", editModel);
    if (editModel.startsWith("gpt-image")) {
      form.append("size", openAiSize(opts.aspectRatio, editModel));
    }
    const res = await fetch("https://api.openai.com/v1/images/edits", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}` },
      body: form,
    });
    const bodyText = await res.text();
    if (!res.ok) throw new Error(`openai edits ${res.status}: ${bodyText.slice(0, 400)}`);
    return await decodeImageResponse(bodyText);
  }

  const res = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      prompt: opts.prompt,
      n: 1,
      size: openAiSize(opts.aspectRatio, model),
      ...(model.startsWith("dall-e") ? { quality } : {}),
    }),
  });
  const bodyText = await res.text();
  if (!res.ok) throw new Error(`openai images ${res.status}: ${bodyText.slice(0, 400)}`);
  return await decodeImageResponse(bodyText);
}

async function decodeImageResponse(bodyText: string): Promise<Uint8Array> {
  const data = JSON.parse(bodyText);
  const item = data?.data?.[0];
  if (item?.b64_json) return base64ToBytes(item.b64_json);
  if (item?.url) {
    const img = await fetch(item.url);
    if (!img.ok) throw new Error(`failed to download generated image ${img.status}`);
    return new Uint8Array(await img.arrayBuffer());
  }
  throw new Error("no image in provider response");
}

// ---------- Storage ----------

export function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

/** Upload bytes to the public `generations` bucket and return the public URL. */
export async function uploadToStorage(
  admin: SupabaseClient,
  userId: string,
  bytes: Uint8Array,
  mime = "image/png",
): Promise<string> {
  const path = `${userId}/${crypto.randomUUID()}.png`;
  const { error } = await admin.storage
    .from("generations")
    .upload(path, bytes, { contentType: mime, upsert: false });
  if (error) throw new Error(`storage upload failed: ${error.message}`);
  return `${Deno.env.get("SUPABASE_URL")}/storage/v1/object/public/generations/${path}`;
}

// ---------- Persistence ----------

export async function saveGeneration(
  admin: SupabaseClient,
  userId: string,
  row: {
    type: string;
    prompt?: string | null;
    result_url?: string | null;
    result_text?: string | null;
    style?: string | null;
    metadata?: Record<string, unknown>;
  },
): Promise<Record<string, unknown>> {
  const { data, error } = await admin
    .from("generations")
    .insert({ user_id: userId, ...row })
    .select()
    .single();
  if (error) throw new Error(`could not save generation: ${error.message}`);
  return data as Record<string, unknown>;
}

export async function readHistory(
  admin: SupabaseClient,
  conversationId: string,
  limit = 20,
): Promise<Array<{ role: "user" | "assistant"; content: string }>> {
  const { data } = await admin
    .from("messages")
    .select("role, content")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });
  const rows = (data ?? []) as Array<{ role: string; content: string }>;
  return rows
    .slice(-limit)
    .map((m) => ({
      role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
      content: m.content,
    }));
}

export const CHAT_SYSTEM_PROMPT =
  "You are NABBEH AI, a professional, friendly AI assistant inside a mobile app. " +
  "Reply in the SAME language the user writes in (Arabic or English). " +
  "Be concise, helpful and well-formatted. Use markdown sparingly (it renders as plain text).";
