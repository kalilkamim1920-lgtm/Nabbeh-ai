import 'package:flutter/material.dart';

import '../models/chat_message.dart';
import '../core/theme/app_colors.dart';

/// Chat bubble with support for attached images.
class MessageBubble extends StatelessWidget {
  const MessageBubble({super.key, required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final bool isUser = message.isUser;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Align(
      alignment: isUser ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.sizeOf(context).width * 0.78,
        ),
        decoration: BoxDecoration(
          gradient: isUser ? AppColors.brandGradient : null,
          color: isUser ? null : (isDark ? AppColors.darkCard : Colors.white),
          borderRadius: BorderRadiusDirectional.only(
            topStart: Radius.circular(isUser ? 18 : 4),
            topEnd: Radius.circular(isUser ? 4 : 18),
            bottomStart: const Radius.circular(18),
            bottomEnd: const Radius.circular(18),
          ),
          border: isUser
              ? null
              : Border.all(
                  color: isDark
                      ? AppColors.darkBorder
                      : AppColors.lightBorder,
                ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (message.imageUrl != null &&
                message.imageUrl!.isNotEmpty &&
                message.imageUrl != 'local')
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    message.imageUrl!,
                    width: 220,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  ),
                ),
              ),
            if (message.content.isNotEmpty)
              SelectableText(
                message.content,
                style: TextStyle(
                  fontSize: 15,
                  height: 1.45,
                  color: isUser
                      ? Colors.white
                      : (isDark ? Colors.white : Colors.black87),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
