import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/app_user.dart';
import '../services/supabase_service.dart';

/// Reads/writes the current user's profile row.
class UserRepository {
  const UserRepository();

  SupabaseClient get _client => SupabaseService.client;

  /// Fetch the profile; retries briefly because the DB trigger that creates
  /// the profile row may still be committing right after sign-up.
  Future<AppUser?> fetchProfile({bool retry = true}) async {
    final User? user = SupabaseService.currentUser;
    if (user == null) return null;

    for (int attempt = 0; attempt < (retry ? 3 : 1); attempt++) {
      final List<dynamic> rows = await _client
          .from('profiles')
          .select()
          .eq('id', user.id)
          .limit(1);
      if (rows.isNotEmpty) {
        return AppUser.fromMap(rows.first as Map<String, dynamic>);
      }
      await Future<void>.delayed(
        Duration(milliseconds: 400 * (attempt + 1)),
      );
    }
    return null;
  }

  Future<void> updateDisplayName(String name) async {
    final User? user = SupabaseService.currentUser;
    if (user == null) return;
    await _client.from('profiles').update({
      'display_name': name,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', user.id);
  }
}
